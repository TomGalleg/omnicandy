import { useCallback, useEffect, useMemo, useState } from 'react';
import { Group, Panel, Separator, useDefaultLayout, usePanelRef } from 'react-resizable-panels';
import { EDITOR_APPS } from '@shared/appEditors';
import type { IntegrationSnapshot } from '@shared/ipc';
import type { AppProbeResult, ProjectManifest, WorkspaceId } from '@shared/types';
import { AssetBrowser } from './components/AssetBrowser';
import { BottomPanel, type LogEntry } from './components/BottomPanel';
import { ClaudePanel } from './components/ClaudePanel';
import { Header } from './components/Header';
import { WorkspaceView } from './components/Workspaces';
import { useAppearance } from './useAppearance';
import { useLive } from './useLive';

const storage = (() => { try { return window.localStorage; } catch { return undefined; } })();

export function App() {
  const appearance = useAppearance();
  const [workspace, setWorkspace] = useState<WorkspaceId>('media');
  const [manifest, setManifest] = useState<ProjectManifest | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [apps, setApps] = useState<AppProbeResult[]>([]);
  const [integrations, setIntegrations] = useState<IntegrationSnapshot | null>(null);
  const [log, setLog] = useState<LogEntry[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [projectKey, setProjectKey] = useState<string | null>(null);

  const addLog = useCallback((source: string, message: string) => {
    setLog((l) => [...l.slice(-299), { at: new Date(), source, message }]);
  }, []);

  const reloadProject = useCallback(() => {
    window.studio.loadProject().then(setManifest).catch((e: unknown) => setError(String(e)));
  }, []);

  const loadCurrent = useCallback(() => {
    window.studio.projects.current().then(setProjectKey).catch(() => {});
    window.studio.loadProject()
      .then((m) => { setManifest(m); setSelectedId(m.assets[0]?.id ?? null); setError(null); addLog('project', `Loaded "${m.name}" (${m.assets.length} assets).`); })
      .catch((e: unknown) => setError(String(e)));
  }, [addLog]);

  useEffect(() => {
    loadCurrent();
    window.studio.integrationStatus().then(setIntegrations).catch(() => {});
    window.studio.probeApps().then((r) => {
      setApps(r);
      addLog('artcraft', `Detected ${r.filter((a) => a.installed).length}/${r.length} ArtCraft apps (installed, not connected).`);
    }).catch(() => {});
  }, [addLog, loadCurrent]);

  const liveApi = useLive(addLog);

  // When Claude opens a file (possibly in another app), show it: select it and go to that app's tab.
  const live = liveApi.live;
  const claudeOpened = live?.status === 'ready' && live.openedBy === 'claude' && live.asset ? `${live.appId}:${live.asset.id}` : null;
  useEffect(() => {
    if (!claudeOpened || !live?.asset) return;
    const id = live.asset.id;
    if (!manifest?.assets.some((a) => a.id === id)) reloadProject();
    setSelectedId(id);
    setWorkspace(EDITOR_APPS[live.appId].tab);
    // Only when Claude opens something new, not on every state update.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [claudeOpened]);

  // New AI images (from the Generate tab or Claude) appear in the library right away.
  useEffect(() => window.studio.generate.onResult((r) => {
    reloadProject();
    if (r.requestedBy === 'claude') addLog('generate', `Claude: ${r.message}`);
  }), [reloadProject, addLog]);

  /** After switching projects: reload everything tied to the old one. */
  const onSwitched = useCallback((key: string) => {
    setProjectKey(key);
    loadCurrent();
    void liveApi.resync();
  }, [loadCurrent, liveApi]);
  const goto = useCallback((w: WorkspaceId, assetId?: string) => { if (assetId) setSelectedId(assetId); setWorkspace(w); }, []);

  const selected = useMemo(() => manifest?.assets.find((a) => a.id === selectedId) ?? null, [manifest, selectedId]);

  const outer = useDefaultLayout({ id: 'cs-outer', storage });
  // Claude panel starts minimized; the header's Claude button opens/closes it (remembered).
  const claudeRef = usePanelRef();
  const [claudeOpen, setClaudeOpen] = useState(() => { try { return storage?.getItem('cs-claude-open') === '1'; } catch { return false; } });
  useEffect(() => {
    const p = claudeRef.current;
    if (!p) return;
    if (claudeOpen && p.isCollapsed()) p.expand();
    if (!claudeOpen && !p.isCollapsed()) p.collapse();
    try { storage?.setItem('cs-claude-open', claudeOpen ? '1' : '0'); } catch { /* storage unavailable */ }
  }, [claudeOpen, claudeRef]);
  const center = useDefaultLayout({ id: 'cs-center', storage });

  return (
    <div className="app">
      <Header
        projectName={manifest?.name ?? '…'}
        onProjectHome={() => setWorkspace('home')}
        workspace={workspace}
        onWorkspace={setWorkspace}
        apps={apps}
        integrations={integrations}
        appearance={appearance}
        claudeOpen={claudeOpen}
        appTheme={liveApi.live?.appTheme ?? null}
        onToggleClaude={() => setClaudeOpen((o) => !o)}
      />
      {error && <div className="notice" role="alert">Could not load project: {error}</div>}
      <div className="main">
        <Group orientation="horizontal" defaultLayout={outer.defaultLayout} onLayoutChanged={outer.onLayoutChanged}>
          <Panel id="left" defaultSize="20" minSize={220} collapsible>
            <AssetBrowser
              manifest={manifest}
              selectedId={selectedId}
              onSelect={setSelectedId}
              onManifest={setManifest}
              log={addLog}
            />
          </Panel>
          <Separator className="sep" />
          <Panel id="center" minSize="35">
            <Group orientation="vertical" defaultLayout={center.defaultLayout} onLayoutChanged={center.onLayoutChanged}>
              <Panel id="viewer" minSize="30">
                <div className="center">
                  <WorkspaceView
                    key={projectKey ?? 'none'}
                    projectKey={projectKey}
                    onSwitched={onSwitched}
                    onGoto={goto}
                    workspace={workspace}
                    manifest={manifest}
                    selected={selected}
                    apps={apps}
                    integrations={integrations}
                    resolvedTheme={appearance.resolved}
                    log={addLog}
                    onProjectChanged={reloadProject}
                    liveApi={liveApi}
                    onSelectAsset={setSelectedId}
                  />
                </div>
              </Panel>
              <Separator className="sep" />
              <Panel id="bottom" defaultSize="24" minSize={90} collapsible>
                <BottomPanel selected={selected} log={log} liveApi={liveApi} manifest={manifest} />
              </Panel>
            </Group>
          </Panel>
          <Separator className="sep" />
          <Panel id="right" defaultSize="22" minSize={260} collapsible collapsedSize={0} panelRef={claudeRef}
            onResize={() => { const c = claudeRef.current?.isCollapsed() ?? false; if (c === claudeOpen) setClaudeOpen(!c); }}>
            <ClaudePanel key={projectKey ?? 'none'} selected={selected} integrations={integrations} liveApi={liveApi} />
          </Panel>
        </Group>
      </div>
    </div>
  );
}
