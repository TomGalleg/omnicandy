import { z } from 'zod';
import type { LiveTaskController } from '../liveTask';
import type { ProjectStore } from '../projectStore';
import { EDITOR_APPS, type EditorAppId } from '@shared/appEditors';
import { tool, ToolRegistry } from './registry';

const empty = z.object({}).strict();
const values = z.record(z.string().max(64), z.unknown());
/** Uses the existing controller: it owns command allow-lists, versioning and human approval. */
export function nativeToolRegistry(ctl: LiveTaskController, store: ProjectStore, opts: { supportsVision?: boolean } = {}): ToolRegistry {
  const tools = [
    tool('get_status', 'Get the currently open app, document, edit lock and available edits. Call first.', empty, async () => JSON.stringify(await ctl.statusForClaude())),
    tool('list_files', 'List names and formats of project library files.', empty, async () => JSON.stringify((await store.loadManifest()).assets.map(a => ({ name: a.name, kind: a.kind, format: a.sourceFormat, version: !!a.parentId })))),
    tool('open_file', 'Open a project library file by its exact name. Do not discard unsaved edits.', z.object({ name: z.string().min(1).max(512), app: z.string().max(32).optional() }).strict(), async ({name, app}) => {
      const s = ctl.snapshot();
      if (s.asset && s.history.length > 1 && s.savedVersionIds.length === 0) throw new Error('Unsaved edits may exist; ask the user before changing documents.');
      if (s.collab.phase === 'manual' || s.collab.phase === 'pausing' || s.collab.phase === 'paused') throw new Error('The user has control or paused the task; stop and wait.');
      const assets = (await store.loadManifest()).assets.filter(a => a.name === name);
      if (assets.length !== 1) throw new Error(assets.length ? 'Ambiguous file name.' : `No file named ${name}. Use list_files.`);
      if (app && !(app in EDITOR_APPS)) throw new Error('Unknown application id. Use get_status.');
      await ctl.open(assets[0]!.id, app as EditorAppId | undefined, 'claude');
      return JSON.stringify((await ctl.statusForClaude()).open);
    }),
    tool('apply_edit', 'Apply an edit listed in get_status to the open app.', z.object({ edit_id: z.string().min(1).max(64), settings: values.optional() }).strict(), async ({edit_id,settings}) => ctl.claudeQuickEdit(edit_id, settings ?? {})),
    tool('app_commands', 'Discover exact commands and parameters of the open app; do not guess command identifiers.', z.object({ filter: z.string().max(64).optional() }).strict(), async ({filter}) => ctl.appCommandList(filter)),
    tool('app_command', 'Execute one advertised command in the current app. Existing permissions and human approvals always apply.', z.object({ command: z.string().min(1).max(128), params: values.optional() }).strict(), async ({command,params}) => ctl.claudeAppCommand(command,params ?? {})),
    tool('undo', 'Undo the last change to the active document.', empty, async () => ctl.claudeUndo()),
    tool('save_version', 'Save changes as a new library version only if the user requested a save.', empty, async () => {
      const s = ctl.snapshot();
      if (s.collab.lockOwner === 'user' || ['manual','pausing','paused'].includes(s.collab.phase)) throw new Error('User controls or paused document; stop and wait.');
      return (await ctl.saveVersion()).message ?? 'Save operation completed.';
    }),
  ];
  // Vision requires multimodal message parts, not supplied by the prototype provider contract.
  // Never send image base64 as text to a model. Future providers may add look_at_document.
  void opts;
  return new ToolRegistry(tools);
}
