# CreateCraft independent agent harness — Prototype 1

## Scope

This is an **offline-first, isolated source drop**, not a wired-in feature or a replacement for the Claude panel. Nothing in the existing CreateCraft source was changed. No paid model calls were made.

Files go under `creative-studio/src/main/agentHarness/`. The new components are:

- `types.ts` — provider, messages, tool calls, results and event contracts.
- `registry.ts` — validated registry, stable tool snapshots and safe error results.
- `nativeTools.ts` — eight native app tools routed through existing LiveTaskController and ProjectStore.
- `loop.ts` — bounded model/tool iteration, state checks, completion of all tool-call IDs, event stream, cleanup.
- `providers/scripted.ts` — deterministic offline provider.
- `providers/openaiCompatible.ts` — HTTPS / explicit localhost Chat Completions tool-calling adapter.
- Two unit-test files — offline protocol, runtime and registry tests.

### Honest limitations

1. **No Electron IPC or UI wiring**. The prototype cannot be launched from CreateCraft yet. Phase 2 requires passing the singleton controller, project store, and vault into a factory inside `ipc.ts`, and enforcing exclusion against the active ClaudePartner session.
2. **No actual OpenAI calls** or on-device app test has been run here. Provider model identifiers are supplied by the caller rather than hardcoded.
3. `look_at_document` is **deferred**: an image requires a multimodal provider message representation. Unlike text tools, it must not be faked by injecting base64 into prompt text.
4. External adapters are **not wired**. The registry can accept future tool backends, but `IntegrationManager` remains protected by its existing permissions and is not currently exposed to this harness.
5. **State and outcomes are in memory** for this phase; audit persistence, recoverable checkpoints and independent verification are future milestones. An executed command is not automatically proof the intended result was achieved.
6. **The current controller uses one `claude` edit lock**, so running a new harness concurrently with ClaudePartner would be unsafe. Do not enable it in a live CreateCraft process without a shared session/mutual-exclusion guard. Its `claudeDone()` cleanup is a legacy API name, not an Anthropic SDK dependency.
7. `save_version` and `open_file` currently rely on the existing controller's safety behavior and contain additional checks. Before a live UI release, add explicit user confirmation for replacing unsaved documents and a save authorization state.
8. The OpenAI-compatible provider accepts `getKey` for prototyping. For production, instantiate/call it **inside the existing `vault.withKey('openai', async key => ...)` scope** rather than persisting the key or obtaining it outside the vault lifetime. Never pass keys to adapters.
9. No dependency install was undertaken in this environment. Compilation and the full Vitest suite must be run against the actual repository dependencies.

## Installation

1. Extract the archive into a temporary directory, review its contents, and copy **only** `src/main/agentHarness/` to the equivalent directory in `creative-studio/`.
2. Run `npm run typecheck` and `npx vitest run src/main/agentHarness` from `creative-studio`.
3. Run `npm run check` and `npm run build` when dependencies and project files are available.
4. Do not wire the harness to IPC or a UI in this phase. Do not push until reviewed.
5. Send any TypeScript/test failures back for a narrowly scoped patch.

## Safety

- The controller remains the only owner of app control, approvals, policies, versions and locks.
- Tool schema validation cannot grant privileges; actual execution must pass through the existing backend.
- ScriptedProvider supports offline tests; HTTP provider is *not* invoked by test setup.
- A model/tool turn keeps tool-call ID/result alignment even after cancellation.

## Handoff to Claude Code (minimal credits)

> Copy only the new `src/main/agentHarness/` files into the matching source directory. Do not redesign, alter existing Claude integration, install dependencies, make paid API calls, or wire UI. Run `npm run typecheck`, `npx vitest run src/main/agentHarness`, and `npm run check`. Return exact errors with file paths and line numbers; stop without unrelated changes. Do not push.
