# SOURCE_INFO

- Repository: https://github.com/anomalyco/opencode
- Branch: `v2` (available)
- Commit SHA: 4617210822bdbb31e5749751afbfb4584ccedac8 (committed 2026-10-10)
- Download date: 2026-10-20
- License: see `LICENSE` (included)

## Path substitutions (v2 layout differs from the requested paths)

| Requested | Not found / why | Collected instead |
|---|---|---|
| packages/core/src/tool/registry.ts | no such file | packages/core/src/tool.ts, tool-output.ts, tool/runtime.ts, tool/AGENTS.md, tool/mcp.ts, tool/plugin/{opencode,read,shell}.ts |
| packages/core/src/tool/tool.ts | no such file | packages/core/src/tool.ts (same as above) |
| packages/opencode/src/session/processor.ts | `packages/opencode/` does not exist in v2 | packages/core/src/session/runner/* (index, step, llm, model, max-steps, retry, publish-llm-event, to-llm-message, prompt/system.txt) |
| packages/opencode/src/session/llm.ts | same | packages/core/src/session/runner/llm.ts, session/generate.ts |
| packages/opencode/src/session/llm/request.ts | same | packages/core/src/session/model-request.ts, model-transport.ts, provider-context.ts |
| packages/plugin/src/index.ts | no top-level index.ts | packages/plugin/src/effect/index.ts, promise/index.ts, runtime.ts, README.md, AGENTS.md, package.json |
| packages/llm/src/index.ts, packages/llm/AGENTS.md | `packages/llm/` does not exist; renamed | packages/ai/src/index.ts, packages/ai/AGENTS.md (and README.md, package.json) |

## Added supporting files
Permissions (core/src/permission*.ts, schema/src/permission.ts), agent and session management (core/src/agent.ts, session.ts, session/{session,run-coordinator,execution,message,message-updater,history,store,usage,compaction,error,event}.ts), schemas (schema/src/{tool,llm,model,provider}.ts), plugin tool/permission/provider/model/session APIs, the model-provider abstraction in packages/ai (llm, tool, tool-runtime, tool-history, provider, route/*, schema/*) and the protocols most relevant to CreateCraft (openai-chat, openai-compatible-chat, anthropic-messages, gemini, shared, tool-schema/tool-stream utils).
Not collected: the other ~60 provider/media protocols, UI, apps, desktop, tests.

## Requested files not found
All requested files were either found or substituted as listed above; no requested file is entirely missing.

## Collected files
- LICENSE
- packages/ai/AGENTS.md
- packages/ai/README.md
- packages/ai/package.json
- packages/ai/src/ai-client.ts
- packages/ai/src/generation.ts
- packages/ai/src/index.ts
- packages/ai/src/llm.ts
- packages/ai/src/protocols.ts
- packages/ai/src/protocols/anthropic-messages.ts
- packages/ai/src/protocols/gemini.ts
- packages/ai/src/protocols/index.ts
- packages/ai/src/protocols/openai-chat.ts
- packages/ai/src/protocols/openai-compatible-chat.ts
- packages/ai/src/protocols/shared.ts
- packages/ai/src/protocols/utils/gemini-json-schema.ts
- packages/ai/src/protocols/utils/tool-schema.ts
- packages/ai/src/protocols/utils/tool-stream.ts
- packages/ai/src/provider-error.ts
- packages/ai/src/provider.ts
- packages/ai/src/route.ts
- packages/ai/src/route/auth.ts
- packages/ai/src/route/client.ts
- packages/ai/src/route/endpoint.ts
- packages/ai/src/route/executor.ts
- packages/ai/src/route/framing.ts
- packages/ai/src/route/index.ts
- packages/ai/src/route/protocol.ts
- packages/ai/src/route/transport/http.ts
- packages/ai/src/schema/errors.ts
- packages/ai/src/schema/events.ts
- packages/ai/src/schema/ids.ts
- packages/ai/src/schema/index.ts
- packages/ai/src/tool-history.ts
- packages/ai/src/tool-runtime.ts
- packages/ai/src/tool.ts
- packages/core/src/agent.ts
- packages/core/src/permission.ts
- packages/core/src/permission/saved.ts
- packages/core/src/session.ts
- packages/core/src/session/compaction.ts
- packages/core/src/session/error.ts
- packages/core/src/session/event.ts
- packages/core/src/session/execution.ts
- packages/core/src/session/generate.ts
- packages/core/src/session/history.ts
- packages/core/src/session/message-updater.ts
- packages/core/src/session/message.ts
- packages/core/src/session/model-request.ts
- packages/core/src/session/model-transport.ts
- packages/core/src/session/provider-context.ts
- packages/core/src/session/run-coordinator.ts
- packages/core/src/session/runner/index.ts
- packages/core/src/session/runner/llm.ts
- packages/core/src/session/runner/max-steps.ts
- packages/core/src/session/runner/model.ts
- packages/core/src/session/runner/prompt/system.txt
- packages/core/src/session/runner/publish-llm-event.ts
- packages/core/src/session/runner/retry.ts
- packages/core/src/session/runner/step.ts
- packages/core/src/session/runner/to-llm-message.ts
- packages/core/src/session/session.ts
- packages/core/src/session/store.ts
- packages/core/src/session/usage.ts
- packages/core/src/tool-output.ts
- packages/core/src/tool.ts
- packages/core/src/tool/AGENTS.md
- packages/core/src/tool/mcp.ts
- packages/core/src/tool/plugin/opencode.ts
- packages/core/src/tool/plugin/read.ts
- packages/core/src/tool/plugin/shell.ts
- packages/core/src/tool/runtime.ts
- packages/http-recorder/LICENSE
- packages/plugin/AGENTS.md
- packages/plugin/package.json
- packages/plugin/src/README.md
- packages/plugin/src/effect/aisdk.ts
- packages/plugin/src/effect/index.ts
- packages/plugin/src/effect/model.ts
- packages/plugin/src/effect/permission.ts
- packages/plugin/src/effect/plugin.ts
- packages/plugin/src/effect/provider.ts
- packages/plugin/src/effect/session.ts
- packages/plugin/src/effect/tool.ts
- packages/plugin/src/promise/index.ts
- packages/plugin/src/promise/tool.ts
- packages/plugin/src/runtime.ts
- packages/schema/src/llm.ts
- packages/schema/src/model.ts
- packages/schema/src/permission.ts
- packages/schema/src/provider.ts
- packages/schema/src/tool.ts
- packages/ui/LICENSE
- script/oxlint/anti-slop/vendor/eslint-stylistic/LICENSE
