import type { AgentEvent, AgentOutcome, Message, ModelProvider } from './types';
import { ToolRegistry } from './registry';
import type { LiveTaskController } from '../liveTask';

const active = new WeakSet<LiveTaskController>();
const system = `You operate ONLY connected CreateCraft applications through approved tools. Call get_status before editing, use app_commands to discover exact commands, and inspect results before continuing. Never invent success. Human denials, pauses and takeovers are final; stop. Save versions only when the user requests it. Do not request shell, code execution or unlisted tools.`;
const paused = (ctl: LiveTaskController) => {
  const c = ctl.snapshot().collab;
  return c.lockOwner === 'user' || ['manual','pausing','paused','awaiting_approval'].includes(c.phase);
};
const stopText = /stop and wait|do not retry|user declined|user paused|user cancelled|taken control|not available here/i;
export async function runAgent(args: { goal: string; provider: ModelProvider; registry: ToolRegistry; ctl: LiveTaskController; signal?: AbortSignal; maxTurns?: number; maxToolCalls?: number; onEvent?: (event: AgentEvent) => void }): Promise<AgentOutcome> {
  const { provider, registry, ctl } = args;
  if (active.has(ctl) || ctl.snapshot().collab.activeOperation || ctl.snapshot().collab.phase === 'running') throw new Error('Another application task is already running.');
  if (paused(ctl)) throw new Error('User control or pause is active.');
  active.add(ctl);
  const messages: Message[] = [{ role: 'user', content: args.goal }];
  const events: AgentEvent[] = [];
  const emit = (e: AgentEvent) => { events.push(e); args.onEvent?.(e); };
  const result = (status: AgentOutcome['status'], text: string): AgentOutcome => ({ status, text, messages, events });
  const maxTurns = Math.max(1, Math.min(args.maxTurns ?? 20, 100));
  const maxCalls = Math.max(1, Math.min(args.maxToolCalls ?? 50, 250));
  let calls = 0;
  try {
    for (let turn = 0; turn < maxTurns; turn++) {
      if (args.signal?.aborted) return result('cancelled', 'Cancelled.');
      if (paused(ctl)) return result('paused', 'User intervention is required.');
      const snapshot = registry.snapshot();
      let reply;
      try { reply = await provider.complete({ system, messages, tools: snapshot.map(({name,description,parameters})=>({name,description,parameters})), signal: args.signal ?? new AbortController().signal }); }
      catch (e) {
        if (args.signal?.aborted) return result('cancelled', 'Cancelled.');
        const msg = e instanceof Error ? e.message : String(e);
        emit({kind:'error',text:msg}); return result('failed',msg);
      }
      messages.push({ role: 'assistant', content: reply.text, ...(reply.toolCalls.length ? {toolCalls:reply.toolCalls} : {}) });
      emit({kind:'model',text:reply.text ?? ''});
      if (!reply.toolCalls.length) return result('completed',reply.text ?? 'Model finished without a final message; verify the output.');
      // Complete *every* tool call in the assistant message with a matching tool result, even on stop.
      let halt: 'cancelled' | 'paused' | 'limit' | undefined;
      for (const call of reply.toolCalls) {
        if (!halt && args.signal?.aborted) halt='cancelled';
        if (!halt && paused(ctl)) halt='paused';
        if (!halt && calls >= maxCalls) halt='limit';
        let r;
        if (halt) r = {text:`Error: Not executed; agent ${halt}.`,isError:true};
        else {
          calls++;
          emit({kind:'tool',text:JSON.stringify(call.args).slice(0,2000),callId:call.id,tool:call.name});
          r = await registry.call(snapshot,call.name,call.args);
          if (paused(ctl) || (r.isError && stopText.test(r.text))) halt='paused';
        }
        messages.push({role:'tool',toolCallId:call.id,content:r.text});
        emit({kind:'result',text:r.text,callId:call.id,tool:call.name,isError:!!r.isError});
      }
      if (halt) { emit({kind:'stop',text:halt}); return result(halt,`Agent stopped: ${halt}.`); }
    }
    return result('limit','Maximum model turns reached.');
  } finally {
    ctl.claudeDone();
    active.delete(ctl);
  }
}
