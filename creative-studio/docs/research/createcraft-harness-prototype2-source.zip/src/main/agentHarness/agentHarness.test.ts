import { describe, expect, it } from 'vitest';
import { z } from 'zod';
import { ToolRegistry, tool } from './registry';
import { runAgent } from './loop';
import { ScriptedProvider } from './providers/scripted';
import type { LiveTaskController } from '../liveTask';

function fakeController() {
  const state = { phase: 'idle', lockOwner: null as string | null, activeOperation: null as string | null };
  let done = 0;
  const ctl = { snapshot: () => ({ collab: state }), claudeDone: () => { done++; state.phase='completed'; state.lockOwner=null; } } as unknown as LiveTaskController;
  return { ctl, state, get done() { return done; } };
}
const reply = (name: string, args: unknown = {}) => ({ text: null, toolCalls: [{ id:'call_1',name,args }] });
const final = { text:'Done, pending verification', toolCalls:[] };

describe('model-independent harness', () => {
  it('executes tools and returns results to the model', async () => {
    const f=fakeController(); let edits=0;
    const registry=new ToolRegistry([tool('edit','Validated edit',z.object({amount:z.number()}).strict(),async ({amount})=>{edits+=amount;return 'executed';})]);
    const outcome=await runAgent({goal:'edit',provider:new ScriptedProvider([reply('edit',{amount:2}),final]),ctl:f.ctl,registry});
    expect(outcome.status).toBe('completed'); expect(edits).toBe(2);
    expect(outcome.messages.find(m=>m.role==='tool')).toMatchObject({role:'tool',toolCallId:'call_1',content:'executed'});
    expect(f.done).toBe(1);
  });
  it('rejects invalid and unknown tools with structured error results', async () => {
    const f=fakeController();
    const registry=new ToolRegistry([tool('edit','Edit',z.object({amount:z.number()}).strict(),async ()=>'unexpected')]);
    const outcome=await runAgent({goal:'edit',provider:new ScriptedProvider([reply('edit',{amount:'bad'}),reply('absent'),final]),ctl:f.ctl,registry});
    expect(outcome.status).toBe('completed');
    expect(outcome.messages.filter(m=>m.role==='tool')).toHaveLength(2);
    expect(outcome.events.filter(e=>e.kind==='result').every(e=>e.isError)).toBe(true);
  });
  it('respects cancellation, max turns, and user takeover', async () => {
    const f=fakeController(); const signal=new AbortController(); signal.abort();
    expect((await runAgent({goal:'x',ctl:f.ctl,registry:new ToolRegistry(),provider:new ScriptedProvider([final]),signal:signal.signal})).status).toBe('cancelled');
    expect((await runAgent({goal:'x',ctl:f.ctl,registry:new ToolRegistry(),provider:new ScriptedProvider([reply('missing')]),maxTurns:1})).status).toBe('limit');
    const g=fakeController();
    const reg=new ToolRegistry([tool('takeover','Change control',z.object({}).strict(),async ()=>{g.state.phase='manual';g.state.lockOwner='user';return 'user took control';})]);
    expect((await runAgent({goal:'x',ctl:g.ctl,registry:reg,provider:new ScriptedProvider([reply('takeover'),final])})).status).toBe('paused');
  });
  it('revalidates that a tool snapshot is still current', async () => {
    const t=tool('edit','Edit',z.object({}).strict(),async ()=>'ok');
    const a=new ToolRegistry([t]);
    const b=new ToolRegistry();
    expect((await b.call(a.snapshot(),'edit',{})).isError).toBe(true);
  });
});
