# SOURCE_INFO

- Branch: main
- Commit SHA: bf3b0623158ddadeda7632f0e58ef5287d90747b (base commit; `src/main/agentHarness/` is NOT committed: it is untracked in the working tree and is included as it exists on disk)
- Collection date: 2026-10-20
- Missing files: none
- No credentials or secret files included (key handling code only: credentialVault.ts, claudeAuth.ts).

## Corrected OpenAI provider import
`src/main/agentHarness/providers/openaiCompatible.ts` line 1 in this archive: `import type { ModelProvider, ProviderReply } from '../types';` (unused `Message` removed; `npm run check` passed with this version).

## Relevant UI mounting locations
- `src/renderer/src/App.tsx` is the only file that imports `ClaudePanel`.
- `src/renderer/src/components/ClaudePanel.tsx` is the chat panel; styles in `src/renderer/src/styles.css` (sections "Claude panel", "Claude chat").
- `src/renderer/src/components/ClaudeAuthCard.tsx`, `ProvidersCard.tsx`, `SettingsDialog.tsx`: existing settings/key-entry UI.
- `src/renderer/src/useLive.ts`: live-task state hook used by the panel.
- Electron wiring: `src/main/ipc.ts` (`live()` builds LiveTaskController; `vault` = SafeStorageVault; `claude()` builds ClaudePartner; `claude:*` handlers), `src/shared/ipc.ts` (IPC channel map and StudioApi types), `src/preload/index.ts`.
- No existing IPC unit tests were found (`*ipc*.test.ts`); `src/main/liveTask.test.ts` and `src/main/agentHarness/*.test.ts` are the nearest tests (liveTask.test.ts not included; request if needed).

## Files (34 source files)
- src/main/ipc.ts
- src/shared/ipc.ts
- src/preload/index.ts
- src/renderer/src/components/ClaudePanel.tsx
- src/renderer/src/App.tsx
- src/renderer/src/main.tsx
- src/renderer/src/useLive.ts
- src/renderer/src/styles.css
- src/renderer/src/components/ClaudeAuthCard.tsx
- src/renderer/src/components/ProvidersCard.tsx
- src/renderer/src/components/SettingsDialog.tsx
- src/renderer/src/components/live/LiveParts.tsx
- src/shared/claude.ts
- src/shared/live.ts
- src/shared/generation.ts
- src/shared/types.ts
- src/main/index.ts
- src/main/claudeAuth.ts
- src/main/credentialVault.ts
- src/main/liveTask.ts
- src/main/approvalWindow.ts
- package.json
- tsconfig.node.json
- tsconfig.web.json
- electron.vite.config.ts
- vitest.config.ts
- src/main/agentHarness/agentHarness.test.ts
- src/main/agentHarness/loop.ts
- src/main/agentHarness/nativeTools.ts
- src/main/agentHarness/providers/openaiCompatible.test.ts
- src/main/agentHarness/providers/openaiCompatible.ts
- src/main/agentHarness/providers/scripted.ts
- src/main/agentHarness/registry.ts
- src/main/agentHarness/types.ts