# CreateCraft Agent Harness — Prototype 2

This patch adds an Independent AI mode to the existing Claude panel. No Claude Agent SDK is used in the new execution path.

## Apply

1. Make sure your working tree is backed up / committed locally.
2. Extract this ZIP into the `creative-studio` directory, preserving `src/...` paths, or apply `changes.patch` after reviewing it. **Do not do both.**
3. Run `npm run check` and the Electron build. Report exact failures for follow-up fixes.
4. Open a disposable project and test with an installed Craft app. Real OpenAI requests **cost money**; only run them after explicit approval.

## UI

Open the right Claude panel and select **Switch to Independent AI**. Choose a GPT model and enter a goal. The OpenAI key is borrowed from CreateCraft's secure vault, not exposed to the page. Run, stop, progress, and error text are displayed. Switch back using **Switch to Claude Code**.

## Deliberate limitations / review items

- OpenAI Chat Completions-compatible provider only. Anthropic, Gemini and local model selection are future work.
- Existing app controller is reused; external adapter execution is not yet wired.
- Results and events are in memory and are not persisted between app launches.
- Vision/document preview is not in the prototype provider contract.
- Manual control, shared lock, approval and save-version paths need live Windows testing.
- This is a beta integration package; only TypeScript syntax parsing was validated in the authoring environment, not full project typecheck, lint, unit tests, or GUI behavior.
- If provider key not configured, use Settings > Integrations to add an OpenAI key.
- Avoid switching projects while a run is active; IPC refuses project switch and cross-engine concurrency.
