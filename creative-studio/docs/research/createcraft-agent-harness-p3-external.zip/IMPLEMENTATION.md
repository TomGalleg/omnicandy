# CreateCraft Agent Harness — External Adapter Support (Prototype 3A)

This package adds **three dynamic external app tools** to the existing independent agent: `external_apps`, `external_commands`, `external_command`. It reuses IntegrationManager and existing approval/policy checks. Native Craft app controls are untouched.

## Installation

1. Make a local Git checkpoint or backup. Use only if your `src/main/ipc.ts` is still compatible with Prototype 2; review `changes.patch` first.
2. Extract the `src/` paths into `creative-studio/`, overwriting `src/main/ipc.ts` only after reviewing the two-line diff. **Do not also apply `changes.patch`.**
3. Run `npm run check` and `npx electron-vite build`.
4. Don't run paid model tests yet. A dry run can validate external app discovery with a previously connected test adapter.

## Notes and limitations

- Only `connected` and `limited` external apps are shown, and their commands are rechecked before execution.
- `IntegrationManager.execute()` remains the authority for all parameter validation, approval dialogs, permission ceilings and app command execution.
- This increment does not automatically connect apps or grant permissions. Long-running commands are refused until job tracking is implemented.
- Commands run sequentially through the existing agent loop; stop/abort cannot forcibly cancel a command already handed to IntegrationManager. Test cancellation on disposable projects.
- The independent agent is still OpenAI-compatible only; no Claude/Gemini/local provider work is included.
- Application availability is refreshed on every discovery/execution call; the model's advertised tool *names* are a stable set of three generic tools.
- No live test, typecheck or Electron build has been run in the user's full repository here. See local tests.
