#[cfg(feature = "tree-sitter")]
pub mod analyze;
#[cfg(feature = "platform-apps")]
pub mod apps;
#[cfg(feature = "chat-recall")]
pub mod chatrecall;
#[cfg(feature = "code-mode")]
pub mod code_execution;
pub mod developer;
pub mod ext_manager;
#[cfg(feature = "code-mode")]
mod javascript;
#[cfg(feature = "scheduler")]
pub mod scheduler;
pub mod summarize;
pub mod summon;
pub mod todo;
pub mod tom;

use std::collections::HashMap;

use crate::agents::mcp_client::McpClientTrait;
use once_cell::sync::Lazy;

pub use ext_manager::MANAGE_EXTENSIONS_TOOL_NAME_COMPLETE;

// These are used by integration tests in crates/goose/tests/
#[allow(unused_imports)]
pub use ext_manager::MANAGE_EXTENSIONS_TOOL_NAME;
#[allow(unused_imports)]
pub use ext_manager::SEARCH_AVAILABLE_EXTENSIONS_TOOL_NAME;

pub static PLATFORM_EXTENSIONS: Lazy<HashMap<&'static str, PlatformExtensionDef>> = Lazy::new(
    || {
        let mut map = HashMap::new();

        #[cfg(feature = "tree-sitter")]
        map.insert(
            analyze::EXTENSION_NAME,
            PlatformExtensionDef {
                name: analyze::EXTENSION_NAME,
                display_name: "Analyze",
                description:
                    "Analyze code structure with tree-sitter: directory overviews, file details, symbol call graphs",
                default_enabled: true,
                unprefixed_tools: true,
                hidden: false,
                client_factory: |ctx| Some(Box::new(analyze::AnalyzeClient::new(ctx).unwrap())),
            },
        );

        map.insert(
            todo::EXTENSION_NAME,
            PlatformExtensionDef {
                name: todo::EXTENSION_NAME,
                display_name: "Todo",
                description:
                    "Enable a todo list for goose so it can keep track of what it is doing",
                default_enabled: false,
                unprefixed_tools: false,
                hidden: false,
                client_factory: |ctx| Some(Box::new(todo::TodoClient::new(ctx).unwrap())),
            },
        );

        #[cfg(feature = "platform-apps")]
        map.insert(
            apps::EXTENSION_NAME,
            PlatformExtensionDef {
                name: apps::EXTENSION_NAME,
                display_name: "Apps",
                description:
                    "Create and manage custom Goose apps through chat. Apps are HTML/CSS/JavaScript and run in sandboxed windows.",
                default_enabled: true,
                unprefixed_tools: false,
                hidden: false,
                client_factory: |ctx| Some(Box::new(apps::AppsManagerClient::new(ctx).unwrap())),
            },
        );

        #[cfg(feature = "chat-recall")]
        map.insert(
            chatrecall::EXTENSION_NAME,
            PlatformExtensionDef {
                name: chatrecall::EXTENSION_NAME,
                display_name: "Chat Recall",
                description:
                    "Search past conversations and load session summaries for contextual memory",
                default_enabled: false,
                unprefixed_tools: false,
                hidden: false,
                client_factory: |ctx| {
                    Some(Box::new(chatrecall::ChatRecallClient::new(ctx).unwrap()))
                },
            },
        );

        map.insert(
            "extensionmanager",
            PlatformExtensionDef {
                name: ext_manager::EXTENSION_NAME,
                display_name: "Extension Manager",
                description:
                    "Enable extension management tools for discovering, enabling, and disabling extensions",
                default_enabled: true,
                unprefixed_tools: false,
                hidden: false,
                client_factory: |ctx| Some(Box::new(ext_manager::ExtensionManagerClient::new(ctx).unwrap())),
            },
        );

        #[cfg(feature = "scheduler")]
        map.insert(
            scheduler::EXTENSION_NAME,
            PlatformExtensionDef {
                name: scheduler::EXTENSION_NAME,
                display_name: "Scheduler",
                description: "Create and manage scheduled recipe execution",
                default_enabled: true,
                unprefixed_tools: false,
                hidden: true,
                client_factory: |ctx| {
                    scheduler::SchedulerClient::new(ctx).map(|client| Box::new(client) as _)
                },
            },
        );

        map.insert(
            summon::EXTENSION_NAME,
            PlatformExtensionDef {
                name: summon::EXTENSION_NAME,
                display_name: "Summon",
                description: "Load knowledge and delegate tasks to subagents",
                default_enabled: true,
                unprefixed_tools: true,
                hidden: false,
                client_factory: |ctx| Some(Box::new(summon::SummonClient::new(ctx).unwrap())),
            },
        );

        map.insert(
            summarize::EXTENSION_NAME,
            PlatformExtensionDef {
                name: summarize::EXTENSION_NAME,
                display_name: "Summarize",
                description: "Load files/directories and get an LLM summary in a single call",
                default_enabled: false,
                unprefixed_tools: false,
                hidden: false,
                client_factory: |ctx| Some(Box::new(summarize::SummarizeClient::new(ctx).unwrap())),
            },
        );

        #[cfg(feature = "code-mode")]
        map.insert(
            code_execution::EXTENSION_NAME,
            PlatformExtensionDef {
                name: code_execution::EXTENSION_NAME,
                display_name: "Code Mode",
                description:
                    "Goose will make extension calls through code execution, saving tokens",
                default_enabled: false,
                unprefixed_tools: true,
                hidden: false,
                client_factory: |ctx| {
                    Some(Box::new(
                        code_execution::CodeExecutionClient::new(ctx).unwrap(),
                    ))
                },
            },
        );

        map.insert(
            developer::EXTENSION_NAME,
            PlatformExtensionDef {
                name: developer::EXTENSION_NAME,
                display_name: "Developer",
                description: "Write and edit files, and execute shell commands",
                default_enabled: true,
                unprefixed_tools: true,
                hidden: false,
                client_factory: |_| Some(Box::new(developer::DeveloperClient::new().unwrap())),
            },
        );

        map.insert(
            tom::EXTENSION_NAME,
            PlatformExtensionDef {
                name: tom::EXTENSION_NAME,
                display_name: "Top Of Mind",
                description:
                    "Inject custom context into every turn via GOOSE_MOIM_MESSAGE_TEXT and GOOSE_MOIM_MESSAGE_FILE environment variables",
                default_enabled: true,
                unprefixed_tools: false,
                hidden: false,
                client_factory: |ctx| Some(Box::new(tom::TomClient::new(ctx).unwrap())),
            },
        );

        map.insert(
            crate::skills::EXTENSION_NAME,
            PlatformExtensionDef {
                name: crate::skills::EXTENSION_NAME,
                display_name: "Skills",
                description: "Discover and provide skill instructions from filesystem and builtins",
                default_enabled: true,
                unprefixed_tools: true,
                hidden: false,
                client_factory: |_| Some(Box::new(crate::skills::SkillsClient::default())),
            },
        );

        map
    },
);

#[derive(Clone)]
pub struct PlatformExtensionContext {
    /// Sibling access for the two extensions that operate on the running set
    /// (extension management, code mode). Everything else uses the fields
    /// below.
    pub extension_manager:
        Option<std::sync::Weak<crate::agents::extension_manager::ExtensionManager>>,
    pub providers: std::sync::Arc<crate::agents::provider_manager::ProviderManager>,
    pub session_manager: std::sync::Arc<crate::session::SessionManager>,
    pub scheduler: Option<std::sync::Arc<dyn crate::scheduler_trait::SchedulerTrait>>,
}

impl PlatformExtensionContext {
    pub async fn provider_for_session(
        &self,
        session_id: &str,
    ) -> Result<std::sync::Arc<dyn crate::providers::base::Provider>, String> {
        let session = self
            .session_manager
            .get_session(session_id, false)
            .await
            .map_err(|e| e.to_string())?;
        self.providers
            .provider_for(&session)
            .await
            .map_err(|e| e.to_string())
    }

    pub async fn model_config_for_session(
        &self,
        session_id: &str,
    ) -> Result<goose_providers::model::ModelConfig, String> {
        if let Ok(session) = self.session_manager.get_session(session_id, false).await {
            if let Some(model_config) = session.model_config {
                return Ok(model_config);
            }
        }

        let config = crate::config::Config::global();
        let provider_name = config
            .get_goose_provider()
            .map_err(|_| "Could not resolve model config: missing provider".to_string())?;
        let model_name = config
            .get_goose_model()
            .map_err(|_| "Could not resolve model config: missing model".to_string())?;
        crate::model_config::model_config_from_user_config(&provider_name, &model_name)
            .map_err(|e| format!("Could not resolve model config: {e}"))
    }

    pub fn result_with_platform_notification(
        &self,
        mut result: rmcp::model::CallToolResult,
        extension_name: impl Into<String>,
        event_type: impl Into<String>,
        mut additional_params: serde_json::Map<String, serde_json::Value>,
    ) -> rmcp::model::CallToolResult {
        additional_params.insert("extension".to_string(), extension_name.into().into());
        additional_params.insert("event_type".to_string(), event_type.into().into());

        let meta_value = serde_json::json!({
            "platform_notification": {
                "method": "platform_event",
                "params": additional_params
            }
        });

        if let Some(ref mut meta) = result.meta {
            if let Some(obj) = meta_value.as_object() {
                for (k, v) in obj {
                    meta.0.insert(k.clone(), v.clone());
                }
            }
        } else {
            result.meta = Some(rmcp::model::MetaObject(
                meta_value.as_object().unwrap().clone(),
            ));
        }

        result
    }
}

/// Definition for a platform extension that runs in-process with direct agent access.
#[derive(Debug, Clone)]
pub struct PlatformExtensionDef {
    pub name: &'static str,
    pub display_name: &'static str,
    pub description: &'static str,
    pub default_enabled: bool,
    /// If true, tools are exposed without extension prefix for intuitive first-class use.
    pub unprefixed_tools: bool,
    /// If true, the extension is not shown in the UI or discoverable via search_available_extensions.
    pub hidden: bool,
    pub client_factory: fn(PlatformExtensionContext) -> Option<Box<dyn McpClientTrait>>,
}
