use crate::agents::extension::ExtensionConfig;
use crate::agents::extension::PlatformExtensionContext;
use crate::agents::extension_manager::{is_hidden_extension, ExtensionMutation};
use crate::agents::mcp_client::{Error, McpClientTrait};
use crate::agents::tool_execution::ToolCallContext;
use crate::config::extensions::name_to_key;
use crate::config::{get_all_extensions, get_extension_by_name};
use crate::session::SessionType;
use anyhow::Result;
use async_trait::async_trait;
use indoc::indoc;
use rmcp::model::{
    CallToolResult, ContentBlock, ErrorCode, ErrorData, GetPromptResult, Implementation,
    InitializeResult, JsonObject, ListPromptsResult, ListResourcesResult, ListToolsResult,
    ReadResourceResult, ServerCapabilities, ServerNotification, Tool, ToolAnnotations,
};
use schemars::{schema_for, JsonSchema};
use serde::{Deserialize, Serialize};
use serde_json::Value;
use std::sync::Arc;
use tokio::sync::mpsc;
use tokio_util::sync::CancellationToken;

pub static EXTENSION_NAME: &str = "Extension Manager";

#[derive(Debug, thiserror::Error)]
pub enum ExtensionManagerToolError {
    #[error("Unknown tool: {tool_name}")]
    UnknownTool { tool_name: String },

    #[error("Missing required parameter: {param_name}")]
    MissingParameter { param_name: String },

    #[error("Extension operation failed: {message}")]
    OperationFailed { message: String },

    #[error("Failed to deserialize parameters: {0}")]
    DeserializationError(#[from] serde_json::Error),
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize, JsonSchema)]
#[serde(rename_all = "lowercase")]
pub enum ManageExtensionAction {
    Enable,
    Disable,
}

#[derive(Debug, Clone, Serialize, Deserialize, JsonSchema)]
pub struct ManageExtensionsParams {
    pub action: ManageExtensionAction,
    pub extension_name: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, JsonSchema)]
pub struct ReadResourceParams {
    pub uri: String,
    pub extension_name: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, JsonSchema)]
pub struct ListResourcesParams {
    #[serde(skip_serializing_if = "Option::is_none")]
    pub extension_name: Option<String>,
}

pub const READ_RESOURCE_TOOL_NAME: &str = "read_resource";
pub const LIST_RESOURCES_TOOL_NAME: &str = "list_resources";
pub const SEARCH_AVAILABLE_EXTENSIONS_TOOL_NAME: &str = "search_available_extensions";
pub const MANAGE_EXTENSIONS_TOOL_NAME: &str = "manage_extensions";
pub const MANAGE_EXTENSIONS_TOOL_NAME_COMPLETE: &str = "extensionmanager__manage_extensions";

pub struct ExtensionManagerClient {
    info: InitializeResult,
    #[allow(dead_code)]
    context: PlatformExtensionContext,
}

impl ExtensionManagerClient {
    pub fn new(context: PlatformExtensionContext) -> Result<Self> {
        let info = InitializeResult::new(
            ServerCapabilities::builder().enable_tools().build(),
        )
        .with_server_info(Implementation::new(EXTENSION_NAME, "1.0.0").with_title(EXTENSION_NAME))
        .with_instructions(indoc! {r#"
            Extension Management

            Use these tools to discover, enable, and disable extensions, as well as review resources.

            Available tools:
            - search_available_extensions: Find extensions available to enable/disable
            - manage_extensions: Enable or disable extensions
            - list_resources: List resources from extensions
            - read_resource: Read specific resources from extensions

            When you lack the tools needed to complete a task, use search_available_extensions first
            to discover what extensions can help.

            Use manage_extensions to enable or disable specific extensions by name.
            Use list_resources and read_resource to work with extension data and resources.
        "#});

        Ok(Self { info, context })
    }

    fn handle_search_available_extensions(ctx: &ToolCallContext) -> Vec<ContentBlock> {
        let enabled: Vec<String> = ctx
            .extension_lease()
            .expect("platform tool calls are dispatched through a lease")
            .configs()
            .iter()
            .map(ExtensionConfig::key)
            .collect();
        vec![ContentBlock::text(search_available_extensions(&enabled))]
    }

    async fn handle_manage_extensions(
        &self,
        session_id: &str,
        arguments: Option<JsonObject>,
    ) -> Result<CallToolResult, ExtensionManagerToolError> {
        let arguments = arguments.ok_or(ExtensionManagerToolError::MissingParameter {
            param_name: "arguments".to_string(),
        })?;

        let params: ManageExtensionsParams =
            serde_json::from_value(serde_json::Value::Object(arguments))?;

        self.manage_extensions_impl(session_id, params.action, params.extension_name)
            .await
            .map_err(|error_data| ExtensionManagerToolError::OperationFailed {
                message: error_data.message.to_string(),
            })
    }

    async fn manage_extensions_impl(
        &self,
        session_id: &str,
        action: ManageExtensionAction,
        extension_name: String,
    ) -> Result<CallToolResult, ErrorData> {
        let session = self
            .context
            .session_manager
            .get_session(session_id, false)
            .await
            .map_err(|error| {
                ErrorData::new(
                    ErrorCode::INTERNAL_ERROR,
                    format!("Failed to get caller session: {error}"),
                    None,
                )
            })?;
        if session.session_type == SessionType::SubAgent {
            return Err(ErrorData::new(
                ErrorCode::INVALID_REQUEST,
                "Subagents cannot manage extensions".to_string(),
                None,
            ));
        }

        let (mutation, text) = match action {
            ManageExtensionAction::Disable => {
                if name_to_key(&extension_name) == "extensionmanager" {
                    return Err(ErrorData::new(
                        ErrorCode::INVALID_REQUEST,
                        "The Extension Manager cannot disable itself. Ask the user to disable it from goose settings instead.".to_string(),
                        None,
                    ));
                }
                (
                    ExtensionMutation::Disable {
                        name: extension_name.clone(),
                    },
                    format!(
                        "The extension '{}' has been disabled successfully",
                        extension_name
                    ),
                )
            }
            ManageExtensionAction::Enable => {
                if get_extension_by_name(&extension_name).is_none() {
                    return Err(ErrorData::new(
                        ErrorCode::RESOURCE_NOT_FOUND,
                        format!(
                            "Extension '{}' not found. Please check the extension name and try again.",
                            extension_name
                        ),
                        None,
                    ));
                }
                (
                    ExtensionMutation::Enable {
                        name: extension_name.clone(),
                    },
                    format!(
                        "The extension '{}' has been installed successfully",
                        extension_name
                    ),
                )
            }
        };
        let mut result = CallToolResult::success(vec![ContentBlock::text(text)]);
        mutation.attach(&mut result);
        Ok(result)
    }

    async fn handle_list_resources(
        &self,
        ctx: &ToolCallContext,
        arguments: Option<JsonObject>,
    ) -> Result<Vec<ContentBlock>, ExtensionManagerToolError> {
        let params = arguments.map(serde_json::Value::Object).unwrap_or_default();
        let result = ctx
            .extension_lease()
            .expect("platform tool calls are dispatched through a lease")
            .list_resources(params, CancellationToken::default())
            .await;
        result.map_err(|error| ExtensionManagerToolError::OperationFailed {
            message: format!("Failed to list resources: {}", error.message),
        })
    }

    async fn handle_read_resource(
        &self,
        ctx: &ToolCallContext,
        arguments: Option<JsonObject>,
    ) -> Result<Vec<ContentBlock>, ExtensionManagerToolError> {
        let params = arguments.map(serde_json::Value::Object).unwrap_or_default();
        let result = ctx
            .extension_lease()
            .expect("platform tool calls are dispatched through a lease")
            .read_resource_tool(params, CancellationToken::default())
            .await;
        result.map_err(|error| ExtensionManagerToolError::OperationFailed {
            message: format!("Failed to read resource: {}", error.message),
        })
    }

    #[allow(clippy::too_many_lines)]
    fn get_tools(&self, include_manage_extensions: bool) -> Vec<Tool> {
        let mut tools = vec![Tool::new(
                SEARCH_AVAILABLE_EXTENSIONS_TOOL_NAME.to_string(),
                "Searches for additional extensions available to help complete tasks.
        Use this tool when you're unable to find a specific feature or functionality you need to complete your task, or when standard approaches aren't working.
        These extensions might provide the exact tools needed to solve your problem.
        If you find a relevant one, consider using your tools to enable it.".to_string(),
                Arc::new(
                    serde_json::json!({
                        "type": "object",
                        "required": [],
                        "properties": {}
                    })
                    .as_object()
                    .expect("Schema must be an object")
                    .clone()
                ),
            ).annotate(ToolAnnotations::from_raw(
                Some("Discover extensions".to_string()),
                Some(true),
                Some(false),
                Some(false),
                Some(false),
            ))];

        if include_manage_extensions {
            tools.push(
                Tool::new(
                    MANAGE_EXTENSIONS_TOOL_NAME.to_string(),
                    "Tool to manage extensions and tools in goose context.
            Enable or disable extensions to help complete tasks.
            Enable or disable an extension by providing the extension name.
            "
                    .to_string(),
                    Arc::new(
                        serde_json::to_value(schema_for!(ManageExtensionsParams))
                            .expect("Failed to serialize schema")
                            .as_object()
                            .expect("Schema must be an object")
                            .clone(),
                    ),
                )
                .annotate(ToolAnnotations::from_raw(
                    Some("Enable or disable an extension".to_string()),
                    Some(false),
                    Some(false),
                    Some(false),
                    Some(false),
                )),
            );
        }

        tools.extend([
            Tool::new(
                LIST_RESOURCES_TOOL_NAME.to_string(),
                indoc! {r#"
            List resources from an extension(s).

            Resources allow extensions to share data that provide context to LLMs, such as
            files, database schemas, or application-specific information. This tool lists resources
            in the provided extension, and returns a list for the user to browse. If no extension
            is provided, the tool will search all extensions for the resource.
        "#}
                .to_string(),
                Arc::new(
                    serde_json::to_value(schema_for!(ListResourcesParams))
                        .expect("Failed to serialize schema")
                        .as_object()
                        .expect("Schema must be an object")
                        .clone(),
                ),
            )
            .annotate(ToolAnnotations::from_raw(
                Some("List resources".to_string()),
                Some(true),
                Some(false),
                Some(false),
                Some(false),
            )),
            Tool::new(
                READ_RESOURCE_TOOL_NAME.to_string(),
                indoc! {r#"
            Read a resource from a specific extension.

            Resources allow extensions to share data that provide context to LLMs, such as
            files, database schemas, or application-specific information. You must pass the
            owning extension as `extension_name`; if you don't know which extension owns a
            URI, call `list_resources` first — its output labels each resource with its
            extension.
        "#}
                .to_string(),
                Arc::new(
                    serde_json::to_value(schema_for!(ReadResourceParams))
                        .expect("Failed to serialize schema")
                        .as_object()
                        .expect("Schema must be an object")
                        .clone(),
                ),
            )
            .annotate(ToolAnnotations::from_raw(
                Some("Read a resource".to_string()),
                Some(true),
                Some(false),
                Some(false),
                Some(false),
            )),
        ]);

        tools
    }
}

#[async_trait]
impl McpClientTrait for ExtensionManagerClient {
    async fn list_resources(
        &self,
        _session_id: &str,
        _next_cursor: Option<String>,
        _cancellation_token: CancellationToken,
    ) -> Result<ListResourcesResult, Error> {
        Err(Error::TransportClosed)
    }

    async fn read_resource(
        &self,
        _session_id: &str,
        _uri: &str,
        _cancellation_token: CancellationToken,
    ) -> Result<ReadResourceResult, Error> {
        // Extension manager doesn't expose resources directly
        Err(Error::TransportClosed)
    }

    async fn list_tools(
        &self,
        session_id: &str,
        _next_cursor: Option<String>,
        _cancellation_token: CancellationToken,
    ) -> Result<ListToolsResult, Error> {
        let can_manage_extensions = self
            .context
            .session_manager
            .get_session(session_id, false)
            .await
            .is_ok_and(|session| session.session_type != SessionType::SubAgent);

        Ok(ListToolsResult {
            tools: self.get_tools(can_manage_extensions),
            next_cursor: None,
            meta: None,
            ..Default::default()
        })
    }

    async fn call_tool(
        &self,
        ctx: &ToolCallContext,
        name: &str,
        arguments: Option<JsonObject>,
        _cancellation_token: CancellationToken,
    ) -> Result<CallToolResult, Error> {
        let session_id = &ctx.session_id;
        let result = match name {
            SEARCH_AVAILABLE_EXTENSIONS_TOOL_NAME => {
                Ok(Self::handle_search_available_extensions(ctx))
            }
            MANAGE_EXTENSIONS_TOOL_NAME => {
                return Ok(self
                    .handle_manage_extensions(session_id, arguments)
                    .await
                    .unwrap_or_else(|error| {
                        CallToolResult::error(vec![ContentBlock::text(error.to_string())])
                    }));
            }
            LIST_RESOURCES_TOOL_NAME => self.handle_list_resources(ctx, arguments).await,
            READ_RESOURCE_TOOL_NAME => self.handle_read_resource(ctx, arguments).await,
            _ => Err(ExtensionManagerToolError::UnknownTool {
                tool_name: name.to_string(),
            }),
        };

        match result {
            Ok(content) => Ok(CallToolResult::success(content)),
            Err(error) => Ok(CallToolResult::error(vec![ContentBlock::text(
                error.to_string(),
            )])),
        }
    }

    async fn list_prompts(
        &self,
        _session_id: &str,
        _next_cursor: Option<String>,
        _cancellation_token: CancellationToken,
    ) -> Result<ListPromptsResult, Error> {
        Err(Error::TransportClosed)
    }

    async fn get_prompt(
        &self,
        _session_id: &str,
        _name: &str,
        _arguments: Value,
        _cancellation_token: CancellationToken,
    ) -> Result<GetPromptResult, Error> {
        Err(Error::TransportClosed)
    }

    async fn subscribe(&self) -> mpsc::Receiver<ServerNotification> {
        mpsc::channel(1).1
    }

    fn get_info(&self) -> Option<&InitializeResult> {
        Some(&self.info)
    }
}

fn search_available_extensions(enabled: &[String]) -> String {
    let disabled: Vec<String> = get_all_extensions()
        .into_iter()
        .filter(|extension| !extension.enabled && !is_hidden_extension(&extension.config.name()))
        .map(|extension| {
            let description = match &extension.config {
                ExtensionConfig::Builtin {
                    description,
                    display_name,
                    ..
                } if description.is_empty() => display_name
                    .as_deref()
                    .unwrap_or("Built-in extension")
                    .to_string(),
                ExtensionConfig::Builtin { description, .. }
                | ExtensionConfig::Platform { description, .. }
                | ExtensionConfig::StreamableHttp { description, .. }
                | ExtensionConfig::Stdio { description, .. } => description.clone(),
            };
            format!("- {} - {}", extension.config.name(), description)
        })
        .collect();
    let enabled: Vec<String> = enabled
        .iter()
        .filter(|name| !is_hidden_extension(name))
        .map(|name| format!("- {}", name))
        .collect();

    let mut output_parts = vec![];
    if disabled.is_empty() {
        output_parts.push("No extensions available to enable.\n".to_string());
    } else {
        output_parts.push(format!(
            "Extensions available to enable:\n{}\n",
            disabled.join("\n")
        ));
    }
    if enabled.is_empty() {
        output_parts.push("No extensions that can be disabled.\n".to_string());
    } else {
        output_parts.push(format!(
            "\n\nExtensions available to disable:\n{}\n",
            enabled.join("\n")
        ));
    }
    output_parts.join("\n")
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::agents::extension_manager::ExtensionManager;
    use crate::config::GooseMode;
    use std::path::PathBuf;

    fn client_for(manager: &Arc<ExtensionManager>) -> ExtensionManagerClient {
        ExtensionManagerClient::new(PlatformExtensionContext {
            extension_manager: None,
            providers: manager.get_context().providers.clone(),
            session_manager: manager.get_context().session_manager.clone(),
            scheduler: None,
        })
        .unwrap()
    }

    async fn create_session(manager: &ExtensionManager, session_type: SessionType) -> String {
        manager
            .get_context()
            .session_manager
            .create_session(
                PathBuf::from("/tmp/extension-manager-test"),
                "extension manager test".to_string(),
                session_type,
                GooseMode::default(),
            )
            .await
            .unwrap()
            .id
    }

    fn manage_arguments(action: &str) -> JsonObject {
        manage_arguments_for(action, "developer")
    }

    fn manage_arguments_for(action: &str, extension_name: &str) -> JsonObject {
        serde_json::json!({
            "action": action,
            "extension_name": extension_name,
        })
        .as_object()
        .unwrap()
        .clone()
    }

    async fn manage(
        client: &ExtensionManagerClient,
        session_id: &str,
        action: &str,
    ) -> CallToolResult {
        client
            .call_tool(
                &ToolCallContext::new(session_id.to_string(), None, None),
                MANAGE_EXTENSIONS_TOOL_NAME,
                Some(manage_arguments(action)),
                CancellationToken::default(),
            )
            .await
            .unwrap()
    }

    #[tokio::test]
    async fn manage_extensions_emits_a_mutation_and_refuses_subagents() {
        let temp_dir = tempfile::tempdir().unwrap();
        let manager = Arc::new(ExtensionManager::with_data_dir(
            temp_dir.path().to_path_buf(),
        ));
        let client = client_for(&manager);
        let user_id = create_session(&manager, SessionType::User).await;
        let subagent_id = create_session(&manager, SessionType::SubAgent).await;

        let mut enable = manage(&client, &subagent_id, "enable").await;
        assert!(enable.is_error.unwrap_or(false));
        assert_eq!(ExtensionMutation::take(&mut enable), None);

        let mut user_enable = manage(&client, &user_id, "enable").await;
        assert!(!user_enable.is_error.unwrap_or(false));
        assert_eq!(
            ExtensionMutation::take(&mut user_enable),
            Some(ExtensionMutation::Enable {
                name: "developer".to_string()
            })
        );
        assert!(
            user_enable.meta.is_none(),
            "the mutation is for the loop, not the model"
        );
        assert!(
            !manager
                .is_extension_enabled(&user_id, "developer")
                .await
                .unwrap(),
            "the tool declares the change; the loop applies it"
        );

        let mut user_disable = manage(&client, &user_id, "disable").await;
        assert_eq!(
            ExtensionMutation::take(&mut user_disable),
            Some(ExtensionMutation::Disable {
                name: "developer".to_string()
            })
        );
    }

    #[tokio::test]
    async fn extension_manager_cannot_disable_itself() {
        let temp_dir = tempfile::tempdir().unwrap();
        let manager = Arc::new(ExtensionManager::with_data_dir(
            temp_dir.path().to_path_buf(),
        ));
        let client = client_for(&manager);
        let user_id = create_session(&manager, SessionType::User).await;

        for name in [
            "Extension Manager",
            "extensionmanager",
            "Extension Manager ",
        ] {
            let result = client
                .call_tool(
                    &ToolCallContext::new(user_id.clone(), None, None),
                    MANAGE_EXTENSIONS_TOOL_NAME,
                    Some(manage_arguments_for("disable", name)),
                    CancellationToken::default(),
                )
                .await
                .unwrap();
            assert!(result.is_error.unwrap_or(false));
        }
    }

    #[tokio::test]
    async fn subagent_and_unknown_callers_are_not_offered_extension_management() {
        let temp_dir = tempfile::tempdir().unwrap();
        let manager = Arc::new(ExtensionManager::with_data_dir(
            temp_dir.path().to_path_buf(),
        ));
        let client = client_for(&manager);
        let user_id = create_session(&manager, SessionType::User).await;
        let subagent_id = create_session(&manager, SessionType::SubAgent).await;

        let user_tools = client
            .list_tools(&user_id, None, CancellationToken::default())
            .await
            .unwrap();
        assert!(user_tools
            .tools
            .iter()
            .any(|tool| tool.name == MANAGE_EXTENSIONS_TOOL_NAME));

        for session_id in [&subagent_id, "missing-session"] {
            let tools = client
                .list_tools(session_id, None, CancellationToken::default())
                .await
                .unwrap();
            assert!(tools
                .tools
                .iter()
                .any(|tool| tool.name == SEARCH_AVAILABLE_EXTENSIONS_TOOL_NAME));
            assert!(tools
                .tools
                .iter()
                .all(|tool| tool.name != MANAGE_EXTENSIONS_TOOL_NAME));
        }

        let unknown_enable = manage(&client, "missing-session", "enable").await;
        assert!(unknown_enable.is_error.unwrap_or(false));
        assert!(!manager
            .is_extension_enabled(&subagent_id, "developer")
            .await
            .unwrap());
    }
}
