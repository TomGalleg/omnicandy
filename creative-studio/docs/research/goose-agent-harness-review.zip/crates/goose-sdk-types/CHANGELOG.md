# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.0-alpha.12](https://github.com/aaif-goose/goose/compare/gdk-v0.1.0-alpha.11...gdk-v0.1.0-alpha.12) - 2026-10-13

### Other

- Remove Nostr session sharing from goose core ([#12453](https://github.com/aaif-goose/goose/pull/12453))

## [0.1.0-alpha.10](https://github.com/aaif-goose/goose/compare/gdk-v0.1.0-alpha.9...gdk-v0.1.0-alpha.10) - 2026-09-24

### Added

- add Live voice conversations to the desktop app ([#12093](https://github.com/aaif-goose/goose/pull/12093))
- *(acp)* scope Toolshim to custom providers ([#11414](https://github.com/aaif-goose/goose/pull/11414))

### Fixed

- *(acp)* bind MCP app tools to extension owners ([#11416](https://github.com/aaif-goose/goose/pull/11416))
