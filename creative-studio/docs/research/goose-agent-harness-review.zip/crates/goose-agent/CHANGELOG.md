# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.0-alpha.12](https://github.com/aaif-goose/goose/compare/gdk-v0.1.0-alpha.11...gdk-v0.1.0-alpha.12) - 2026-10-13

### Added

- surface provider x-request-id on responses and errors ([#12587](https://github.com/aaif-goose/goose/pull/12587))

### Other

- not infer or steer while a tool approval is pending ([#12808](https://github.com/aaif-goose/goose/pull/12808))
- changed yield_to_customer to next enum ([#12789](https://github.com/aaif-goose/goose/pull/12789))
- rename to finalize_cancellation and make Emitter sync ([#12786](https://github.com/aaif-goose/goose/pull/12786))
- agent loop: make Stop end the run promptly and save what it produced ([#12765](https://github.com/aaif-goose/goose/pull/12765))
- Delete the legacy agent loop ([#12760](https://github.com/aaif-goose/goose/pull/12760))
- Resolve extensions into a per-inference lease ([#12161](https://github.com/aaif-goose/goose/pull/12161))
- Run the GDK agent loop on wasm32 ([#12569](https://github.com/aaif-goose/goose/pull/12569))

## [0.1.0-alpha.11](https://github.com/aaif-goose/goose/compare/gdk-v0.1.0-alpha.10...gdk-v0.1.0-alpha.11) - 2026-09-28

### Other

- don't emit warning when ending on a successful tool call ([#12468](https://github.com/aaif-goose/goose/pull/12468))

## [0.1.0-alpha.10](https://github.com/aaif-goose/goose/compare/gdk-v0.1.0-alpha.9...gdk-v0.1.0-alpha.10) - 2026-09-24

### Fixed

- *(agents)* keep streamed thinking ahead of text and tool calls ([#11837](https://github.com/aaif-goose/goose/pull/11837))
- *(anthropic)* preserved-thinking compliance for the provider layer ([#11836](https://github.com/aaif-goose/goose/pull/11836))

## [0.1.0-alpha.9](https://github.com/aaif-goose/goose/compare/gdk-v0.1.0-alpha.8...gdk-v0.1.0-alpha.9) - 2026-09-08

### Other

- update Cargo.toml dependencies
