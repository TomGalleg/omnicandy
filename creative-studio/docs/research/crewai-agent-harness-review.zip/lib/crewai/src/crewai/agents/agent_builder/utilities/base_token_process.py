"""Token usage tracking utilities."""

from pydantic import BaseModel, Field

from crewai.types.usage_metrics import UsageMetrics


class TokenProcess(BaseModel):
    """Track token usage during agent processing."""

    total_tokens: int = Field(default=0)
    prompt_tokens: int = Field(default=0)
    cached_prompt_tokens: int = Field(default=0)
    completion_tokens: int = Field(default=0)
    successful_requests: int = Field(default=0)

    def sum_prompt_tokens(self, tokens: int) -> None:
        self.prompt_tokens += tokens
        self.total_tokens += tokens

    def sum_completion_tokens(self, tokens: int) -> None:
        self.completion_tokens += tokens
        self.total_tokens += tokens

    def sum_cached_prompt_tokens(self, tokens: int) -> None:
        self.cached_prompt_tokens += tokens

    def sum_successful_requests(self, requests: int) -> None:
        self.successful_requests += requests

    def get_summary(self) -> UsageMetrics:
        return UsageMetrics(
            total_tokens=self.total_tokens,
            prompt_tokens=self.prompt_tokens,
            cached_prompt_tokens=self.cached_prompt_tokens,
            completion_tokens=self.completion_tokens,
            successful_requests=self.successful_requests,
        )
