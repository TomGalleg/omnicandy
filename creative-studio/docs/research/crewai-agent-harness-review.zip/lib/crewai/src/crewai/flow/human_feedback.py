"""Human feedback support for Flow methods.

This module backs the @human_feedback decorator that enables human-in-the-loop
workflows within CrewAI Flows. The decorator is a pure metadata stamper: it
records a :class:`HumanFeedbackConfig` on the method, the Flow definition
builder lifts it into ``FlowHumanFeedbackDefinition``, and the Flow engine
collects feedback after each decorated method completes, driven by the flow's
definition.

Supports both synchronous (blocking) and asynchronous (non-blocking) feedback
collection through the provider parameter.

Example (synchronous, default):
    ```python
    from crewai.flow import Flow, start, listen, human_feedback


    class ReviewFlow(Flow):
        @start()
        @human_feedback(
            message="Please review this content:",
            emit=["approved", "rejected"],
            llm="gpt-5.4-mini",
        )
        def generate_content(self):
            return {"title": "Article", "body": "Content..."}

        @listen("approved")
        def publish(self):
            result = self.human_feedback
            print(f"Publishing: {result.output}")
    ```

Example (asynchronous with custom provider):
    ```python
    from crewai.flow import Flow, start, human_feedback
    from crewai.flow.async_feedback import HumanFeedbackProvider, HumanFeedbackPending


    class SlackProvider(HumanFeedbackProvider):
        def request_feedback(self, context, flow):
            self.send_notification(context)
            raise HumanFeedbackPending(context=context)


    class ReviewFlow(Flow):
        @start()
        @human_feedback(
            message="Review this:",
            emit=["approved", "rejected"],
            llm="gpt-5.4-mini",
            provider=SlackProvider(),
        )
        def generate_content(self):
            return "Content..."
    ```
"""

from __future__ import annotations

from collections.abc import Callable, Sequence
from dataclasses import dataclass, field
from datetime import datetime
import logging
from typing import TYPE_CHECKING, Any, TypeVar

from pydantic import BaseModel, Field, Secret, SecretBytes, SecretStr


if TYPE_CHECKING:
    from crewai.flow.async_feedback.types import HumanFeedbackProvider
    from crewai.flow.runtime import Flow
    from crewai.llms.base_llm import BaseLLM


logger = logging.getLogger(__name__)

F = TypeVar("F", bound=Callable[..., Any])
_StructuredT = TypeVar("_StructuredT", bound=BaseModel)

__all__ = ["HumanFeedbackCollapseError", "HumanFeedbackResult", "human_feedback"]


class HumanFeedbackCollapseError(ValueError):
    """Raised when human feedback cannot be mapped to an emit outcome."""


def _match_collapse_outcome(response_text: str, outcomes: Sequence[str]) -> str | None:
    """Return the emit label that best matches ``response_text``, or None."""
    response_clean = response_text.strip()
    for outcome in outcomes:
        if outcome.lower() == response_clean.lower():
            return outcome
    response_lower = response_clean.lower()
    best_outcome: str | None = None
    best_len = -1
    for outcome in outcomes:
        if outcome.lower() in response_lower and len(outcome) > best_len:
            best_outcome = outcome
            best_len = len(outcome)
    return best_outcome


def _require_collapse_outcome(response_text: str, outcomes: Sequence[str]) -> str:
    matched = _match_collapse_outcome(response_text, outcomes)
    if matched is None:
        raise HumanFeedbackCollapseError(
            f"Could not match LLM response {response_text!r} to outcomes "
            f"{list(outcomes)}."
        )
    return matched


def _serialize_llm_for_context(llm: Any) -> dict[str, Any] | str | None:
    to_config: Callable[[], dict[str, Any]] | None = getattr(
        llm, "to_config_dict", None
    )
    if to_config is not None:
        return to_config()

    # Fallback for non-BaseLLM objects: just extract model + provider prefix
    model = getattr(llm, "model", None)
    if not model:
        return None
    provider = getattr(llm, "provider", None)
    return f"{provider}/{model}" if provider and "/" not in model else model


def _deserialize_llm_from_context(
    llm_data: dict[str, Any] | str | None,
) -> BaseLLM | None:
    if llm_data is None:
        return None

    from crewai.llm import LLM

    if isinstance(llm_data, str):
        return LLM(model=llm_data)

    if isinstance(llm_data, dict):
        data = dict(llm_data)
        model = data.pop("model", None)
        if not model:
            return None
        return LLM(model=model, **data)
    return None


@dataclass
class HumanFeedbackResult:
    """Result from a @human_feedback decorated method.

    This dataclass captures all information about a human feedback interaction,
    including the original method output, the human's feedback, and any
    collapsed outcome for routing purposes.

    Attributes:
        output: The output shown to the human for review: the decorated
            method's return value or, with ``learn=True``, that value after
            past lessons were applied (same type). Downstream steps should read
            the approved output from here, not from state the method set. After
            a flow pauses for async feedback and resumes, the pending review is
            restored from JSON, so a Pydantic output arrives as a ``dict``.
        feedback: The raw text feedback provided by the human. Empty string
            if no feedback was provided.
        outcome: The collapsed outcome string when emit is specified.
            This is determined by the LLM based on the human's feedback.
            None if emit was not specified.
        timestamp: When the feedback was received.
        method_name: The name of the decorated method that triggered feedback.
        metadata: Optional metadata for enterprise integrations. Can be used
            to pass additional context like channel, assignee, etc.

    Example:
        ```python
        @listen("approved")
        def handle_approval(self):
            result = self.human_feedback
            print(f"Output: {result.output}")
            print(f"Feedback: {result.feedback}")
            print(f"Outcome: {result.outcome}")  # "approved"
        ```
    """

    output: Any
    feedback: str
    outcome: str | None = None
    timestamp: datetime = field(default_factory=datetime.now)
    method_name: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class HumanFeedbackConfig:
    """Configuration for the @human_feedback decorator.

    Stores the parameters passed to the decorator for later use by the
    Flow definition builder and for introspection by visualization tools.

    Attributes:
        message: The message shown to the human when requesting feedback.
        emit: Optional sequence of outcome strings for routing.
        llm: The LLM used to collapse feedback to an emit outcome.
            None means resolve at runtime via create_llm (decorator
            value, then MODEL / MODEL_NAME / OPENAI_MODEL_NAME, then
            DEFAULT_LLM_MODEL).
        default_outcome: The outcome to use when no feedback is provided.
        metadata: Optional metadata for enterprise integrations.
        provider: Optional custom feedback provider for async workflows.
    """

    message: str
    emit: Sequence[str] | None = None
    llm: str | BaseLLM | None = None
    default_outcome: str | None = None
    metadata: dict[str, Any] | None = None
    provider: HumanFeedbackProvider | None = None
    learn: bool = False
    learn_source: str = "hitl"
    learn_strict: bool = False


class PreReviewResult(BaseModel):
    """Structured output from the HITL pre-review LLM call."""

    improved_output: str = Field(
        description="The improved version of the output with past human feedback lessons applied.",
    )


class DistilledLessons(BaseModel):
    """Structured output from the HITL lesson distillation LLM call."""

    lessons: list[str] = Field(
        default_factory=list,
        description=(
            "Generalizable lessons extracted from the human feedback. "
            "Each lesson should be a reusable rule or preference. "
            "Return an empty list if the feedback contains no generalizable guidance."
        ),
    )


def _validate_human_feedback_options(
    emit: Sequence[str] | None,
    default_outcome: str | None,
) -> None:
    if emit is not None:
        if default_outcome is not None and default_outcome not in emit:
            raise ValueError(
                f"default_outcome '{default_outcome}' must be one of the "
                f"emit options: {list(emit)}"
            )
    elif default_outcome is not None:
        raise ValueError("default_outcome requires emit to be specified.")


def _get_hitl_prompt(key: str) -> str:
    from crewai.utilities.i18n import I18N_DEFAULT

    return I18N_DEFAULT.slice(key)


def _resolve_llm_instance(llm: Any) -> Any:
    """Resolve a collapse/learn LLM the same way agents resolve theirs.

    Explicit decorator values win. ``None`` follows ``create_llm``:
    ``MODEL`` / ``MODEL_NAME`` / ``OPENAI_MODEL_NAME``, then
    ``DEFAULT_LLM_MODEL``.
    """
    from crewai.llm import LLM
    from crewai.utilities.llm_utils import create_llm

    if llm is None:
        return create_llm(None)
    if isinstance(llm, str):
        return LLM(model=llm)
    if isinstance(llm, dict):
        deserialized = _deserialize_llm_from_context(llm)
        return deserialized if deserialized is not None else create_llm(None)
    return llm


def _as_structured(response: Any, model_type: type[_StructuredT]) -> _StructuredT:
    if isinstance(response, model_type):
        return response
    if isinstance(response, str):
        # LiteLLM-routed models return structured output as a JSON string.
        return model_type.model_validate_json(response)
    return model_type.model_validate(response)


def _has_hidden_values(value: Any) -> bool:
    if isinstance(value, (Secret, SecretStr, SecretBytes)):
        return True
    if isinstance(value, BaseModel):
        private = value.__pydantic_private__ or {}
        # A rebuilt model starts private attributes from their defaults, so any
        # private value that differs from its default would be lost.
        if any(
            private[name] != attr.get_default()
            for name, attr in type(value).__private_attributes__.items()
            if name in private
        ):
            return True
        return any(
            info.exclude or _has_hidden_values(getattr(value, name))
            for name, info in type(value).model_fields.items()
        )
    if isinstance(value, dict):
        return any(_has_hidden_values(item) for item in value.values())
    if isinstance(value, (list, tuple, set, frozenset)):
        return any(_has_hidden_values(item) for item in value)
    return False


def _pre_review_with_lessons(
    flow_instance: Flow[Any],
    method_name: str,
    method_output: Any,
    *,
    llm: Any,
    learn_source: str,
    learn_strict: bool,
) -> Any:
    from crewai.hooks.dispatch import HookAborted

    try:
        # Only text and Pydantic outputs can be rewritten without changing their
        # type, and a model only when the LLM sees all of it: secrets are masked,
        # excluded fields and private attributes dropped, so rebuilding from the
        # review would lose them. Anything else reaches the reviewer unchanged.
        if isinstance(method_output, BaseModel):
            if _has_hidden_values(method_output):
                return method_output
            rendered = method_output.model_dump_json()
        elif isinstance(method_output, str):
            rendered = method_output
        else:
            return method_output

        mem = flow_instance.memory
        if mem is None:
            return method_output
        query = f"human feedback lessons for {method_name}: {rendered}"
        matches = mem.recall(query, source=learn_source)
        if not matches:
            return method_output

        lessons = "\n".join(f"- {m.record.content}" for m in matches)
        llm_inst = _resolve_llm_instance(llm)
        prompt = _get_hitl_prompt("hitl_pre_review_user").format(
            output=rendered,
            lessons=lessons,
        )
        messages = [
            {
                "role": "system",
                "content": _get_hitl_prompt("hitl_pre_review_system"),
            },
            {"role": "user", "content": prompt},
        ]
        if isinstance(method_output, BaseModel):
            output_type = type(method_output)
            return _as_structured(
                llm_inst.call(messages, response_model=output_type), output_type
            )
        if getattr(llm_inst, "supports_function_calling", lambda: False)():
            response = llm_inst.call(messages, response_model=PreReviewResult)
            return _as_structured(response, PreReviewResult).improved_output
        reviewed = llm_inst.call(messages)
        return reviewed if isinstance(reviewed, str) else str(reviewed)
    except HookAborted:
        raise
    except Exception:
        if learn_strict:
            logger.warning(
                "HITL pre-review failed for %s; re-raising (learn_strict=True)",
                method_name,
                exc_info=True,
            )
            raise
        logger.warning(
            "HITL pre-review failed for %s; falling back to raw output",
            method_name,
            exc_info=True,
        )
        return method_output


def _distill_and_store_lessons(
    flow_instance: Flow[Any],
    method_name: str,
    method_output: Any,
    raw_feedback: str,
    *,
    llm: Any,
    learn_source: str,
    learn_strict: bool,
) -> None:
    from crewai.hooks.dispatch import HookAborted

    try:
        mem = flow_instance.memory
        if mem is None:
            return
        llm_inst = _resolve_llm_instance(llm)
        prompt = _get_hitl_prompt("hitl_distill_user").format(
            method_name=method_name,
            output=str(method_output),
            feedback=raw_feedback,
        )
        messages = [
            {
                "role": "system",
                "content": _get_hitl_prompt("hitl_distill_system"),
            },
            {"role": "user", "content": prompt},
        ]

        lessons: list[str] = []
        if getattr(llm_inst, "supports_function_calling", lambda: False)():
            response = llm_inst.call(messages, response_model=DistilledLessons)
            lessons = _as_structured(response, DistilledLessons).lessons
        else:
            response = llm_inst.call(messages)
            if isinstance(response, str):
                lessons = [
                    line.strip("- ").strip()
                    for line in response.strip().split("\n")
                    if line.strip() and line.strip() != "NONE"
                ]

        if lessons:
            mem.remember_many(lessons, source=learn_source)  # type: ignore[union-attr]
    except HookAborted:
        raise
    except Exception:
        if learn_strict:
            logger.warning(
                "HITL lesson distillation failed for %s; re-raising (learn_strict=True)",
                method_name,
                exc_info=True,
            )
            raise
        logger.warning(
            "HITL lesson distillation failed for %s; no lessons stored",
            method_name,
            exc_info=True,
        )


def human_feedback(
    message: str,
    emit: Sequence[str] | None = None,
    llm: str | BaseLLM | None = None,
    default_outcome: str | None = None,
    metadata: dict[str, Any] | None = None,
    provider: HumanFeedbackProvider | None = None,
    learn: bool = False,
    learn_source: str = "hitl",
    learn_strict: bool = False,
) -> Callable[[F], F]:
    """Compatibility import path for the Flow human-feedback DSL decorator."""
    from crewai.flow.dsl._human_feedback import human_feedback as dsl_human_feedback

    return dsl_human_feedback(
        message=message,
        emit=emit,
        llm=llm,
        default_outcome=default_outcome,
        metadata=metadata,
        provider=provider,
        learn=learn,
        learn_source=learn_source,
        learn_strict=learn_strict,
    )
