"""Exceptions for crewAI."""
