"""Flow Runtime: the engine that executes a Flow.

Provides the ``Flow`` class (kickoff/resume/listener dispatch) and the
``FlowMeta`` metaclass. Flows authored with the Python DSL (see ``dsl``)
are described by a Flow
Structure (see ``flow_definition``) and executed here.
"""

from __future__ import annotations

import asyncio
from collections.abc import Callable, Iterator, Sequence
from concurrent.futures import Future, ThreadPoolExecutor
import contextvars
import copy
from datetime import datetime, timezone
import enum
import inspect
import logging
from pathlib import Path
import threading
from typing import (
    TYPE_CHECKING,
    Annotated,
    Any,
    ClassVar,
    Generic,
    Literal,
    ParamSpec,
    TypeVar,
    cast,
)
from uuid import uuid4

from opentelemetry import baggage
from opentelemetry.context import attach, detach
from pydantic import (
    BaseModel,
    BeforeValidator,
    ConfigDict,
    Field,
    PlainSerializer,
    PrivateAttr,
    SerializeAsAny,
    ValidationError,
)
from pydantic._internal._model_construction import ModelMetaclass
from rich.console import Console
from rich.panel import Panel

from crewai.events.base_events import reset_emission_counter
from crewai.events.event_bus import crewai_event_bus
from crewai.events.event_context import (
    get_current_parent_id,
    reset_last_event_id,
    restore_event_scope,
    triggered_by_scope,
)
from crewai.events.listeners.tracing.trace_listener import (
    TraceCollectionListener,
)
from crewai.events.listeners.tracing.utils import (
    has_user_declined_tracing,
    set_tracing_enabled,
    should_enable_tracing,
    should_suppress_tracing_messages,
)
from crewai.events.types.flow_events import (
    FlowCreatedEvent,
    FlowFailedEvent,
    FlowFinishedEvent,
    FlowPausedEvent,
    FlowPlotEvent,
    FlowStartedEvent,
    MethodExecutionFailedEvent,
    MethodExecutionFinishedEvent,
    MethodExecutionPausedEvent,
    MethodExecutionStartedEvent,
)
from crewai.events.types.llm_events import LLMCallCompletedEvent
from crewai.execution import (
    ExecutionTrace,
    begin_execution,
    end_execution,
    get_execution_uuid,
)
from crewai.flow.async_feedback.types import (
    HumanFeedbackPending,
    HumanFeedbackProvider,
    PendingFeedbackContext,
)
from crewai.flow.dsl._utils import build_flow_definition
from crewai.flow.flow_context import (
    current_flow_defer_trace_finalization,
    current_flow_id,
    current_flow_name,
    current_flow_request_id,
)
from crewai.flow.flow_definition import (
    FlowDefinition,
    FlowDefinitionCondition,
    FlowHumanFeedbackDefinition,
    FlowMethodDefinition,
    FlowPersistenceDefinition,
    FlowStateDefinition,
)
from crewai.flow.flow_wrappers import (
    FlowMethod,
    ListenMethod,
    RouterMethod,
    StartMethod,
)
from crewai.flow.human_feedback import (
    HumanFeedbackCollapseError,
    HumanFeedbackResult,
    _distill_and_store_lessons,
    _pre_review_with_lessons,
    _require_collapse_outcome,
    _resolve_llm_instance,
    _serialize_llm_for_context,
)
from crewai.flow.input_provider import InputProvider
from crewai.flow.persistence.base import FlowPersistence
from crewai.flow.runtime._actions import FlowScriptExecutionDisabledError, build_action
from crewai.flow.types import (
    FlowExecutionData,
    FlowMethodName,
    InputHistoryEntry,
    PendingListenerKey,
)
from crewai.memory.memory_scope import MemoryScope, MemorySlice, _ensure_memory_kind
from crewai.memory.unified_memory import Memory
from crewai.state.checkpoint_config import (
    CheckpointConfig,
    _coerce_checkpoint,
    apply_checkpoint,
)
from crewai.telemetry.tracing.context import get_trace_session
from crewai.utilities.declarative_refs import InvalidRefError, resolve_ref


if TYPE_CHECKING:
    from crewai_files import FileInput

    from crewai.context import ExecutionContext
    from crewai.hooks.contexts import InterceptionContext
    from crewai.hooks.dispatch import InterceptionPoint
    from crewai.llms.base_llm import BaseLLM

from crewai.flow.visualization import build_flow_structure, render_interactive
from crewai.types.streaming import (
    AsyncStreamSession,
    StreamSession,
)
from crewai.types.usage_metrics import UsageMetrics
from crewai.utilities.env import get_env_context
from crewai.utilities.streaming import (
    create_async_frame_generator,
    create_frame_generator,
    create_frame_streaming_state,
)


# Runtime alias so Pydantic can resolve the ``execution_context`` field's
# annotation in subclass modules without those modules needing to import
# ``crewai.context.ExecutionContext`` themselves. The real class is brought
# in under ``TYPE_CHECKING`` above for static analysis. We can't import it at
# runtime because ``crewai.context`` is loaded mid-initialization when this
# module is imported through ``crewai.__init__`` (circular).
ExecutionContext = Any  # type: ignore[assignment,misc]


logger = logging.getLogger(__name__)


def _condition_branches(
    condition: dict[str, Any],
) -> tuple[Literal["and", "or"], list[FlowDefinitionCondition]]:
    if "and" in condition:
        return "and", condition["and"]
    return "or", condition["or"]


def _condition_satisfied(condition: FlowDefinitionCondition, events: set[str]) -> bool:
    if isinstance(condition, str):
        return condition in events
    operator, branches = _condition_branches(condition)
    combine = all if operator == "and" else any
    return combine(_condition_satisfied(branch, events) for branch in branches)


def _build_definition_state_model(
    state_definition: FlowStateDefinition,
    compose: Callable[[type[BaseModel]], type[BaseModel]] | None = None,
) -> BaseModel | None:
    kwargs = dict(state_definition.default or {})

    model_class: type[BaseModel] | None = None
    state_ref = getattr(state_definition, "ref", None)
    if state_ref:
        try:
            resolved: Any = resolve_ref(state_ref, field="state")
        except Exception:
            logger.warning("Could not import state ref %r", state_ref, exc_info=True)
        else:
            if isinstance(resolved, type) and issubclass(resolved, BaseModel):
                model_class = resolved
            else:
                logger.warning("State ref %r is not a pydantic model", state_ref)

    json_schema = getattr(state_definition, "json_schema", None)
    if model_class is None and json_schema:
        from crewai.utilities.pydantic_schema_utils import create_model_from_schema

        try:
            model_class = create_model_from_schema(json_schema)
        except Exception:
            logger.warning(
                "Could not build a state model from the declared json_schema",
                exc_info=True,
            )

    if model_class is None:
        return None

    if compose is not None:
        model_class = compose(model_class)

    if not issubclass(model_class, FlowState):

        class StateWithId(FlowState, model_class):  # type: ignore[misc, valid-type]
            pass

        model_class = StateWithId
    try:
        return model_class(**kwargs)
    except ValidationError as e:
        if any(error.get("type") != "missing" for error in e.errors()):
            raise
        return model_class.model_construct(**kwargs)


def _iter_condition_events(condition: FlowDefinitionCondition) -> Iterator[str]:
    if isinstance(condition, str):
        yield condition
        return

    _, branches = _condition_branches(condition)
    for branch in branches:
        yield from _iter_condition_events(branch)


def _or_alternative_events(condition: FlowDefinitionCondition) -> Iterator[str]:
    if isinstance(condition, str):
        yield condition
        return

    operator, branches = _condition_branches(condition)
    if operator != "or":
        return
    for branch in branches:
        yield from _or_alternative_events(branch)


def _is_multi_event_or(
    condition: FlowDefinitionCondition,
) -> bool:
    if isinstance(condition, str):
        return False

    operator, branches = _condition_branches(condition)
    return operator == "or" and len(branches) > 1


def _usage_dict_to_metrics(usage: dict[str, Any] | None) -> UsageMetrics | None:
    """Normalize an LLM call's raw usage dict into ``UsageMetrics``.

    Thin wrapper around ``UsageMetrics.from_provider_dict`` so the flow
    aggregator and ``BaseLLM._track_token_usage_internal`` agree on the
    set of provider key aliases (LiteLLM, Anthropic, Gemini).
    """
    return UsageMetrics.from_provider_dict(usage)


def _resolve_persistence(value: Any) -> Any:
    if value is None or isinstance(value, FlowPersistence):
        return value
    if isinstance(value, dict):
        from crewai.flow.persistence.base import _persistence_registry

        cls = _persistence_registry.get(value.get("persistence_type", ""))
        if cls is not None:
            return cls.model_validate(value)
    return value


def _resolve_instance_ref(ref: str, *, field: str) -> Any:
    target = resolve_ref(ref, field=field)
    if not inspect.isclass(target):
        return target
    try:
        return target()
    except Exception as e:
        raise InvalidRefError(
            f"cannot instantiate {field} ref {ref!r} without arguments: {e}"
        ) from e


def _serialize_persistence(value: Any) -> dict[str, Any] | None:
    if value is None:
        return None
    if isinstance(value, FlowPersistence):
        return value.model_dump(mode="json")
    raise TypeError(
        f"Cannot serialize Flow.persistence of type {type(value).__name__}: "
        "expected FlowPersistence or None."
    )


def _validate_input_provider(value: Any) -> Any:
    if value is None or isinstance(value, InputProvider):
        return value
    if isinstance(value, str) and ":" in value:
        resolved = _resolve_instance_ref(value, field="input_provider")
    else:
        from crewai.types.callback import _dotted_path_to_instance

        resolved = _dotted_path_to_instance(value)
    if resolved is None or isinstance(resolved, InputProvider):
        return resolved
    raise ValueError(
        f"Resolved input_provider {resolved!r} does not implement the "
        "InputProvider protocol (missing request_input)."
    )


def _serialize_input_provider(value: Any) -> str | None:
    if value is None:
        return None
    from crewai.types.callback import _instance_to_dotted_path

    return _instance_to_dotted_path(value)


_INITIAL_STATE_CLASS_MARKER = "__crewai_pydantic_class_schema__"


def _serialize_initial_state(value: Any) -> Any:
    """Make ``initial_state`` safe for JSON checkpoint serialization.

    ``BaseModel`` class refs are emitted as their JSON schema under a sentinel
    marker key so deserialization can round-trip them back to a class.
    ``BaseModel`` instances are dumped to JSON (round-trip as plain dicts,
    which ``_create_initial_state`` accepts). Bare ``type`` values that are
    not ``BaseModel`` subclasses (e.g. ``dict``) are dropped since they
    can't be represented in JSON.
    """
    if isinstance(value, type):
        if issubclass(value, BaseModel):
            return {_INITIAL_STATE_CLASS_MARKER: value.model_json_schema()}
        return None
    if isinstance(value, BaseModel):
        return value.model_dump(mode="json")
    return value


def _deserialize_initial_state(value: Any) -> Any:
    """Rehydrate a class ref serialized by :func:`_serialize_initial_state`."""
    if isinstance(value, dict) and _INITIAL_STATE_CLASS_MARKER in value:
        from crewai.utilities.pydantic_schema_utils import create_model_from_schema

        return create_model_from_schema(value[_INITIAL_STATE_CLASS_MARKER])
    return value


class FlowState(BaseModel):
    """Base model for all flow states, ensuring each state has a unique ID."""

    id: str = Field(
        default_factory=lambda: str(uuid4()),
        description="Unique identifier for the flow state",
    )


T = TypeVar("T", bound=dict[str, Any] | BaseModel)
P = ParamSpec("P")
R = TypeVar("R")
F = TypeVar("F", bound=Callable[..., Any])


class FlowMeta(ModelMetaclass):
    def __new__(
        mcs,
        name: str,
        bases: tuple[type, ...],
        namespace: dict[str, Any],
        **kwargs: Any,
    ) -> type:
        parent_fields: set[str] = set()
        for base in bases:
            if hasattr(base, "model_fields"):
                parent_fields.update(base.model_fields)

        annotations = namespace.get("__annotations__", {})
        _skip_types = (classmethod, staticmethod, property)

        for base in bases:
            if isinstance(base, ModelMetaclass):
                continue
            for attr_name in getattr(base, "__annotations__", {}):
                if attr_name not in annotations and attr_name not in namespace:
                    annotations[attr_name] = ClassVar

        for attr_name, attr_value in namespace.items():
            if isinstance(attr_value, property) and attr_name not in annotations:
                for base in bases:
                    base_ann = getattr(base, "__annotations__", {})
                    if attr_name in base_ann:
                        annotations[attr_name] = ClassVar

        for attr_name, attr_value in list(namespace.items()):
            if attr_name in annotations or attr_name.startswith("_"):
                continue
            if attr_name in parent_fields:
                annotations[attr_name] = Any
                if isinstance(attr_value, BaseModel):
                    namespace[attr_name] = Field(
                        default_factory=lambda v=attr_value: v, exclude=True
                    )
                continue
            if callable(attr_value) or isinstance(
                attr_value, (*_skip_types, FlowMethod)
            ):
                continue
            annotations[attr_name] = ClassVar[type(attr_value)]
        namespace["__annotations__"] = annotations

        # The static FlowDefinition is built lazily (on first access via
        # ``Flow.flow_definition()`` or visualization), not at class-definition
        # time, to avoid AST parsing and diagnostic logging on every import.
        return super().__new__(mcs, name, bases, namespace)


class Flow(BaseModel, Generic[T], metaclass=FlowMeta):
    """Base class for all flows.

    type parameter T must be either dict[str, Any] or a subclass of BaseModel."""

    model_config = ConfigDict(
        arbitrary_types_allowed=True,
        ignored_types=(StartMethod, ListenMethod, RouterMethod),
        revalidate_instances="never",
    )
    __hash__ = object.__hash__

    _flow_definition: ClassVar[FlowDefinition | None] = None

    entity_type: Literal["flow"] = "flow"

    def _initialize_runtime_extension_attrs(self) -> None:
        """Initialize optional runtime-extension attributes."""

    def _extend_definition(self, definition: FlowDefinition) -> FlowDefinition:
        """Let an optional runtime extension complete the definition.

        Runs once ``_definition`` is resolved and before methods are bound, so
        an extension can contribute the methods it owns.
        """
        return definition

    def _create_default_extension_state(
        self, *, ignore_declared_state: bool = False
    ) -> Any | None:
        """Return a default state supplied by an optional runtime extension.

        ``ignore_declared_state`` is set when a declared ``state:`` block named
        a model that could not be built, so the extension is asked again as if
        nothing had been declared.
        """
        return None

    def _compose_extension_state_model(
        self, model_class: type[BaseModel]
    ) -> type[BaseModel]:
        """Let an optional runtime extension add bases to a declared state model.

        Applied to the model built from ``state:`` before the engine wraps it
        for its ``id`` field, so an extension can require its own fields
        alongside whatever the declaration asked for.
        """
        return model_class

    def _should_apply_pending_kickoff_context(self) -> bool:
        """Whether an optional runtime extension has pending kickoff context."""
        return False

    def _apply_pending_kickoff_context(self) -> None:
        """Apply optional runtime-extension kickoff context."""

    def _order_start_methods_for_kickoff(
        self,
        start_methods: list[FlowMethodName],
    ) -> tuple[list[FlowMethodName], bool]:
        """Allow an optional runtime extension to order kickoff start methods."""
        return start_methods, False

    def _should_defer_trace_finalization(self) -> bool:
        """Whether this kickoff should defer final flow trace finalization."""
        return bool(getattr(self, "defer_trace_finalization", False))

    def _begin_trace_execution(
        self, execution_uuid: str | None = None
    ) -> contextvars.Token[str | None] | None:
        previous = self._deferred_execution_trace
        token = begin_execution(
            execution_uuid, tracing=self.tracing, trace_session=previous
        )
        if token is not None and get_trace_session() is not (
            previous.session if previous else None
        ):
            # A tracing toggle starts a fresh lifecycle; the old opener belongs
            # to the previous session (or to an untraced turn).
            object.__setattr__(self, "_deferred_flow_started_event_id", None)
        return token

    def _end_trace_execution(self, token: contextvars.Token[str | None] | None) -> None:
        if token is None:
            return
        owned_trace = get_trace_session() is not None
        defer = self._should_defer_trace_finalization()
        self._deferred_execution_trace = end_execution(token, defer=defer)
        if owned_trace and defer and self._deferred_execution_trace is None:
            object.__setattr__(self, "_deferred_flow_started_event_id", None)

    @classmethod
    def flow_definition(cls) -> FlowDefinition:
        """Return the static Flow Definition built from this Flow class."""
        flow_definition = cls.__dict__.get("_flow_definition")
        if flow_definition is None:
            flow_definition = build_flow_definition(cls)
            cls._flow_definition = flow_definition
        return flow_definition

    @classmethod
    def from_declaration(
        cls,
        *,
        contents: FlowDefinition | str | dict[str, Any] | None = None,
        path: Path | str | None = None,
        **kwargs: Any,
    ) -> Flow[Any]:
        """Build a runnable declarative flow from contents or a file path."""
        definition = FlowDefinition.from_declaration(
            contents=contents,
            path=path,
        )
        return cls.model_validate(
            {**definition.config.model_dump(), **kwargs},
            context={"flow_definition": definition},
        )

    def _start_method_names(self) -> list[FlowMethodName]:
        return [
            FlowMethodName(method_name)
            for method_name, method_definition in self._definition.methods.items()
            if method_definition.is_start
        ]

    def _listener_methods(
        self,
    ) -> Iterator[tuple[FlowMethodName, FlowMethodDefinition, FlowDefinitionCondition]]:
        # (name, definition, condition) for every method that listens, start
        # methods included: `start: true` plus `listen` runs at kickoff and again
        # on each listen event (e.g. a review step re-drafting on request_changes).
        # Routers are included (they listen too); callers wanting only plain
        # listeners filter on definition.router.
        for method_name, method_definition in self._definition.methods.items():
            if method_definition.listen is not None:
                yield (
                    FlowMethodName(method_name),
                    method_definition,
                    method_definition.listen,
                )

    def _start_condition(
        self, method_name: FlowMethodName
    ) -> FlowDefinitionCondition | None:
        method_definition = self._definition.methods[str(method_name)]
        start = method_definition.start
        if isinstance(start, (str, dict)):
            return start
        return None

    def _listen_condition(
        self, method_name: FlowMethodName
    ) -> FlowDefinitionCondition | None:
        return self._definition.methods[str(method_name)].listen

    def _is_router(self, method_name: FlowMethodName) -> bool:
        return self._definition.methods[str(method_name)].router

    initial_state: Annotated[  # type: ignore[type-arg]
        type[BaseModel] | type[dict] | dict[str, Any] | BaseModel | None,
        BeforeValidator(_deserialize_initial_state),
        PlainSerializer(_serialize_initial_state, return_type=Any, when_used="json"),
    ] = Field(default=None)
    name: str | None = Field(default=None)
    tracing: bool | None = Field(default=None)
    stream: bool = Field(default=False)
    memory: Annotated[
        Annotated[
            Memory | MemoryScope | MemorySlice, Field(discriminator="memory_kind")
        ]
        | None,
        BeforeValidator(_ensure_memory_kind),
    ] = Field(default=None)
    input_provider: Annotated[
        InputProvider | None,
        BeforeValidator(_validate_input_provider),
        PlainSerializer(
            _serialize_input_provider, return_type=str | None, when_used="json"
        ),
    ] = Field(default=None)
    suppress_flow_events: bool = Field(default=False)
    defer_trace_finalization: bool = Field(
        default=False,
        description=(
            "When True, skip per-kickoff ``FlowFinishedEvent`` + trace-batch "
            "finalization. ``finalize_session_traces()`` does the final emit "
            "+ finalize. Use for multi-turn chat sessions where every "
            "``handle_turn()`` is a turn within one logical trace."
        ),
    )
    human_feedback_history: list[HumanFeedbackResult] = Field(default_factory=list)
    last_human_feedback: HumanFeedbackResult | None = Field(default=None)

    persistence: Annotated[
        SerializeAsAny[FlowPersistence] | None,
        BeforeValidator(lambda v, _: _resolve_persistence(v)),
        PlainSerializer(
            _serialize_persistence, return_type=dict | None, when_used="json"
        ),
    ] = Field(default=None)
    max_method_calls: int = Field(default=100)

    execution_context: ExecutionContext | None = Field(default=None)
    checkpoint: Annotated[
        CheckpointConfig | bool | None,
        BeforeValidator(_coerce_checkpoint),
    ] = Field(default=None)

    @classmethod
    def from_checkpoint(
        cls,
        config: CheckpointConfig,
        *,
        definition: FlowDefinition | None = None,
    ) -> Flow:  # type: ignore[type-arg]
        """Restore a Flow from a checkpoint.

        Args:
            config: Checkpoint configuration with ``restore_from`` set to
                the path of the checkpoint to load.
            definition: The FlowDefinition to restore a definition-built flow
                (one created via ``Flow.from_declaration``) from; its actions
                are re-resolved since checkpoints carry no callables.
                Subclasses carry their own definition and don't need this.

        Returns:
            A Flow instance ready to resume.
        """
        from crewai.context import apply_execution_context
        from crewai.events.event_bus import crewai_event_bus
        from crewai.state.runtime import RuntimeState

        context: dict[str, Any] = {"from_checkpoint": True}
        if definition is not None:
            context["flow_definition"] = definition
        state = RuntimeState.from_checkpoint(config, context=context)
        crewai_event_bus.set_runtime_state(state)
        for entity in state.root:
            if not isinstance(entity, Flow):
                continue
            if entity.execution_context is not None:
                apply_execution_context(entity.execution_context)
            if isinstance(entity, cls):
                entity._restore_from_checkpoint()
                return entity
            instance = (
                cls.from_declaration(contents=definition)
                if definition is not None
                else cls()
            )
            instance.checkpoint_completed_methods = entity.checkpoint_completed_methods
            instance.checkpoint_method_outputs = entity.checkpoint_method_outputs
            instance.checkpoint_method_counts = entity.checkpoint_method_counts
            instance.checkpoint_state = entity.checkpoint_state
            instance._restore_from_checkpoint()
            return instance
        raise ValueError(f"No Flow found in checkpoint: {config.restore_from}")

    @classmethod
    def fork(
        cls,
        config: CheckpointConfig,
        branch: str | None = None,
        *,
        definition: FlowDefinition | None = None,
    ) -> Flow:  # type: ignore[type-arg]
        """Fork a Flow from a checkpoint, creating a new execution branch.

        Args:
            config: Checkpoint configuration with ``restore_from`` set.
            branch: Branch label for the fork. Auto-generated if not provided.
            definition: The FlowDefinition to restore a definition-built flow
                from, as in :meth:`from_checkpoint`.

        Returns:
            A Flow instance on the new branch. Call kickoff() to run.
        """
        flow = cls.from_checkpoint(config, definition=definition)
        state = crewai_event_bus.runtime_state
        if state is None:
            raise RuntimeError(
                "Cannot fork: no runtime state on the event bus. "
                "Ensure from_checkpoint() succeeded before calling fork()."
            )
        state.fork(branch)
        new_id = str(uuid4())
        if isinstance(flow._state, dict):
            flow._state["id"] = new_id
        else:
            object.__setattr__(flow._state, "id", new_id)
        return flow

    checkpoint_completed_methods: set[str] | None = Field(default=None)
    checkpoint_method_outputs: list[Any] | None = Field(default=None)
    checkpoint_method_counts: dict[str, int] | None = Field(default=None)
    checkpoint_state: dict[str, Any] | None = Field(default=None)

    def _restore_from_checkpoint(self) -> None:
        """Restore private execution state from checkpoint fields."""
        if self.checkpoint_completed_methods is not None:
            self._completed_methods = {
                FlowMethodName(m) for m in self.checkpoint_completed_methods
            }
            self._restored_from_checkpoint = True
        if self.checkpoint_method_outputs is not None:
            self._method_outputs = [
                entry
                if isinstance(entry, dict) and "method" in entry and "output" in entry
                else {"method": "", "output": entry}
                for entry in self.checkpoint_method_outputs
            ]
        if self.checkpoint_method_counts is not None:
            self._method_execution_counts = {
                FlowMethodName(k): v for k, v in self.checkpoint_method_counts.items()
            }
        if self.checkpoint_state is not None:
            self._restore_state(self.checkpoint_state)
        if (
            isinstance(self.memory, MemoryScope | MemorySlice)
            and self.memory._memory is None
        ):
            self.memory.bind(Memory())
        restore_event_scope(())
        reset_last_event_id()

    _methods: dict[FlowMethodName, Callable[..., Any]] = PrivateAttr(
        default_factory=dict
    )
    _method_execution_counts: dict[FlowMethodName, int] = PrivateAttr(
        default_factory=dict
    )
    _pending_events: dict[PendingListenerKey, set[str]] = PrivateAttr(
        default_factory=dict
    )
    _fired_or_listeners: set[FlowMethodName] = PrivateAttr(default_factory=set)
    _racing_groups_cache: dict[frozenset[FlowMethodName], FlowMethodName] | None = (
        PrivateAttr(default=None)
    )
    _method_outputs: list[Any] = PrivateAttr(default_factory=list)
    _definition: FlowDefinition = PrivateAttr()
    _or_listeners_lock: threading.Lock = PrivateAttr(default_factory=threading.Lock)
    _completed_methods: set[FlowMethodName] = PrivateAttr(default_factory=set)
    _method_call_counts: dict[FlowMethodName, int] = PrivateAttr(default_factory=dict)
    # True on flows CrewAI runs for its own bookkeeping - the agent executor and
    # the memory encoding/recall flows. Declared rather than inferred from the
    # module: a declarative flow built with Flow.from_declaration() is typed as
    # Flow itself, so a module check would call a caller's flow internal.
    is_crewai_internal: ClassVar[bool] = False

    # Set by the telemetry listener when a conversational turn fails. A
    # conversational session emits FlowFinishedEvent from
    # finalize_session_traces() regardless of outcome, so without this a failed
    # session would be reported as a successful completion.
    _telemetry_turn_error: type[BaseException] | None = PrivateAttr(default=None)

    _is_execution_resuming: bool = PrivateAttr(default=False)
    _restored_from_checkpoint: bool = PrivateAttr(default=False)
    # Monotonic stamp set by the telemetry listener at flow start, so the
    # duration span emitted at the end does not need to hold a span open for
    # the life of the run.
    _telemetry_started_at: float | None = PrivateAttr(default=None)
    _cel_now: datetime | None = PrivateAttr(default=None)
    _event_futures: list[Future[None]] = PrivateAttr(default_factory=list)
    _pending_feedback_context: PendingFeedbackContext | None = PrivateAttr(default=None)
    _human_feedback_method_outputs: dict[str, Any] = PrivateAttr(default_factory=dict)
    _input_history: list[InputHistoryEntry] = PrivateAttr(default_factory=list)
    _state: Any = PrivateAttr(default=None)
    _deferred_flow_started_event_id: str | None = PrivateAttr(default=None)
    _deferred_execution_trace: ExecutionTrace | None = PrivateAttr(default=None)
    _aggregated_usage_metrics: UsageMetrics = PrivateAttr(default_factory=UsageMetrics)
    _usage_metrics_lock: threading.Lock = PrivateAttr(default_factory=threading.Lock)
    _flow_match_id: str | None = PrivateAttr(default=None)
    _usage_aggregation_handler: Callable[..., Any] | None = PrivateAttr(default=None)
    _persist_backends: dict[int, FlowPersistence] = PrivateAttr(default_factory=dict)
    _instance_persistence: bool = PrivateAttr(default=False)
    # Live adapters restore before admission; kickoff must not replace their state.
    _skip_persistence_restore: bool = PrivateAttr(default=False)

    def __class_getitem__(cls: type[Flow[T]], item: type[T]) -> type[Flow[T]]:  # type: ignore[override]
        class _FlowGeneric(cls):  # type: ignore[valid-type,misc]
            pass

        _FlowGeneric.__name__ = f"{cls.__name__}[{item.__name__}]"
        _FlowGeneric._initial_state_t = item
        return _FlowGeneric

    def __setattr__(self, name: str, value: Any) -> None:
        """Allow arbitrary attribute assignment for backward compat with plain class."""
        if name in self.model_fields or name in self.__private_attributes__:
            super().__setattr__(name, value)
        else:
            object.__setattr__(self, name, value)

    def model_post_init(self, __context: Any) -> None:
        definition = (
            __context.get("flow_definition") if isinstance(__context, dict) else None
        )
        self._flow_post_init(definition)

    def _flow_post_init(self, definition: FlowDefinition | None = None) -> None:
        """Heavy initialization: state creation, events, memory, method registration."""
        if getattr(self, "_flow_post_init_done", False):
            return
        object.__setattr__(self, "_flow_post_init_done", True)
        self._initialize_runtime_extension_attrs()

        self._definition = definition or type(self).flow_definition()
        if self.name and self.name != self._definition.name:
            self._definition = self._definition.model_copy(update={"name": self.name})
        self._definition = self._extend_definition(self._definition)
        methods = (
            self._action_bound_methods()
            if definition is not None
            else self._class_bound_methods()
        )

        flow_persist = self._definition.persist
        self._instance_persistence = self.persistence is not None
        if (
            self.persistence is None
            and flow_persist is not None
            and flow_persist.enabled
        ):
            self.persistence = self._persist_backend_for(flow_persist)

        if self._state is None:
            self._state = self._create_initial_state()

        tracing_enabled = should_enable_tracing(override=self.tracing)
        set_tracing_enabled(tracing_enabled)

        trace_listener = TraceCollectionListener()
        trace_listener.setup_listeners(crewai_event_bus)

        if not self.suppress_flow_events:
            crewai_event_bus.emit(
                self,
                FlowCreatedEvent(
                    type="flow_created",
                    flow_name=self._definition.name,
                ),
            )

        # Auto-create memory if not provided at class or instance level.
        # Internal flows (RecallFlow, EncodingFlow) set _skip_auto_memory
        # to avoid creating a wasteful standalone Memory instance.
        if self.memory is None and not getattr(self, "_skip_auto_memory", False):
            from crewai.memory.utils import sanitize_scope_name

            flow_name = sanitize_scope_name(self._definition.name)
            self.memory = Memory(root_scope=f"/flow/{flow_name}")

        self._methods.update(methods)

    def _action_bound_methods(self) -> dict[FlowMethodName, Callable[..., Any]]:
        def build(name: str, definition: FlowMethodDefinition) -> Callable[..., Any]:
            try:
                return build_action(self, definition.do)
            except FlowScriptExecutionDisabledError:
                raise
            except Exception as e:
                unresolved.append(f"{name}: {e}")
                return lambda *args, **kwargs: None

        methods: dict[FlowMethodName, Callable[..., Any]] = {}
        unresolved: list[str] = []
        for method_name, method_definition in self._definition.methods.items():
            methods[FlowMethodName(method_name)] = build(method_name, method_definition)
        if unresolved:
            raise ValueError(
                f"Cannot build flow {self._definition.name!r} from its definition; "
                "methods with unresolvable actions: " + "; ".join(unresolved)
            )
        return methods

    def _class_bound_methods(self) -> dict[FlowMethodName, Callable[..., Any]]:
        methods: dict[FlowMethodName, Callable[..., Any]] = {}
        missing: list[str] = []
        for method_name in self._definition.methods:
            method = getattr(self, method_name, None)
            if method is None:
                missing.append(method_name)
                continue
            if not hasattr(method, "__self__"):
                method = method.__get__(self, type(self))
            methods[FlowMethodName(method_name)] = method
        if missing:
            raise ValueError(
                f"Flow {self._definition.name!r} definition declares methods its "
                "class does not provide: " + ", ".join(missing)
            )
        return methods

    def _attach_usage_aggregation_listener(self) -> None:
        """Wire an ``LLMCallCompletedEvent`` listener for the duration of one
        ``kickoff_async`` call.
        """
        if self._usage_aggregation_handler is not None:
            return

        # Capture the accumulator object in the closure so a stale handler
        # still queued in the bus thread pool from a prior kickoff writes
        # into its own (orphaned) UsageMetrics instead of the next kickoff's
        # fresh one.
        accumulator = self._aggregated_usage_metrics
        match_id = self._flow_match_id
        lock = self._usage_metrics_lock

        def _accumulate(source: Any, event: LLMCallCompletedEvent) -> None:
            if current_flow_id.get() != match_id:
                return
            metrics = _usage_dict_to_metrics(event.usage)
            if metrics is None:
                return
            with lock:
                accumulator.add_usage_metrics(metrics)

        crewai_event_bus.on(LLMCallCompletedEvent)(_accumulate)
        self._usage_aggregation_handler = _accumulate

    def _detach_usage_aggregation_listener(self) -> None:
        handler = self._usage_aggregation_handler
        if handler is None:
            return
        crewai_event_bus.off(LLMCallCompletedEvent, handler)
        self._usage_aggregation_handler = None

    @property
    def usage_metrics(self) -> UsageMetrics:
        """Aggregated LLM token usage for the most recent kickoff (or
        resume) of this flow instance.

        Aggregation is correlated by the ``current_flow_id`` contextvar
        captured at kickoff time. Nested kickoffs (a parent flow calling
        a child flow's ``kickoff``) intentionally roll the child's
        tokens up into the parent because the contextvar is inherited.
        Sibling kickoffs that run in parallel under the same parent
        contextvar share the same correlation id and may therefore
        over-count each other; if you need strict per-flow isolation
        in that pattern, run the children in separate tasks that
        explicitly set their own ``current_flow_id`` before kickoff.

        LLM calls that complete without exposing token usage (e.g.
        structured-output / Instructor paths) are not counted in
        ``successful_requests`` either, since we never see the call's
        token data — the metric stays a faithful summary of usage we
        actually observed rather than a partial count.

        Cross-process pause/resume (``Flow.from_pending`` in a new
        process) starts aggregation from zero on the restored instance
        because pre-pause totals are not yet persisted alongside the
        pending feedback context. Same-process pause/resume — where the
        caller keeps the flow instance and calls ``resume`` on it —
        preserves the running totals end-to-end.
        """
        with self._usage_metrics_lock:
            return self._aggregated_usage_metrics.model_copy()

    def recall(self, query: str, **kwargs: Any) -> Any:
        """Recall relevant memories. Delegates to this flow's memory.

        Args:
            query: Natural language query.
            **kwargs: Passed to memory.recall (e.g. scope, categories, limit, depth).

        Returns:
            Result of memory.recall(query, **kwargs).

        Raises:
            ValueError: If no memory is configured for this flow.
        """
        if self.memory is None:
            raise ValueError("No memory configured for this flow")
        return self.memory.recall(query, **kwargs)

    def remember(self, content: str | list[str], **kwargs: Any) -> Any:
        """Store one or more items in memory.

        Pass a single string for synchronous save (returns the MemoryRecord).
        Pass a list of strings for non-blocking batch save (returns immediately).

        Args:
            content: Text or list of texts to remember.
            **kwargs: Passed to memory.remember / remember_many
                      (e.g. scope, categories, metadata, importance).

        Returns:
            MemoryRecord for single item, empty list for batch (background save).

        Raises:
            ValueError: If no memory is configured for this flow.
            TypeError: If batch remember is attempted on a MemoryScope or MemorySlice.
        """
        if self.memory is None:
            raise ValueError("No memory configured for this flow")
        if isinstance(content, list):
            if not isinstance(self.memory, Memory):
                raise TypeError(
                    "Batch remember requires a Memory instance, "
                    f"got {type(self.memory).__name__}"
                )
            return self.memory.remember_many(content, **kwargs)
        return self.memory.remember(content, **kwargs)

    def _drain_memory_writes(self) -> None:
        """Block until pending background memory saves for this flow finish.

        Must run before ``FlowFinishedEvent`` is emitted: listeners (e.g.
        telemetry sessions) tear down on that event, and any
        ``MemorySaveCompletedEvent``/``MemorySaveFailedEvent`` emitted after
        teardown is lost, leaving the save span orphaned.
        """
        mem = self.memory
        if mem is None:
            return
        backing = getattr(mem, "_memory", None) or mem
        drain = getattr(backing, "drain_writes", None)
        if callable(drain):
            drain()

    def extract_memories(self, content: str) -> list[str]:
        """Extract discrete memories from content. Delegates to this flow's memory.

        Args:
            content: Raw text (e.g. task + result dump).

        Returns:
            List of short, self-contained memory statements.

        Raises:
            ValueError: If no memory is configured for this flow.
        """
        if self.memory is None:
            raise ValueError("No memory configured for this flow")
        result: list[str] = self.memory.extract_memories(content)
        return result

    def _clear_or_listeners(self) -> None:
        """Clear fired OR listeners for cyclic flows."""
        with self._or_listeners_lock:
            self._fired_or_listeners.clear()

    def _discard_or_listener(self, listener_name: FlowMethodName) -> None:
        """Discard a single OR listener from the fired set."""
        with self._or_listeners_lock:
            self._fired_or_listeners.discard(listener_name)

    def _start_condition_triggered_by(
        self, method_name: FlowMethodName, trigger: FlowMethodName
    ) -> bool:
        condition = self._start_condition(method_name)
        if condition is None:
            return False
        return self._condition_met(
            condition, trigger, PendingListenerKey(f"start:{method_name}")
        )

    def _rearm_or_listeners_for_trigger(
        self,
        trigger: FlowMethodName,
        rearmable: set[FlowMethodName] | None = None,
    ) -> None:
        # When a router emits a fresh signal, re-arm fired multi-event or_()
        # listeners that reference the trigger so cyclic flows can re-fire them.
        # A given rearmable set, when passed, bounds which listeners may re-arm.
        with self._or_listeners_lock:
            if not self._fired_or_listeners:
                return
            candidates: set[FlowMethodName] = (
                self._fired_or_listeners & rearmable
                if rearmable is not None
                else set(self._fired_or_listeners)
            )
            if not candidates:
                return
            trigger_str = str(trigger)
            to_discard: list[FlowMethodName] = []
            for listener_name in candidates:
                condition = self._listen_condition(listener_name)
                if condition is None:
                    continue
                if trigger_str in _iter_condition_events(condition):
                    to_discard.append(listener_name)
            for listener_name in to_discard:
                self._fired_or_listeners.discard(listener_name)
                if rearmable is not None:
                    rearmable.discard(listener_name)

    def _build_racing_groups(self) -> dict[frozenset[FlowMethodName], FlowMethodName]:
        # Events of a multi-event or_() listener race: only the first to fire
        # should trigger it. We map {frozenset(racing events): listener}.
        # Only events that EXCLUSIVELY feed one OR listener race; an event that
        # also feeds another listener (e.g. an AND) is left alone when a sibling
        # wins. e.g. @listen(or_(a, b)) on handler -> {frozenset({a, b}): handler}.
        # Events nested under an and_() branch (e.g. or_(and_(a, b), c)) are not
        # alternatives and never race -- cancelling one would make the AND
        # unsatisfiable.
        racing_groups: dict[frozenset[FlowMethodName], FlowMethodName] = {}
        listener_conditions: dict[FlowMethodName, FlowDefinitionCondition] = {
            listener_name: condition
            for listener_name, method_definition, condition in self._listener_methods()
            if not method_definition.router
        }

        events_by_listener: dict[FlowMethodName, set[str]] = {
            listener_name: set(_iter_condition_events(condition))
            for listener_name, condition in listener_conditions.items()
        }

        listeners_by_event: dict[str, set[FlowMethodName]] = {}
        for listener_name, events in events_by_listener.items():
            for event in events:
                listeners_by_event.setdefault(event, set()).add(listener_name)

        for listener_name, condition in listener_conditions.items():
            if not isinstance(condition, dict):
                continue
            alternatives = set(_or_alternative_events(condition))
            if len(alternatives) <= 1:
                continue

            exclusive_events = {
                event
                for event in alternatives
                if listeners_by_event[event] == {listener_name}
            }
            if len(exclusive_events) > 1:
                # Racing only applies to method-completion events: each member is
                # later executed as a method and intersected with the running
                # method names, so the leaves re-enter method space here.
                racing_groups[
                    frozenset(FlowMethodName(event) for event in exclusive_events)
                ] = listener_name

        return racing_groups

    def _get_racing_group_for_listeners(
        self,
        listener_names: list[FlowMethodName],
    ) -> tuple[frozenset[FlowMethodName], FlowMethodName] | None:
        """Check if the given listeners form a racing group.

        Args:
            listener_names: List of listener method names being executed.

        Returns:
            Tuple of (racing_members, or_listener_name) if these listeners race,
            None otherwise.
        """
        if self._racing_groups_cache is None:
            self._racing_groups_cache = self._build_racing_groups()

        listener_set = set(listener_names)

        for racing_members, or_listener in self._racing_groups_cache.items():
            racing_subset = racing_members & listener_set
            if len(racing_subset) > 1:
                return (frozenset(racing_subset), or_listener)

        return None

    async def _execute_racing_listeners(
        self,
        racing_listeners: frozenset[FlowMethodName],
        other_listeners: list[FlowMethodName],
        result: Any,
        triggering_event_id: str | None = None,
    ) -> None:
        """Execute racing listeners with first-wins semantics.

        Racing listeners are executed in parallel, but once the first one
        completes, the others are cancelled. Non-racing listeners in the
        same batch are executed normally in parallel.

        Args:
            racing_listeners: Set of listener names that race for an OR condition.
            other_listeners: Other listeners to execute in parallel (not racing).
            result: The result from the triggering method.
            triggering_event_id: The event_id of the event that triggered these listeners.
        """
        racing_tasks = [
            asyncio.create_task(
                self._execute_single_listener(name, result, triggering_event_id),
                name=str(name),
            )
            for name in racing_listeners
        ]

        other_tasks = [
            asyncio.create_task(
                self._execute_single_listener(name, result, triggering_event_id),
                name=str(name),
            )
            for name in other_listeners
        ]

        if racing_tasks:
            for coro in asyncio.as_completed(racing_tasks):
                try:
                    await coro
                except Exception as e:
                    logger.debug(f"Racing listener failed: {e}")
                    continue
                break

            for task in racing_tasks:
                if not task.done():
                    task.cancel()

        if other_tasks:
            await asyncio.gather(*other_tasks, return_exceptions=True)

    @classmethod
    def from_pending(
        cls,
        flow_id: str,
        persistence: FlowPersistence | None = None,
        *,
        definition: FlowDefinition | None = None,
        **kwargs: Any,
    ) -> Flow[Any]:
        """Create a Flow instance from a pending feedback state.

        This classmethod is used to restore a flow that was paused waiting
        for async human feedback. It loads the persisted state and pending
        feedback context, then returns a flow instance ready to resume.

        Args:
            flow_id: The unique identifier of the paused flow (from state.id)
            persistence: The persistence backend where the state was saved.
                If not provided, uses ``default_flow_persistence()`` (the
                registered factory when present, else the built-in SQLite
                fallback).
            definition: The FlowDefinition to restore a definition-built flow
                (one created via ``Flow.from_declaration``) from. Subclasses
                carry their own definition and don't need this.
            **kwargs: Additional keyword arguments passed to the Flow constructor

        Returns:
            A new Flow instance with restored state, ready to call resume()

        Raises:
            ValueError: If no pending feedback exists for the given flow_id

        Example:
            ```python
            # Simple usage with default persistence:
            flow = MyFlow.from_pending("abc-123")
            result = flow.resume("looks good!")

            # Or with custom persistence:
            persistence = SQLiteFlowPersistence("custom.db")
            flow = MyFlow.from_pending("abc-123", persistence)
            result = flow.resume("looks good!")
            ```
        """
        if persistence is None:
            from crewai.flow.persistence.factory import default_flow_persistence

            persistence = default_flow_persistence()

        loaded = persistence.load_pending_feedback(flow_id)
        if loaded is None:
            raise ValueError(f"No pending feedback found for flow_id: {flow_id}")

        state_data, pending_context = loaded

        instance = (
            cls.from_declaration(contents=definition, persistence=persistence, **kwargs)
            if definition is not None
            else cls(persistence=persistence, **kwargs)
        )
        instance._initialize_state(state_data)
        instance._pending_feedback_context = pending_context
        instance._is_execution_resuming = True
        # Seed the match id so the resume-phase listener filters its own
        # LLM events (which run with `current_flow_id == instance.flow_id`)
        # instead of dropping or absorbing unrelated ones. Must stay
        # `instance.flow_id`: resume forces `current_flow_id` to this value and
        # `_owns_execution_boundary` compares the two.
        instance._flow_match_id = instance.flow_id

        return instance

    @property
    def pending_feedback(self) -> PendingFeedbackContext | None:
        """Get the pending feedback context if this flow is waiting for feedback.

        Returns:
            The PendingFeedbackContext if the flow is paused waiting for feedback,
            None otherwise.

        Example:
            ```python
            flow = MyFlow.from_pending("abc-123", persistence)
            if flow.pending_feedback:
                print(f"Waiting for feedback on: {flow.pending_feedback.method_name}")
            ```
        """
        return self._pending_feedback_context

    def resume(self, feedback: str = "") -> Any:
        """Resume flow execution, optionally with human feedback.

        This method continues flow execution after a flow was paused for
        async human feedback. It processes the feedback (including LLM-based
        outcome collapsing if emit was specified), stores the result, and
        triggers downstream listeners.

        Note:
            If called from within an async context (running event loop),
            use `await flow.resume_async(feedback)` instead.

        Args:
            feedback: The human's feedback as a string. If empty, uses
                default_outcome or the first emit option.

        Returns:
            The final output from the flow execution, or HumanFeedbackPending
            if another feedback point is reached.

        Raises:
            ValueError: If no pending feedback context exists (flow wasn't paused)
            RuntimeError: If called from within a running event loop (use resume_async instead)

        Example:
            ```python
            # In a sync webhook handler:
            def handle_feedback(flow_id: str, feedback: str):
                flow = MyFlow.from_pending(flow_id)
                result = flow.resume(feedback)
                return result


            # In an async handler, use resume_async instead:
            async def handle_feedback_async(flow_id: str, feedback: str):
                flow = MyFlow.from_pending(flow_id)
                result = await flow.resume_async(feedback)
                return result
            ```
        """
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop is not None:
            raise RuntimeError(
                "resume() cannot be called from within an async context. "
                "Use 'await flow.resume_async(feedback)' instead."
            )

        return asyncio.run(self.resume_async(feedback))

    async def resume_async(self, feedback: str = "") -> Any:
        """Async version of resume.

        Resume flow execution, optionally with human feedback asynchronously.

        Args:
            feedback: The human's feedback as a string. If empty, uses
                default_outcome or the first emit option.

        Returns:
            The final output from the flow execution, or HumanFeedbackPending
            if another feedback point is reached.

        Raises:
            ValueError: If no pending feedback context exists
        """
        if self._pending_feedback_context is None:
            raise ValueError(
                "No pending feedback context. Use from_pending() to restore a paused flow."
            )

        # A fresh instant, not the persisted kickoff one: a flow can pause on
        # feedback for days, and expressions after resume must see today.
        self._cel_now = datetime.now(timezone.utc)

        execution_token = None

        # Force `current_flow_id` to this flow's match id for the
        # duration of the resume so the usage listener's filter passes
        # even when resume runs under another flow's active context.
        flow_id_token = None
        if self._flow_match_id is not None:
            flow_id_token = current_flow_id.set(self._flow_match_id)
        self._attach_usage_aggregation_listener()
        # Per-invocation pairing state: a resumed execution's EXECUTION_START
        # fired in the original kickoff, so a failure here still owes the
        # paired EXECUTION_END (unless the body already dispatched it).
        hook_state = {"end_dispatched": False}
        try:
            execution_token = self._begin_trace_execution(
                self._pending_feedback_context.execution_uuid,
            )
            if execution_token is not None and (session := get_trace_session()):
                session.context.parent_otel_context = (
                    self._pending_feedback_context.trace_context
                )
                session.context.resume_feedback = feedback
            return await self._resume_async_body(feedback, hook_state)
        except Exception as e:
            from crewai.telemetry.tracing.grants import TraceGrantError

            if execution_token is None and isinstance(e, TraceGrantError):
                raise
            if not hook_state["end_dispatched"]:
                self._dispatch_execution_end_failure(e)
            await self._emit_flow_failed(e)
            raise
        finally:
            # Match kickoff_async: drain pending handlers so the resumed
            # phase's LLM events all hit `_aggregated_usage_metrics`
            # before the listener is detached.
            crewai_event_bus.flush()
            self._detach_usage_aggregation_listener()
            if flow_id_token is not None:
                current_flow_id.reset(flow_id_token)
            self._end_trace_execution(execution_token)

    async def _resume_async_body(
        self, feedback: str = "", hook_state: dict[str, bool] | None = None
    ) -> Any:
        await self._open_flow_scope(None)

        context = self._pending_feedback_context
        if context is None:
            raise ValueError(
                "No pending feedback context. Use from_pending() to restore a paused flow."
            )
        emit = context.emit

        if not self.suppress_flow_events:
            # Opens the scope the finished event below closes; without it that
            # event pops the enclosing ``flow_started`` instead.
            future = crewai_event_bus.emit(
                self,
                MethodExecutionStartedEvent(
                    type="method_execution_started",
                    flow_name=self._definition.name,
                    method_name=context.method_name,
                    state=self._copy_and_serialize_state(),
                ),
            )
            if future and isinstance(future, Future):
                try:
                    await asyncio.wrap_future(future)
                except Exception:
                    logger.warning(
                        "MethodExecutionStartedEvent handler failed", exc_info=True
                    )

        try:
            # The serialized context carries the full LLM config (a dict, or a
            # legacy model string) — the single source for cross- and
            # same-process resume.
            previous_feedback = self.last_human_feedback
            result = await self._finalize_human_feedback(
                method_name=context.method_name,
                method_output=context.method_output,
                raw_feedback=feedback,
                emit=emit,
                default_outcome=context.default_outcome,
                llm=context.llm,
                metadata=context.metadata,
            )
            collapsed_outcome = result.outcome
            resumed_method_output = (
                result.output
                if emit and isinstance(result, HumanFeedbackResult)
                else result
            )

            feedback_definition = self._definition.methods[
                context.method_name
            ].human_feedback
            if feedback_definition is not None:
                # A reply that resumes a paused flow (e.g. email review on AMP)
                # teaches the same lessons as one that arrives during the run.
                try:
                    await self._store_feedback_lessons(
                        feedback_definition,
                        context.method_name,
                        context.method_output,
                        feedback,
                        context.llm,
                    )
                except Exception:
                    # learn_strict re-raised and the review stays pending: undo the
                    # recorded reply so a retry on this instance records it once.
                    self.human_feedback_history.pop()
                    self.last_human_feedback = previous_feedback
                    raise

            self._completed_methods.add(FlowMethodName(context.method_name))

            await asyncio.to_thread(
                self._persist_method_completion, FlowMethodName(context.method_name)
            )

            self._pending_feedback_context = None

            if self.persistence is not None:
                self.persistence.clear_pending_feedback(context.flow_id)
        except Exception as e:
            if not self.suppress_flow_events:
                crewai_event_bus.emit(
                    self,
                    MethodExecutionFailedEvent(
                        type="method_execution_failed",
                        flow_name=self._definition.name,
                        method_name=context.method_name,
                        error=e,
                    ),
                )
            raise

        if not self.suppress_flow_events:
            crewai_event_bus.emit(
                self,
                MethodExecutionFinishedEvent(
                    type="method_execution_finished",
                    flow_name=self._definition.name,
                    method_name=context.method_name,
                    result=collapsed_outcome if emit else result,
                    state=self._state,
                ),
            )

        # Clear resumption flag before triggering listeners
        # This allows methods to re-execute in loops (e.g., implement_changes → suggest_changes → implement_changes)
        self._is_execution_resuming = False

        method_output_entry: dict[str, Any] = {
            "method": context.method_name,
            "output": resumed_method_output,
        }
        if emit and isinstance(result, HumanFeedbackResult):
            method_output_entry["human_feedback"] = result
        self._method_outputs.append(method_output_entry)

        try:
            if emit and collapsed_outcome:
                await self._execute_listeners(
                    FlowMethodName(collapsed_outcome),
                    result,
                )
            else:
                await self._execute_listeners(
                    FlowMethodName(context.method_name),
                    result,
                )
        except Exception as e:
            # Check if flow was paused again for human feedback (loop case)
            if isinstance(e, HumanFeedbackPending):
                self._pending_feedback_context = e.context

                if self.persistence is None:
                    from crewai.flow.persistence.factory import default_flow_persistence

                    self.persistence = default_flow_persistence()

                state_data = (
                    self._state
                    if isinstance(self._state, dict)
                    else self._state.model_dump()
                )
                future = crewai_event_bus.emit(
                    self,
                    FlowPausedEvent(
                        type="flow_paused",
                        flow_name=self._definition.name,
                        flow_id=e.context.flow_id,
                        method_name=e.context.method_name,
                        state=self._copy_and_serialize_state(),
                        message=e.context.message,
                        emit=e.context.emit,
                    ),
                )
                if future:
                    await asyncio.wrap_future(future)
                if session := get_trace_session():
                    e.context.trace_context = session.context.otel_resume_context
                self.persistence.save_pending_feedback(
                    flow_uuid=e.context.flow_id,
                    context=e.context,
                    state_data=state_data,
                )
                return e
            raise

        method_outputs = self.method_outputs
        final_result = (
            method_outputs[-1]
            if method_outputs
            else (resumed_method_output if emit else result)
        )

        from crewai.hooks.contexts import ExecutionEndContext, OutputContext
        from crewai.hooks.dispatch import InterceptionPoint

        output_ctx = OutputContext(flow=self, output=final_result, payload=final_result)
        self._dispatch_interception(InterceptionPoint.OUTPUT, output_ctx)
        final_result = output_ctx.payload

        end_ctx = ExecutionEndContext(
            flow=self, output=final_result, payload=final_result
        )
        # Flag set before dispatching so an EXECUTION_END hook that raises
        # HookAborted does not trigger a second (failure) dispatch upstream. A
        # skipped dispatch leaves it false, matching the kickoff path.
        if hook_state is not None and not self._skip_interception(
            InterceptionPoint.EXECUTION_END
        ):
            hook_state["end_dispatched"] = True
        self._dispatch_interception(InterceptionPoint.EXECUTION_END, end_ctx)
        final_result = end_ctx.payload

        if self._event_futures:
            await asyncio.gather(
                *[
                    asyncio.wrap_future(f)
                    for f in self._event_futures
                    if isinstance(f, Future)
                ]
            )
            self._event_futures.clear()

        # Not gated on suppress_flow_events: that asks for console quiet, and the
        # started event above is ungated, so gating here would emit a start with no
        # terminal event. The defer check stays - it is a real reason to withhold the
        # finish, because finalize_session_traces() emits it later instead.
        if not self._should_defer_trace_finalization():
            # Background memory saves must finish (and emit their
            # completed/failed events) before flow-finished triggers
            # listener teardown/finalization; the flush then waits for those
            # events' async handlers, mirroring Crew._create_crew_output.
            # Offloaded to a thread so the blocking waits don't stall other
            # coroutines on the loop.
            await asyncio.to_thread(self._drain_memory_writes)
            await asyncio.to_thread(crewai_event_bus.flush)
            future = crewai_event_bus.emit(
                self,
                FlowFinishedEvent(
                    type="flow_finished",
                    flow_name=self._definition.name,
                    result=final_result,
                    state=self._copy_and_serialize_state(),
                ),
            )
            if future and isinstance(future, Future):
                try:
                    await asyncio.wrap_future(future)
                except Exception:
                    logger.warning("FlowFinishedEvent handler failed", exc_info=True)

        return final_result

    def _create_initial_state(self) -> T:
        """Create and initialize flow state with UUID and default values.

        Returns:
            New state instance with UUID and default values initialized

        Raises:
            ValueError: If structured state model lacks 'id' field
            TypeError: If state is neither BaseModel nor dictionary
        """
        init_state = self.initial_state

        if init_state is None:
            extension_state = self._create_default_extension_state()
            if extension_state is not None:
                return cast(T, extension_state)

        if init_state is None and hasattr(self, "_initial_state_t"):
            state_type = self._initial_state_t
            if isinstance(state_type, TypeVar):
                state_type = None
            if isinstance(state_type, type):
                if issubclass(state_type, FlowState):
                    instance = state_type()
                    if not getattr(instance, "id", None):
                        object.__setattr__(instance, "id", str(uuid4()))
                    return cast(T, instance)
                if issubclass(state_type, BaseModel):

                    class StateWithId(FlowState, state_type):  # type: ignore
                        pass

                    instance = StateWithId()
                    if not getattr(instance, "id", None):
                        object.__setattr__(instance, "id", str(uuid4()))
                    return cast(T, instance)
                if state_type is dict:
                    return cast(T, {"id": str(uuid4())})

        if init_state is None:
            return cast(T, self._create_definition_state())

        if isinstance(init_state, type):
            state_class = init_state
            if issubclass(state_class, FlowState):
                return cast(T, state_class())
            if issubclass(state_class, BaseModel):
                model_fields = getattr(state_class, "model_fields", None)
                if not model_fields or "id" not in model_fields:
                    raise ValueError("Flow state model must have an 'id' field")
                model_instance = state_class()
                if not getattr(model_instance, "id", None):
                    object.__setattr__(model_instance, "id", str(uuid4()))
                return cast(T, model_instance)
            if init_state is dict:
                return cast(T, {"id": str(uuid4())})

        if isinstance(init_state, dict):
            new_state = dict(init_state)  # Copy to avoid mutations
            if "id" not in new_state:
                new_state["id"] = str(uuid4())
            return cast(T, new_state)

        if isinstance(init_state, BaseModel):
            model = init_state
            if hasattr(model, "id"):
                state_dict = model.model_dump()
                if not state_dict.get("id"):
                    state_dict["id"] = str(uuid4())
                model_class = type(model)
                return cast(T, model_class(**state_dict))

            class StateWithId(FlowState, type(model)):  # type: ignore
                pass

            state_dict = model.model_dump()
            state_dict["id"] = str(uuid4())
            return cast(T, StateWithId(**state_dict))
        raise TypeError(
            f"Initial state must be dict or BaseModel, got {type(self.initial_state)}"
        )

    def _create_definition_state(self) -> dict[str, Any] | BaseModel:
        state_definition = self._definition.state
        if state_definition is None:
            return {"id": str(uuid4())}
        if state_definition.type in ("pydantic", "json_schema"):
            state = _build_definition_state_model(
                state_definition, compose=self._compose_extension_state_model
            )
            if state is not None:
                return state
            logger.error(
                "Flow %r declares %s state but neither ref nor json_schema "
                "produced a model; falling back to dict state",
                self._definition.name,
                state_definition.type,
            )
            extension_state: dict[str, Any] | BaseModel | None = (
                self._create_default_extension_state(ignore_declared_state=True)
            )
            if extension_state is not None:
                return extension_state
        elif state_definition.type == "unknown":
            logger.warning(
                "Flow %r declares state of unknown type; falling back to dict state",
                self._definition.name,
            )
        dict_state: dict[str, Any] = dict(state_definition.default or {})
        if "id" not in dict_state:
            dict_state["id"] = str(uuid4())
        return dict_state

    def _copy_state(self) -> T:
        """Create a copy of the current state.

        Returns:
            A copy of the current state
        """
        if isinstance(self._state, BaseModel):
            try:
                return cast(T, self._state.model_copy(deep=True))
            except (TypeError, AttributeError):
                try:
                    state_dict = self._state.model_dump()
                    model_class = type(self._state)
                    return cast(T, model_class(**state_dict))
                except Exception:
                    return cast(T, self._state.model_copy(deep=False))
        else:
            try:
                return cast(T, copy.deepcopy(self._state))
            except (TypeError, AttributeError):
                return cast(T, self._state.copy())

    @property
    def state(self) -> T:
        return cast(T, self._state)

    @property
    def method_outputs(self) -> list[Any]:
        """Returns the list of all outputs from executed methods."""
        outputs: list[Any] = []
        for entry in self._method_outputs:
            if isinstance(entry, dict) and "output" in entry:
                outputs.append(entry["output"])
            else:
                outputs.append(entry)
        return outputs

    @property
    def flow_id(self) -> str:
        """Returns the unique identifier of this flow instance.

        This property provides a consistent way to access the flow's unique identifier
        regardless of the underlying state implementation (dict or BaseModel).

        Returns:
            str: The flow's unique identifier, or an empty string if not found

        Note:
            This property safely handles both dictionary and BaseModel state types,
            returning an empty string if the ID cannot be retrieved rather than raising
            an exception.

        Example:
            ```python
            flow = MyFlow()
            print(f"Current flow ID: {flow.flow_id}")  # Safely get flow ID
            ```
        """
        try:
            if not hasattr(self, "_state"):
                return ""

            if isinstance(self._state, dict):
                return str(self._state.get("id", ""))
            if isinstance(self._state, BaseModel):
                return str(getattr(self._state, "id", ""))
            return ""
        except (AttributeError, TypeError):
            return ""  # Safely handle any unexpected attribute access issues

    def _initialize_state(self, inputs: dict[str, Any]) -> None:
        """Initialize or update flow state with new inputs.

        Args:
            inputs: Dictionary of state values to set/update

        Raises:
            ValueError: If validation fails for structured state
            TypeError: If state is neither BaseModel nor dictionary
        """
        if isinstance(self._state, dict):
            # If inputs contains an id, use it (for restoring from persistence);
            # otherwise preserve the current id or generate a new one.
            current_id = self._state.get("id")
            inputs_has_id = "id" in inputs

            for k, v in inputs.items():
                self._state[k] = v

            if not inputs_has_id:
                if current_id:
                    self._state["id"] = current_id
                elif "id" not in self._state:
                    self._state["id"] = str(uuid4())
        elif isinstance(self._state, BaseModel):
            try:
                model = self._state
                if hasattr(model, "model_dump"):
                    current_state = model.model_dump()
                elif hasattr(model, "dict"):
                    current_state = model.dict()
                else:
                    current_state = {
                        k: v for k, v in model.__dict__.items() if not k.startswith("_")
                    }

                new_state = {**current_state, **inputs}

                model_class = type(model)
                if hasattr(model_class, "model_validate"):
                    self._state = cast(T, model_class.model_validate(new_state))
                elif hasattr(model_class, "parse_obj"):
                    self._state = cast(T, model_class.parse_obj(new_state))
                else:
                    self._state = cast(T, model_class(**new_state))
            except ValidationError as e:
                raise ValueError(f"Invalid inputs for structured state: {e}") from e
        else:
            raise TypeError("State must be a BaseModel instance or a dictionary.")

    def _restore_state(self, stored_state: dict[str, Any]) -> None:
        """Restore flow state from persistence.

        Args:
            stored_state: Previously stored state to restore

        Raises:
            ValueError: If validation fails for structured state
            TypeError: If state is neither BaseModel nor dictionary
        """
        stored_id = stored_state.get("id")
        if not stored_id:
            raise ValueError("Stored state must have an 'id' field")

        if isinstance(self._state, dict):
            self._state.clear()
            self._state.update(stored_state)
        elif isinstance(self._state, BaseModel):
            model = self._state
            if hasattr(model, "model_validate"):
                self._state = cast(T, type(model).model_validate(stored_state))
            elif hasattr(model, "parse_obj"):
                self._state = cast(T, type(model).parse_obj(stored_state))
            else:
                self._state = cast(T, type(model)(**stored_state))
        else:
            raise TypeError(f"State must be dict or BaseModel, got {type(self._state)}")

    def reload(self, execution_data: FlowExecutionData) -> None:
        """Reloads the flow from an execution data dict.

        This method restores the flow's execution ID, completed methods, and state,
        allowing it to resume from where it left off.

        Args:
            execution_data: Flow execution data containing:
                - id: Flow execution ID
                - flow: Flow structure
                - completed_methods: list of successfully completed methods
                - execution_methods: All execution methods with their status
        """
        flow_id = execution_data.get("id")
        if flow_id:
            self._update_state_field("id", flow_id)

        self._completed_methods = {
            cast(FlowMethodName, name)
            for method_data in execution_data.get("completed_methods", [])
            if (name := method_data.get("flow_method", {}).get("name")) is not None
        }

        execution_methods = execution_data.get("execution_methods", [])
        if not execution_methods:
            return

        sorted_methods = sorted(
            execution_methods,
            key=lambda m: m.get("started_at", ""),
        )

        state_to_apply = None
        for method in reversed(sorted_methods):
            if method.get("final_state"):
                state_to_apply = method["final_state"]
                break

        if not state_to_apply and sorted_methods:
            last_method = sorted_methods[-1]
            if last_method.get("initial_state"):
                state_to_apply = last_method["initial_state"]

        if state_to_apply:
            self._apply_state_updates(state_to_apply)

        for method in sorted_methods[:-1]:
            method_name = cast(
                FlowMethodName | None, method.get("flow_method", {}).get("name")
            )
            if method_name:
                self._completed_methods.add(method_name)

    def _update_state_field(self, field_name: str, value: Any) -> None:
        """Update a single field in the state."""
        if isinstance(self._state, dict):
            self._state[field_name] = value
        elif hasattr(self._state, field_name):
            object.__setattr__(self._state, field_name, value)

    def _apply_state_updates(self, updates: dict[str, Any]) -> None:
        """Apply multiple state updates efficiently."""
        if isinstance(self._state, dict):
            self._state.update(updates)
        elif hasattr(self._state, "__dict__"):
            for key, value in updates.items():
                if hasattr(self._state, key):
                    object.__setattr__(self._state, key, value)

    def stream_events(
        self,
        inputs: dict[str, Any] | None = None,
        input_files: dict[str, FileInput] | None = None,
        from_checkpoint: CheckpointConfig | None = None,
        restore_from_state_id: str | None = None,
    ) -> StreamSession[Any]:
        """Run the flow and stream all scoped public ``StreamFrame`` events."""
        result_holder: list[Any] = []
        state = create_frame_streaming_state(result_holder, use_async=False)
        output_holder: list[StreamSession[Any]] = []

        def run_flow() -> Any:
            original_stream = self.stream
            try:
                self.stream = False
                return self.kickoff(
                    inputs=inputs,
                    input_files=input_files,
                    from_checkpoint=from_checkpoint,
                    restore_from_state_id=restore_from_state_id,
                )
            except HumanFeedbackPending as e:
                return e
            finally:
                self.stream = original_stream

        stream_session: StreamSession[Any] = StreamSession(
            sync_iterator=create_frame_generator(state, run_flow, output_holder)
        )
        output_holder.append(stream_session)
        return stream_session

    def astream(
        self,
        inputs: dict[str, Any] | None = None,
        input_files: dict[str, FileInput] | None = None,
        from_checkpoint: CheckpointConfig | None = None,
        restore_from_state_id: str | None = None,
    ) -> AsyncStreamSession[Any]:
        """Run the flow asynchronously and stream scoped public frames."""
        result_holder: list[Any] = []
        state = create_frame_streaming_state(result_holder, use_async=True)
        output_holder: list[AsyncStreamSession[Any]] = []

        async def run_flow() -> Any:
            original_stream = self.stream
            try:
                self.stream = False
                return await self.kickoff_async(
                    inputs=inputs,
                    input_files=input_files,
                    from_checkpoint=from_checkpoint,
                    restore_from_state_id=restore_from_state_id,
                )
            except HumanFeedbackPending as e:
                return e
            finally:
                self.stream = original_stream

        stream_session: AsyncStreamSession[Any] = AsyncStreamSession(
            async_iterator=create_async_frame_generator(state, run_flow, output_holder)
        )
        output_holder.append(stream_session)
        return stream_session

    def kickoff(
        self,
        inputs: dict[str, Any] | None = None,
        input_files: dict[str, FileInput] | None = None,
        from_checkpoint: CheckpointConfig | None = None,
        restore_from_state_id: str | None = None,
    ) -> Any | StreamSession[Any]:
        """Start the flow execution in a synchronous context.

        This method wraps kickoff_async so that all state initialization and event
        emission is handled in the asynchronous method.

        Args:
            inputs: Optional dictionary containing input values and/or a state ID.
            input_files: Optional dict of named file inputs for the flow.
            from_checkpoint: Optional checkpoint config. If ``restore_from``
                is set, the flow resumes from that checkpoint.
            restore_from_state_id: Optional UUID of a previously-persisted flow
                whose latest snapshot should hydrate this run's state. The new
                run is assigned a fresh ``state.id`` (or ``inputs["id"]`` if
                pinned), so its ``@persist`` writes land under a separate
                persistence key and the source flow's history is preserved.
                If the referenced state is not found, the kickoff falls back
                silently to baseline behavior. Cannot be combined with
                ``from_checkpoint``; passing both raises ``ValueError``.

        Returns:
            The final output from the flow or StreamSession if streaming.
        """
        if from_checkpoint is not None and restore_from_state_id is not None:
            raise ValueError(
                "Cannot combine `from_checkpoint` and `restore_from_state_id`. "
                "These parameters target different state systems "
                "(Checkpointing and @persist) and cannot be used together."
            )
        restored = apply_checkpoint(self, from_checkpoint)
        if restored is not None:
            return restored.kickoff(inputs=inputs, input_files=input_files)
        if self.stream:
            return self.stream_events(
                inputs=inputs,
                input_files=input_files,
                from_checkpoint=from_checkpoint,
                restore_from_state_id=restore_from_state_id,
            )

        async def _run_flow() -> Any:
            return await self.kickoff_async(
                inputs,
                input_files,
                restore_from_state_id=restore_from_state_id,
            )

        runtime_scope = crewai_event_bus._enter_runtime_scope()
        try:
            try:
                asyncio.get_running_loop()
                ctx = contextvars.copy_context()
                with ThreadPoolExecutor(max_workers=1) as pool:
                    return pool.submit(ctx.run, asyncio.run, _run_flow()).result()
            except RuntimeError:
                return asyncio.run(_run_flow())
        finally:
            crewai_event_bus._exit_runtime_scope(runtime_scope)

    async def kickoff_async(
        self,
        inputs: dict[str, Any] | None = None,
        input_files: dict[str, FileInput] | None = None,
        from_checkpoint: CheckpointConfig | None = None,
        restore_from_state_id: str | None = None,
    ) -> Any | AsyncStreamSession[Any]:
        """Start the flow execution asynchronously.

        This method performs state restoration (if an 'id' is provided and persistence is available)
        and updates the flow state with any additional inputs. It then emits the FlowStartedEvent,
        logs the flow startup, and executes all start methods. Once completed, it emits the
        FlowFinishedEvent and returns the final output.

        Args:
            inputs: Optional dictionary containing input values and/or a state ID for restoration.
            input_files: Optional dict of named file inputs for the flow.
            from_checkpoint: Optional checkpoint config. If ``restore_from``
                is set, the flow resumes from that checkpoint.
            restore_from_state_id: Optional UUID of a previously-persisted flow
                whose latest snapshot should hydrate this run's state. The new
                run is assigned a fresh ``state.id`` (or ``inputs["id"]`` if
                pinned), so subsequent ``@persist`` writes land under a
                separate persistence key. If the referenced state is not
                found, falls back silently to baseline. Cannot be combined
                with ``from_checkpoint``; passing both raises ``ValueError``.

        Returns:
            The final output from the flow, which is the result of the last executed method.
        """
        if from_checkpoint is not None and restore_from_state_id is not None:
            raise ValueError(
                "Cannot combine `from_checkpoint` and `restore_from_state_id`. "
                "These parameters target different state systems "
                "(Checkpointing and @persist) and cannot be used together."
            )
        restored = apply_checkpoint(self, from_checkpoint)
        if restored is not None:
            return await restored.kickoff_async(inputs=inputs, input_files=input_files)
        if self.stream:
            return self.astream(
                inputs=inputs,
                input_files=input_files,
                from_checkpoint=from_checkpoint,
                restore_from_state_id=restore_from_state_id,
            )

        self._cel_now = datetime.now(timezone.utc)

        ctx = baggage.set_baggage("flow_inputs", inputs or {})
        ctx = baggage.set_baggage("flow_input_files", input_files or {}, context=ctx)
        flow_token = attach(ctx)

        flow_id_token = None
        flow_name_token = None
        flow_defer_trace_finalization_token = None
        request_id_token = None
        # Re-published after the INPUT hook so trigger-payload injection reads
        # the hook-rewritten inputs rather than the pre-hook baggage above.
        flow_inputs_token = None
        if current_flow_id.get() is None:
            flow_id_token = current_flow_id.set(self.flow_id)
            flow_name_token = current_flow_name.set(
                self.name or self.__class__.__name__
            )
            flow_defer_trace_finalization_token = (
                current_flow_defer_trace_finalization.set(
                    self._should_defer_trace_finalization()
                )
            )
        if current_flow_request_id.get() is None:
            request_id_token = current_flow_request_id.set(self.flow_id)

        execution_token = None

        runtime_scope = crewai_event_bus._enter_runtime_scope()

        # Reentrant kickoffs on the same Flow share the outer call's
        # listener and accumulator; only the outermost call wires usage
        # aggregation.
        owns_usage_aggregation = self._usage_aggregation_handler is None
        if owns_usage_aggregation:
            self._flow_match_id = current_flow_id.get()
            self._aggregated_usage_metrics = UsageMetrics()
            self._attach_usage_aggregation_listener()

        # Pairing state is local (per invocation) so reentrant kickoffs on the
        # same instance (see usage aggregation above) each track their own
        # EXECUTION_START/EXECUTION_END dispatch independently.
        execution_start_dispatched = False
        execution_end_dispatched = False
        # Guards the failure event: everything between here and the
        # ``flow_started`` emission below (hooks, input handling, state
        # restore) can raise, and a ``flow_failed`` with no opener would pop
        # an unrelated scope.
        flow_scope_open = False

        try:
            execution_token = self._begin_trace_execution()
            from crewai.hooks.contexts import (
                ExecutionEndContext,
                ExecutionStartContext,
                InputContext,
                OutputContext,
            )
            from crewai.hooks.dispatch import HookAborted, InterceptionPoint

            # ``inputs`` aliases the same object as ``payload`` (not a fresh
            # ``{}`` from ``or``) so in-place edits survive read-back.
            try:
                boundary_ctx: InterceptionContext = ExecutionStartContext(
                    flow=self,
                    inputs=inputs if inputs is not None else {},
                    payload=inputs,
                )
                execution_start_dispatched = self._dispatch_interception(
                    InterceptionPoint.EXECUTION_START, boundary_ctx
                )
                inputs = boundary_ctx.payload

                boundary_ctx = InputContext(
                    flow=self,
                    inputs=inputs if inputs is not None else {},
                    payload=inputs,
                )
                self._dispatch_interception(InterceptionPoint.INPUT, boundary_ctx)
                inputs = boundary_ctx.payload
            except HookAborted:
                # The deny surfaces as started -> failed. Read the payload back
                # from the aborted dispatch first: earlier hooks in the chain
                # may have replaced it before a later one aborted. Then stamp
                # the state id so failure listeners correlate the record, open
                # the flow scope, and re-raise so the failure pairs with the
                # opener.
                inputs = boundary_ctx.payload
                if inputs and "id" in inputs:
                    self._stamp_state_id(inputs["id"])
                flow_scope_open = await self._open_flow_scope(inputs)
                raise

            # Publish the resolved inputs so trigger-payload injection and other
            # baggage readers observe hook rewrites (the baggage set before the
            # hooks carried the pre-hook inputs).
            flow_inputs_token = attach(baggage.set_baggage("flow_inputs", inputs or {}))

            # Reset flow state for fresh execution unless restoring from persistence
            is_restoring = (
                inputs and "id" in inputs and self.persistence is not None
            ) or self._restored_from_checkpoint
            if not is_restoring:
                # Clear completed methods and outputs for a fresh start
                self._completed_methods.clear()
                self._method_outputs.clear()
                self._pending_events.clear()
                self._clear_or_listeners()
                self._method_call_counts.clear()
            else:
                # Only enter resumption mode if there are completed methods to
                # replay.  When _completed_methods is empty (e.g. a pure
                # state-reload via kickoff(inputs={"id": ...})), the flow
                # executes from scratch and the flag would incorrectly
                # suppress cyclic re-execution on the second iteration.
                if self._completed_methods:
                    self._is_execution_resuming = True

            # Restore is single-shot: a later kickoff on the same instance
            # starts fresh.
            self._restored_from_checkpoint = False

            # Fork hydration: when restore_from_state_id is set and persistence is
            # available, hydrate self._state from the source UUID's latest snapshot
            # and reassign state.id to a fresh value so subsequent @persist writes
            # don't extend the source flow's history. If the source state is not
            # found, fall through silently to the existing inputs handling.
            fork_succeeded = False
            if restore_from_state_id is not None and self.persistence is not None:
                stored_state = self.persistence.load_state(restore_from_state_id)
                if stored_state:
                    self._log_flow_event(
                        f"Forking flow state from UUID: {restore_from_state_id}"
                    )
                    self._restore_state(stored_state)
                    # Pin to inputs["id"] when provided, otherwise mint a fresh
                    # UUID. NOTE: pinning inputs.id while forking shares a
                    # persistence key with another flow — usually you want only
                    # restore_from_state_id.
                    new_state_id = (inputs.get("id") if inputs else None) or str(
                        uuid4()
                    )
                    self._stamp_state_id(new_state_id)
                    fork_succeeded = True
                else:
                    self._log_flow_event(
                        "No flow state found for restore_from_state_id: "
                        f"{restore_from_state_id}; proceeding without hydration",
                        color="yellow",
                    )

            if inputs:
                # Override the id in the state if it exists in inputs.
                # Skip when the fork already assigned state.id above.
                if "id" in inputs and not fork_succeeded:
                    self._stamp_state_id(inputs["id"])

                # If persistence is enabled, attempt to restore the stored state using the provided id.
                # Skip when the fork already restored self._state above.
                if (
                    "id" in inputs
                    and self.persistence is not None
                    and not fork_succeeded
                    and not self._skip_persistence_restore
                ):
                    restore_uuid = inputs["id"]
                    stored_state = self.persistence.load_state(restore_uuid)
                    if stored_state:
                        self._log_flow_event(
                            f"Loading flow state from memory for UUID: {restore_uuid}"
                        )
                        self._restore_state(stored_state)
                    else:
                        self._log_flow_event(
                            f"No flow state found for UUID: {restore_uuid}",
                            color="red",
                        )

                # Update state with any additional inputs (ignoring the 'id' key)
                filtered_inputs = {k: v for k, v in inputs.items() if k != "id"}
                if filtered_inputs:
                    self._initialize_state(filtered_inputs)

            flow_scope_open = await self._open_flow_scope(inputs)

            if self._should_apply_pending_kickoff_context():
                self._apply_pending_kickoff_context()

            if inputs is not None and "id" not in inputs:
                self._initialize_state(inputs)

            if self._is_execution_resuming:
                await self._replay_recorded_events()

            try:
                # Determine which start methods to execute at kickoff
                # Conditional start methods are only triggered by their conditions
                # UNLESS there are no unconditional starts (then all starts run as entry points)
                start_methods = self._start_method_names()
                unconditional_starts = [
                    start_method
                    for start_method in start_methods
                    if self._start_condition(start_method) is None
                ]
                # If there are unconditional starts, only run those at kickoff
                # If there are NO unconditional starts, run all starts (including conditional ones)
                starts_to_execute = (
                    unconditional_starts if unconditional_starts else start_methods
                )
                starts_to_execute, run_starts_sequentially = (
                    self._order_start_methods_for_kickoff(starts_to_execute)
                )
                if run_starts_sequentially:
                    for start_method in starts_to_execute:
                        await self._execute_start_method(start_method)
                else:
                    tasks = [
                        self._execute_start_method(start_method)
                        for start_method in starts_to_execute
                    ]
                    await asyncio.gather(*tasks)
            except Exception as e:
                # Check if flow was paused for human feedback
                if isinstance(e, HumanFeedbackPending):
                    # Auto-save pending feedback (create default persistence if needed)
                    if self.persistence is None:
                        from crewai.flow.persistence.factory import (
                            default_flow_persistence,
                        )

                        self.persistence = default_flow_persistence()

                    state_data = (
                        self._state
                        if isinstance(self._state, dict)
                        else self._state.model_dump()
                    )
                    # Emit flow paused event
                    future = crewai_event_bus.emit(
                        self,
                        FlowPausedEvent(
                            type="flow_paused",
                            flow_name=self._definition.name,
                            flow_id=e.context.flow_id,
                            method_name=e.context.method_name,
                            state=self._copy_and_serialize_state(),
                            message=e.context.message,
                            emit=e.context.emit,
                        ),
                    )
                    if future and isinstance(future, Future):
                        self._event_futures.append(future)

                    # Wait for events to be processed
                    if self._event_futures:
                        await asyncio.gather(
                            *[
                                asyncio.wrap_future(f)
                                for f in self._event_futures
                                if isinstance(f, Future)
                            ]
                        )
                        self._event_futures.clear()

                    if session := get_trace_session():
                        e.context.trace_context = session.context.otel_resume_context
                    self.persistence.save_pending_feedback(
                        flow_uuid=e.context.flow_id,
                        context=e.context,
                        state_data=state_data,
                    )

                    # Return the pending exception instead of raising
                    # This allows the caller to handle the paused state gracefully
                    return e

                # Re-raise other exceptions
                raise

            # Clear the resumption flag after initial execution completes
            self._is_execution_resuming = False

            method_outputs = self.method_outputs
            final_output = method_outputs[-1] if method_outputs else None

            output_ctx = OutputContext(
                flow=self, output=final_output, payload=final_output
            )
            self._dispatch_interception(InterceptionPoint.OUTPUT, output_ctx)
            final_output = output_ctx.payload

            # EXECUTION_END runs before FlowFinishedEvent so a HookAborted
            # prevents a spurious finished signal and payload replacement is
            # honored on the emitted result and the returned value.
            end_ctx = ExecutionEndContext(
                flow=self, output=final_output, payload=final_output
            )
            # Flag set before dispatching so an EXECUTION_END hook that raises
            # HookAborted does not trigger a second (failure) dispatch below. A
            # skipped dispatch leaves it false, so it means the same as
            # ``execution_start_dispatched``.
            execution_end_dispatched = not self._skip_interception(
                InterceptionPoint.EXECUTION_END
            )
            self._dispatch_interception(InterceptionPoint.EXECUTION_END, end_ctx)
            final_output = end_ctx.payload

            if self._event_futures:
                await asyncio.gather(
                    *[asyncio.wrap_future(f) for f in self._event_futures]
                )
                self._event_futures.clear()

            # When ``defer_trace_finalization`` is set, skip both per-turn
            # ``FlowFinishedEvent`` AND trace-batch finalization. The caller
            # invokes the matching finalization hook once at session end. The
            # flag is read from either the instance attribute or an extension
            # definition.
            if not self._should_defer_trace_finalization():
                # Background memory saves must finish (and emit their
                # completed/failed events) before flow-finished triggers
                # listener teardown/finalization; the flush then waits for
                # those events' async handlers, mirroring
                # Crew._create_crew_output. Offloaded to a thread so the
                # blocking waits don't stall other coroutines on the loop.
                await asyncio.to_thread(self._drain_memory_writes)
                await asyncio.to_thread(crewai_event_bus.flush)
                future = crewai_event_bus.emit(
                    self,
                    FlowFinishedEvent(
                        type="flow_finished",
                        flow_name=self._definition.name,
                        result=final_output,
                        state=self._copy_and_serialize_state(),
                    ),
                )
                if future:
                    try:
                        await asyncio.wrap_future(future)
                    except Exception:
                        logger.warning(
                            "FlowFinishedEvent handler failed", exc_info=True
                        )

            return final_output
        except Exception as e:
            # Pairing invariant: only fire the failure EXECUTION_END when this
            # invocation's EXECUTION_START dispatched and its EXECUTION_END has
            # not (exactly-once per invocation).
            if execution_start_dispatched and not execution_end_dispatched:
                self._dispatch_execution_end_failure(e)
            if flow_scope_open:
                await self._emit_flow_failed(e)
            raise
        finally:
            # Safety net for the exception path; the success path already
            # drained before emitting FlowFinishedEvent.
            self._drain_memory_writes()
            # Drain pending LLMCallCompletedEvent handlers before
            # detaching so `flow.usage_metrics` reflects every call
            # emitted during this kickoff — mirrors `Crew.kickoff()`,
            # which flushes before reporting `token_usage`. Resume paths
            # re-attach a fresh listener via `resume_async`.
            if owns_usage_aggregation:
                crewai_event_bus.flush()
                self._detach_usage_aggregation_listener()
            if request_id_token is not None:
                current_flow_request_id.reset(request_id_token)
            if flow_defer_trace_finalization_token is not None:
                current_flow_defer_trace_finalization.reset(
                    flow_defer_trace_finalization_token
                )
            if flow_name_token is not None:
                current_flow_name.reset(flow_name_token)
            if flow_id_token is not None:
                current_flow_id.reset(flow_id_token)
            if flow_inputs_token is not None:
                detach(flow_inputs_token)
            self._end_trace_execution(execution_token)
            detach(flow_token)
            crewai_event_bus._exit_runtime_scope(runtime_scope)

    def _skip_interception(self, point: InterceptionPoint) -> bool:
        """Whether ``point`` must not be dispatched for this flow.

        Per point rather than per flow: an internal flow that is itself the
        whole run still owns that run's execution boundary, even though its
        methods are never a caller's steps.
        """
        if not type(self).is_crewai_internal:
            return False
        from crewai.hooks.dispatch import EXECUTION_BOUNDARY_POINTS

        return (
            point not in EXECUTION_BOUNDARY_POINTS
            or not self._owns_execution_boundary()
        )

    def _owns_execution_boundary(self) -> bool:
        """Whether this flow is the run the caller asked for.

        A caller's flow always is. Internal machinery is not, unless it is the
        entry point the caller invoked (``Agent.kickoff()``), which the classes
        that can be one override; the rest need nothing.
        """
        return not type(self).is_crewai_internal

    def _dispatch_interception(
        self, point: InterceptionPoint, ctx: InterceptionContext
    ) -> bool:
        """Dispatch ``point`` unless this flow must not expose it.

        Returns whether the dispatch happened, so callers can keep the
        EXECUTION_START/EXECUTION_END pairing honest on a skipped flow.
        """
        if self._skip_interception(point):
            return False
        from crewai.hooks.dispatch import dispatch

        dispatch(point, ctx)
        return True

    def _dispatch_execution_end_failure(self, error: BaseException) -> None:
        """Dispatch EXECUTION_END with status="failed" for an execution that raised.

        Callers enforce the pairing invariant (EXECUTION_START dispatched,
        EXECUTION_END not yet) with per-invocation state, so reentrant kickoffs
        on the same instance stay exactly-once. Never raises, so the original
        exception propagates unchanged.
        """
        from crewai.hooks.contexts import ExecutionEndContext
        from crewai.hooks.dispatch import InterceptionPoint

        try:
            self._dispatch_interception(
                InterceptionPoint.EXECUTION_END,
                ExecutionEndContext(flow=self, status="failed", error=error),
            )
        except Exception:  # noqa: S110 - aborting an already-failed execution is meaningless
            pass

    def _stamp_state_id(self, state_id: str) -> None:
        if isinstance(self._state, dict):
            self._state["id"] = state_id
        elif isinstance(self._state, BaseModel):
            setattr(self._state, "id", state_id)  # noqa: B010

    async def _open_flow_scope(self, inputs: dict[str, Any] | None) -> bool:
        """Emit ``FlowStartedEvent`` (or restore a deferred session's event
        scope) and return whether the flow scope is open."""
        defer_trace_finalization = self._should_defer_trace_finalization()
        deferred_started_event_id = self._deferred_flow_started_event_id
        should_emit_flow_started = not (
            defer_trace_finalization and deferred_started_event_id
        )
        flow_scope_open = False
        if (
            defer_trace_finalization
            and deferred_started_event_id
            and get_current_parent_id() is None
        ):
            restore_event_scope(((deferred_started_event_id, "flow_started"),))
            flow_scope_open = True
        elif get_current_parent_id() is None:
            reset_emission_counter()
            reset_last_event_id()

        if should_emit_flow_started:
            # In normal flows, each kickoff owns its own flow lifecycle.
            # Deferred sessions reuse the first flow scope until an
            # explicit finalization call closes the batch.
            started_event = FlowStartedEvent(
                type="flow_started",
                flow_name=self._definition.name,
                inputs=inputs,
            )
            future = crewai_event_bus.emit(self, started_event)
            flow_scope_open = True
            if future:
                try:
                    await asyncio.wrap_future(future)
                except Exception:
                    logger.warning("FlowStartedEvent handler failed", exc_info=True)
            # Stash the started event id so a deferred
            # ``finalize_session_traces()`` can restore the event scope
            # before emitting ``FlowFinishedEvent`` (otherwise the bus
            # warns "Ending event 'flow_finished' emitted with empty
            # scope stack").
            if defer_trace_finalization:
                object.__setattr__(
                    self, "_deferred_flow_started_event_id", started_event.event_id
                )
        # After FlowStarted: env events must not pre-empt trace batch init
        # with implicit "crew" execution_type.
        get_env_context()
        return flow_scope_open

    async def _emit_flow_failed(self, error: BaseException) -> None:
        """Emit ``FlowFailedEvent`` and close out the trace batch for a failed run.

        Mirrors the terminal block of the success path: drain pending event
        handlers and background memory saves so their spans close before the
        flow span does, then emit and finalize the trace batch. Never raises,
        so the original exception propagates unchanged.

        Args:
            error: The exception that ended the execution.
        """
        if self._should_defer_trace_finalization():
            return

        try:
            if self._event_futures:
                await asyncio.gather(
                    *[asyncio.wrap_future(f) for f in self._event_futures],
                    return_exceptions=True,
                )
                self._event_futures.clear()

            await asyncio.to_thread(self._drain_memory_writes)
            await asyncio.to_thread(crewai_event_bus.flush)
            future = crewai_event_bus.emit(
                self,
                FlowFailedEvent(
                    type="flow_failed",
                    flow_name=self._definition.name,
                    error=error,
                ),
            )
            if future and isinstance(future, Future):
                try:
                    await asyncio.wrap_future(future)
                except Exception:
                    logger.warning("FlowFailedEvent handler failed", exc_info=True)

        except Exception:
            logger.warning("Failed to signal flow failure", exc_info=True)

    async def akickoff(
        self,
        inputs: dict[str, Any] | None = None,
        input_files: dict[str, FileInput] | None = None,
        from_checkpoint: CheckpointConfig | None = None,
        restore_from_state_id: str | None = None,
    ) -> Any | AsyncStreamSession[Any]:
        """Native async method to start the flow execution. Alias for kickoff_async.

        Args:
            inputs: Optional dictionary containing input values and/or a state ID for restoration.
            input_files: Optional dict of named file inputs for the flow.
            from_checkpoint: Optional checkpoint config. If ``restore_from``
                is set, the flow resumes from that checkpoint.
            restore_from_state_id: Optional UUID of a previously-persisted flow
                whose latest snapshot should hydrate this run's state. See
                ``kickoff_async`` for full semantics.

        Returns:
            The final output from the flow, which is the result of the last executed method.
        """
        return await self.kickoff_async(
            inputs,
            input_files,
            from_checkpoint,
            restore_from_state_id=restore_from_state_id,
        )

    async def _replay_recorded_events(self) -> None:
        """Dispatch recorded ``MethodExecution*`` events from the event record."""
        state = crewai_event_bus.runtime_state
        if state is None:
            return
        record = state.event_record
        if len(record) == 0:
            return

        replayable = (
            MethodExecutionStartedEvent,
            MethodExecutionFinishedEvent,
            MethodExecutionFailedEvent,
        )
        flow_name = self._definition.name
        nodes = sorted(
            (
                n
                for n in record.all_nodes()
                if isinstance(n.event, replayable)
                and n.event.flow_name == flow_name
                and n.event.method_name in self._completed_methods
            ),
            key=lambda n: n.event.emission_sequence or 0,
        )

        for node in nodes:
            future = crewai_event_bus.replay(self, node.event)
            if future is not None:
                try:
                    await asyncio.wrap_future(future)
                except Exception:
                    logger.warning(
                        "Replayed event handler failed: %s",
                        node.event.type,
                        exc_info=True,
                    )

    async def _execute_start_method(self, start_method_name: FlowMethodName) -> None:
        """Executes a flow's start method and its triggered listeners.

        This internal method handles the execution of methods marked with @start
        decorator and manages the subsequent chain of listener executions.

        Args:
            start_method_name: The name of the start method to execute.

        Note:
            - Executes the start method and captures its result
            - Triggers execution of any listeners waiting on this start method
            - Part of the flow's initialization sequence
            - Skips execution if method was already completed (e.g., after reload)
            - Automatically injects crewai_trigger_payload if available in flow inputs
        """
        if start_method_name in self._completed_methods:
            if self._is_execution_resuming:
                # During resumption, skip execution but continue listeners
                method_outputs = self.method_outputs
                last_output = method_outputs[-1] if method_outputs else None
                await self._execute_listeners(start_method_name, last_output)
                return
            # For cyclic flows, clear from completed to allow re-execution
            self._completed_methods.discard(start_method_name)
            # Also clear fired OR listeners to allow them to fire again in new cycle
            self._clear_or_listeners()

        method = self._methods[start_method_name]
        enhanced_method = self._inject_trigger_payload_for_start_method(method)

        result, finished_event_id = await self._execute_method(
            start_method_name, enhanced_method
        )

        # If start method is a router, use its result as an additional trigger
        if self._is_router(start_method_name) and result is not None:
            # Execute listeners for the start method name first
            await self._execute_listeners(start_method_name, result, finished_event_id)
            # Then execute listeners for the router result (e.g., "approved")
            router_result = result.value if isinstance(result, enum.Enum) else result
            router_result_trigger = FlowMethodName(str(router_result))
            listener_result = (
                self.last_human_feedback
                if self.last_human_feedback is not None
                else result
            )
            await self._execute_listeners(
                router_result_trigger, listener_result, finished_event_id
            )
        else:
            await self._execute_listeners(start_method_name, result, finished_event_id)

    def _inject_trigger_payload_for_start_method(
        self, original_method: Callable[..., Any]
    ) -> Callable[..., Any]:
        accepts_trigger_payload = (
            "crewai_trigger_payload" in inspect.signature(original_method).parameters
        )

        def prepare_kwargs(
            *args: Any, **kwargs: Any
        ) -> tuple[tuple[Any, ...], dict[str, Any]]:
            inputs = cast(dict[str, Any], baggage.get_baggage("flow_inputs") or {})
            trigger_payload = inputs.get("crewai_trigger_payload")

            if trigger_payload is not None and accepts_trigger_payload:
                kwargs["crewai_trigger_payload"] = trigger_payload
            elif trigger_payload is not None:
                self._log_flow_event(
                    f"Trigger payload available but {original_method.__name__} doesn't accept crewai_trigger_payload parameter"
                )
            return args, kwargs

        if asyncio.iscoroutinefunction(original_method):

            async def enhanced_method(*args: Any, **kwargs: Any) -> Any:
                args, kwargs = prepare_kwargs(*args, **kwargs)
                return await original_method(*args, **kwargs)
        else:

            def enhanced_method(*args: Any, **kwargs: Any) -> Any:  # type: ignore[misc]
                args, kwargs = prepare_kwargs(*args, **kwargs)
                return original_method(*args, **kwargs)

        enhanced_method.__name__ = original_method.__name__
        enhanced_method.__doc__ = original_method.__doc__

        return enhanced_method

    async def _execute_method(
        self,
        method_name: FlowMethodName,
        method: Callable[..., Any],
        *args: Any,
        **kwargs: Any,
    ) -> tuple[Any, str | None]:
        """Execute a method and emit events.

        Returns:
            A tuple of (result, finished_event_id) where finished_event_id is
            the event_id of the MethodExecutionFinishedEvent, or None if events
            are suppressed.
        """
        try:
            dumped_params = {f"_{i}": arg for i, arg in enumerate(args)} | (
                kwargs or {}
            )

            if not self.suppress_flow_events:
                future = crewai_event_bus.emit(
                    self,
                    MethodExecutionStartedEvent(
                        type="method_execution_started",
                        method_name=method_name,
                        flow_name=self._definition.name,
                        params=dumped_params,
                        state=self._copy_and_serialize_state(),
                    ),
                )
                if future:
                    self._event_futures.append(future)

            from crewai.hooks.contexts import StepContext
            from crewai.hooks.dispatch import InterceptionPoint

            # Guarded here as well as inside the dispatch: a skipped flow must
            # not pay for building the context or reversing the param mapping.
            if not self._skip_interception(InterceptionPoint.PRE_STEP):
                pre_step_ctx = StepContext(
                    kind="flow_method",
                    step_name=str(method_name),
                    flow=self,
                    payload=dumped_params,
                )
                self._dispatch_interception(InterceptionPoint.PRE_STEP, pre_step_ctx)

                # Apply hook edits/replacement of the step params back onto the
                # call. ``dumped_params`` maps positional args to ``_0, _1, ...``
                # keys and keeps kwargs by name, so reverse that mapping here.
                updated_params = pre_step_ctx.payload
                if isinstance(updated_params, dict):
                    positional = sorted(
                        (
                            k
                            for k in updated_params
                            if k.startswith("_") and k[1:].isdigit()
                        ),
                        key=lambda k: int(k[1:]),
                    )
                    args = tuple(updated_params[k] for k in positional)
                    kwargs = {
                        k: v
                        for k, v in updated_params.items()
                        if not (k.startswith("_") and k[1:].isdigit())
                    }

            # Set method name in context so ask() can read it without
            # stack inspection.  Must happen before copy_context() so the
            # value propagates into the thread pool for sync methods.
            from crewai.flow.flow_context import current_flow_method_name

            method_name_token = current_flow_method_name.set(method_name)
            try:
                if asyncio.iscoroutinefunction(method):
                    result = await method(*args, **kwargs)
                else:
                    # Run sync methods in thread pool for isolation
                    # This allows Agent.kickoff() to work synchronously inside Flow methods
                    ctx = contextvars.copy_context()
                    result = await asyncio.to_thread(ctx.run, method, *args, **kwargs)
            finally:
                current_flow_method_name.reset(method_name_token)

            # Auto-await coroutines returned from sync methods (enables AgentExecutor pattern)
            if asyncio.iscoroutine(result):
                result = await result

            method_definition = self._definition.methods[str(method_name)]
            if method_definition.human_feedback is not None:
                result = await self._run_human_feedback_step(
                    method_name, method_definition.human_feedback, result
                )

            if not self._skip_interception(InterceptionPoint.POST_STEP):
                post_step_ctx = StepContext(
                    kind="flow_method",
                    step_name=str(method_name),
                    flow=self,
                    output=result,
                    payload=result,
                )
                self._dispatch_interception(InterceptionPoint.POST_STEP, post_step_ctx)
                result = post_step_ctx.payload

            self._method_outputs.append({"method": str(method_name), "output": result})

            # For @human_feedback methods with emit, the result is the collapsed outcome
            # (e.g., "approved") used for routing. But we want the actual method output
            # to be the stored result (for final flow output). Replace the last entry
            # if a stashed output exists, keeping the feedback alongside the output so
            # expressions read `outputs.<method>` as the full feedback result.
            # Dict-based stash is concurrency-safe.
            if method_name in self._human_feedback_method_outputs:
                feedback_result = self._human_feedback_method_outputs.pop(method_name)
                self._method_outputs[-1] = {
                    "method": str(method_name),
                    "output": feedback_result.output,
                    "human_feedback": feedback_result,
                }

            self._method_execution_counts[method_name] = (
                self._method_execution_counts.get(method_name, 0) + 1
            )

            self._completed_methods.add(method_name)

            await asyncio.to_thread(self._persist_method_completion, method_name)

            finished_event_id: str | None = None
            if not self.suppress_flow_events:
                finished_event = MethodExecutionFinishedEvent(
                    type="method_execution_finished",
                    method_name=method_name,
                    flow_name=self._definition.name,
                    state=self._copy_and_serialize_state(),
                    result=result,
                )
                finished_event_id = finished_event.event_id
                future = crewai_event_bus.emit(self, finished_event)
                if future:
                    self._event_futures.append(future)

            return result, finished_event_id
        except Exception as e:
            # Check if this is a HumanFeedbackPending exception (paused, not failed)
            if isinstance(e, HumanFeedbackPending):
                e.context.method_name = method_name

                if self.persistence is None:
                    from crewai.flow.persistence.factory import default_flow_persistence

                    self.persistence = default_flow_persistence()

                # Emit paused event (not failed)
                if not self.suppress_flow_events:
                    future = crewai_event_bus.emit(
                        self,
                        MethodExecutionPausedEvent(
                            type="method_execution_paused",
                            method_name=method_name,
                            flow_name=self._definition.name,
                            state=self._copy_and_serialize_state(),
                            flow_id=e.context.flow_id,
                            message=e.context.message,
                            emit=e.context.emit,
                        ),
                    )
                    if future:
                        self._event_futures.append(future)
            elif not self.suppress_flow_events:
                # Regular failure - emit failed event
                future = crewai_event_bus.emit(
                    self,
                    MethodExecutionFailedEvent(
                        type="method_execution_failed",
                        method_name=method_name,
                        flow_name=self._definition.name,
                        error=e,
                    ),
                )
                if future:
                    self._event_futures.append(future)
            raise e

    def _persist_method_completion(self, method_name: FlowMethodName) -> None:
        method_definition = self._definition.methods[str(method_name)]
        persist_definition = (
            method_definition.persist
            if method_definition.persist is not None
            else self._definition.persist
        )
        if persist_definition is None or not persist_definition.enabled:
            return

        from crewai.flow.persistence.decorators import PersistenceDecorator

        # An instance-supplied backend overrides definition backends; one the
        # engine derived from the flow-level definition must not shadow a
        # method-scoped persist config.
        backend = (
            self.persistence
            if self._instance_persistence and self.persistence is not None
            else self._persist_backend_for(persist_definition)
        )
        PersistenceDecorator.persist_state(
            self, method_name, backend, verbose=persist_definition.verbose
        )

    def _persist_backend_for(
        self, persist_definition: FlowPersistenceDefinition
    ) -> FlowPersistence:
        cached = self._persist_backends.get(id(persist_definition))
        if cached is None:
            cached = self._resolve_persist_backend(persist_definition)
            self._persist_backends[id(persist_definition)] = cached
        return cached

    def _resolve_persist_backend(
        self, persist_definition: FlowPersistenceDefinition
    ) -> FlowPersistence:
        if persist_definition.persistence is None:
            from crewai.flow.persistence.factory import default_flow_persistence

            return default_flow_persistence()
        resolved = _resolve_persistence(persist_definition.persistence)
        if not isinstance(resolved, FlowPersistence):
            raise ValueError(
                f"Cannot resolve persistence backend "
                f"{persist_definition.persistence!r} from the flow definition "
                f"for flow {self._definition.name!r}."
            )
        return resolved

    def _copy_and_serialize_state(self) -> dict[str, Any]:
        state_copy = self._copy_state()
        if isinstance(state_copy, BaseModel):
            try:
                return state_copy.model_dump(mode="json")
            except Exception:
                return state_copy.model_dump()
        else:
            return state_copy

    async def _execute_listeners(
        self,
        trigger_method: FlowMethodName,
        result: Any,
        triggering_event_id: str | None = None,
    ) -> None:
        """Executes all listeners and routers triggered by a method completion.

        This internal method manages the execution flow by:
        1. First executing all triggered routers sequentially
        2. Then executing all triggered listeners in parallel

        Args:
            trigger_method: The name of the method that triggered these listeners.
            result: The result from the triggering method, passed to listeners that accept parameters.
            triggering_event_id: The event_id of the MethodExecutionFinishedEvent that
                triggered these listeners, used for causal chain tracking.

        Note:
            - Routers are executed sequentially to maintain flow control
            - Each router's result becomes a new trigger_method
            - Normal listeners are executed in parallel for efficiency
            - Listeners can receive the trigger method's result as a parameter
        """
        # First, handle routers repeatedly until no router triggers anymore
        router_results = []
        router_result_payloads: dict[str, Any] = {}
        router_result_to_feedback: dict[
            str, Any
        ] = {}  # Map outcome -> HumanFeedbackResult
        current_trigger = trigger_method
        current_result = result  # Track the result to pass to each router
        current_triggering_event_id = triggering_event_id
        # Methods already run per trigger, so a conditional start that also
        # listens to the same event is not run a second time below.
        ran_for_trigger: dict[str, set[FlowMethodName]] = {}

        while True:
            routers_triggered = self._find_triggered_methods(
                current_trigger, router_only=True
            )
            if not routers_triggered:
                break
            ran_for_trigger.setdefault(str(current_trigger), set()).update(
                routers_triggered
            )

            for router_name in routers_triggered:
                # For routers triggered by a router outcome, pass the HumanFeedbackResult
                router_input = router_result_to_feedback.get(
                    str(current_trigger), current_result
                )
                (
                    router_result,
                    current_triggering_event_id,
                ) = await self._execute_single_listener(
                    router_name, router_input, current_triggering_event_id
                )
                if router_result is None:
                    current_trigger = FlowMethodName("")
                    continue

                router_result = (
                    router_result.value
                    if isinstance(router_result, enum.Enum)
                    else router_result
                )
                router_result_str = str(router_result)
                router_result_event = FlowMethodName(router_result_str)
                router_results.append(router_result_event)
                router_result_payloads[router_result_str] = (
                    self.last_human_feedback
                    if self.last_human_feedback is not None
                    else router_result
                )

                if self.last_human_feedback is not None:
                    router_result_to_feedback[router_result_str] = (
                        self.last_human_feedback
                    )
                current_trigger = router_result_event

        all_triggers = [trigger_method, *router_results]

        with self._or_listeners_lock:
            rearmable: set[FlowMethodName] = set(self._fired_or_listeners)

        for idx, current_trigger in enumerate(all_triggers):
            if current_trigger:
                if idx > 0 and rearmable:
                    self._rearm_or_listeners_for_trigger(current_trigger, rearmable)
                listeners_triggered = self._find_triggered_methods(
                    current_trigger, router_only=False
                )
                ran_for_trigger.setdefault(str(current_trigger), set()).update(
                    listeners_triggered
                )
                if listeners_triggered:
                    listener_result = router_result_payloads.get(
                        str(current_trigger), result
                    )
                    racing_group = self._get_racing_group_for_listeners(
                        listeners_triggered
                    )
                    if racing_group:
                        racing_members, _ = racing_group
                        other_listeners = [
                            name
                            for name in listeners_triggered
                            if name not in racing_members
                        ]
                        await self._execute_racing_listeners(
                            racing_members,
                            other_listeners,
                            listener_result,
                            current_triggering_event_id,
                        )
                    else:
                        tasks = [
                            self._execute_single_listener(
                                listener_name,
                                listener_result,
                                current_triggering_event_id,
                            )
                            for listener_name in listeners_triggered
                        ]
                        await asyncio.gather(*tasks)

                if current_trigger in router_results:
                    for method_name in self._start_method_names():
                        if self._start_condition_triggered_by(
                            method_name, current_trigger
                        ) and method_name not in ran_for_trigger.get(
                            str(current_trigger), set()
                        ):
                            if method_name in self._completed_methods:
                                # Cyclic re-execution: temporarily clear resumption flag so the method actually re-runs
                                was_resuming = self._is_execution_resuming
                                self._is_execution_resuming = False
                                await self._execute_start_method(method_name)
                                self._is_execution_resuming = was_resuming
                            else:
                                await self._execute_start_method(method_name)

    def _condition_met(
        self,
        condition: FlowDefinitionCondition,
        trigger_method: FlowMethodName,
        subscription_key: PendingListenerKey,
    ) -> bool:
        seen = self._pending_events.setdefault(subscription_key, set())
        seen.add(str(trigger_method))
        if not _condition_satisfied(condition, seen):
            return False
        del self._pending_events[subscription_key]
        return True

    def _find_triggered_methods(
        self, trigger_method: FlowMethodName, router_only: bool
    ) -> list[FlowMethodName]:
        triggered: list[FlowMethodName] = []

        for listener_name, method_definition, condition in self._listener_methods():
            is_router = method_definition.router
            if router_only != is_router:
                continue

            should_check_fired = _is_multi_event_or(condition) and not is_router
            if should_check_fired and listener_name in self._fired_or_listeners:
                continue

            if self._condition_met(
                condition, trigger_method, PendingListenerKey(str(listener_name))
            ):
                triggered.append(listener_name)
                if should_check_fired:
                    self._fired_or_listeners.add(listener_name)

        return triggered

    async def _execute_single_listener(
        self,
        listener_name: FlowMethodName,
        result: Any,
        triggering_event_id: str | None = None,
    ) -> tuple[Any, str | None]:
        """Executes a single listener method with proper event handling.

        This internal method manages the execution of an individual listener,
        including parameter inspection, event emission, and error handling.

        Args:
            listener_name: The name of the listener method to execute.
            result: The result from the triggering method, which may be passed to the listener if it accepts parameters.
            triggering_event_id: The event_id of the event that triggered this listener,
                used for causal chain tracking.

        Returns:
            A tuple of (listener_result, event_id) where listener_result is the return
            value of the listener method and event_id is the MethodExecutionFinishedEvent
            id, or (None, None) if skipped during resumption.

        Note:
            - Inspects method signature to determine if it accepts the trigger result
            - Emits events for method execution start and finish
            - Handles errors gracefully with detailed logging
            - Recursively triggers listeners of this listener
            - Supports both parameterized and parameter-less listeners
            - Skips execution if method was already completed (e.g., after reload)
            - Catches and logs any exceptions during execution, preventing individual listener failures from breaking the entire flow
        """
        count = self._method_call_counts.get(listener_name, 0) + 1
        if count > self.max_method_calls:
            raise RecursionError(
                f"Method '{listener_name}' has been called {self.max_method_calls} times in "
                f"this flow execution, which indicates an infinite loop. "
                f"This commonly happens when a @listen label matches the "
                f"method's own name."
            )
        self._method_call_counts[listener_name] = count

        if listener_name in self._completed_methods:
            if self._is_execution_resuming:
                # During resumption, skip execution but continue listeners
                await self._execute_listeners(listener_name, None)

                # For routers, also check if any conditional starts they triggered are completed
                # If so, continue their chains
                if self._is_router(listener_name):
                    for start_method_name in self._start_method_names():
                        if (
                            self._start_condition(start_method_name) is not None
                            and start_method_name in self._completed_methods
                        ):
                            # This conditional start was executed, continue its chain
                            await self._execute_start_method(start_method_name)
                return (None, None)
            # For cyclic flows, clear from completed to allow re-execution
            self._completed_methods.discard(listener_name)
            # Clear ALL fired OR listeners so they can fire again in the new cycle.
            # This mirrors what _execute_start_method does for start-method cycles.
            # Only discarding the individual listener is insufficient because
            # downstream or_() listeners (e.g., method_a listening to
            # or_(handler_a, handler_b)) would remain suppressed across iterations.
            self._clear_or_listeners()

        try:
            method = self._methods[listener_name]

            sig = inspect.signature(method)
            method_params = [p for p in sig.parameters.values() if p.name != "self"]

            if triggering_event_id:
                with triggered_by_scope(triggering_event_id):
                    if method_params:
                        listener_result, finished_event_id = await self._execute_method(
                            listener_name, method, result
                        )
                    else:
                        listener_result, finished_event_id = await self._execute_method(
                            listener_name, method
                        )
            else:
                if method_params:
                    listener_result, finished_event_id = await self._execute_method(
                        listener_name, method, result
                    )
                else:
                    listener_result, finished_event_id = await self._execute_method(
                        listener_name, method
                    )

            await self._execute_listeners(
                listener_name, listener_result, finished_event_id
            )

            return (listener_result, finished_event_id)

        except Exception as e:
            # Don't log HumanFeedbackPending as an error - it's expected control flow
            if not isinstance(e, HumanFeedbackPending):
                if not getattr(e, "_flow_listener_logged", False):
                    logger.error(f"Error executing listener {listener_name}: {e}")
                    e._flow_listener_logged = True  # type: ignore[attr-defined]
            raise

    def _resolve_input_provider(self) -> InputProvider:
        """Resolve the input provider using the priority chain.

        Resolution order:
        1. ``self.input_provider`` (per-flow override)
        2. ``flow_config.input_provider`` (global default)
        3. ``ConsoleInputProvider()`` (built-in fallback)

        Returns:
            An object implementing the ``InputProvider`` protocol.
        """
        from crewai.flow.async_feedback.providers import ConsoleProvider
        from crewai.flow.flow_config import flow_config

        if self.input_provider is not None:
            return self.input_provider
        if flow_config.input_provider is not None:
            return flow_config.input_provider
        return cast(InputProvider, ConsoleProvider())

    def _checkpoint_state_for_ask(self) -> None:
        """Auto-checkpoint flow state before waiting for user input.

        If persistence is configured, saves the current state so that
        ``self.state`` is recoverable even if the process crashes while
        waiting for input.

        This is best-effort: if persistence is not configured, this is a no-op.
        """
        if self.persistence is None:
            return
        try:
            state_data = (
                self._state
                if isinstance(self._state, dict)
                else self._state.model_dump()
            )
            self.persistence.save_state(
                flow_uuid=self.flow_id,
                method_name="_ask_checkpoint",
                state_data=state_data,
            )
        except Exception:
            logger.debug("Failed to checkpoint state before ask()", exc_info=True)

    def ask(
        self,
        message: str,
        timeout: float | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> str | None:
        """Request input from the user during flow execution.

        Blocks the current thread until the user provides input or the
        timeout expires. Works in both sync and async flow methods (the
        flow framework runs sync methods in a thread pool via
        ``asyncio.to_thread``, so the event loop stays free).

        Timeout ensures flows always terminate. When timeout expires,
        ``None`` is returned, enabling the pattern::

            while (msg := self.ask("You: ", timeout=300)) is not None:
                process(msg)

        Before waiting for input, the current ``self.state`` is automatically
        checkpointed to persistence (if configured) for durability.

        Args:
            message: The question or prompt to display to the user.
            timeout: Maximum seconds to wait for input. ``None`` means
                wait indefinitely. When timeout expires, returns ``None``.
                Note: timeout is best-effort for the provider call --
                ``ask()`` returns ``None`` promptly, but the underlying
                ``request_input()`` may continue running in a background
                thread until it completes naturally. Network providers
                should implement their own internal timeouts.
            metadata: Optional metadata to send to the input provider,
                such as user ID, channel, session context. The provider
                can use this to route the question to the right recipient.

        Returns:
            The user's input as a string, or ``None`` on timeout, disconnect,
            or provider error. Empty string ``""`` means the user pressed
            Enter without typing (intentional empty input).

        Example:
            ```python
            class MyFlow(Flow):
                @start()
                def gather_info(self):
                    topic = self.ask(
                        "What topic should we research?",
                        metadata={"user_id": "u123", "channel": "#research"},
                    )
                    if topic is None:
                        return "No input received"
                    return topic
            ```
        """
        from concurrent.futures import (
            ThreadPoolExecutor,
            TimeoutError as FuturesTimeoutError,
        )

        from crewai.events.types.flow_events import (
            FlowInputReceivedEvent,
            FlowInputRequestedEvent,
        )
        from crewai.flow.flow_context import current_flow_method_name
        from crewai.flow.input_provider import InputResponse

        method_name = current_flow_method_name.get("unknown")

        crewai_event_bus.emit(
            self,
            FlowInputRequestedEvent(
                type="flow_input_requested",
                flow_name=self._definition.name,
                method_name=method_name,
                message=message,
                metadata=metadata,
            ),
        )

        self._checkpoint_state_for_ask()

        provider = self._resolve_input_provider()
        raw: str | InputResponse | None = None

        try:
            if timeout is not None:
                # Manual executor management to avoid shutdown(wait=True)
                # deadlock when the provider call outlives the timeout.
                executor = ThreadPoolExecutor(max_workers=1)
                ctx = contextvars.copy_context()
                future = executor.submit(
                    ctx.run, provider.request_input, message, cast(Any, self), metadata
                )
                try:
                    raw = future.result(timeout=timeout)
                except FuturesTimeoutError:
                    future.cancel()
                    raw = None
                finally:
                    # wait=False so we don't block if the provider is still
                    # running (e.g. input() stuck waiting for user).
                    # cancel_futures=True cleans up any queued-but-not-started tasks.
                    executor.shutdown(wait=False, cancel_futures=True)
            else:
                raw = provider.request_input(
                    message, cast(Any, self), metadata=metadata
                )
        except KeyboardInterrupt:
            raise
        except Exception:
            logger.debug("Input provider error in ask()", exc_info=True)
            raw = None

        response: str | None = None
        response_metadata: dict[str, Any] | None = None

        if isinstance(raw, InputResponse):
            response = raw.text
            response_metadata = raw.metadata
        elif isinstance(raw, str):
            response = raw
        else:
            response = None

        self._input_history.append(
            {
                "message": message,
                "response": response,
                "method_name": method_name,
                "timestamp": datetime.now(),
                "metadata": metadata,
                "response_metadata": response_metadata,
            }
        )

        crewai_event_bus.emit(
            self,
            FlowInputReceivedEvent(
                type="flow_input_received",
                flow_name=self._definition.name,
                method_name=method_name,
                message=message,
                response=response,
                metadata=metadata,
                response_metadata=response_metadata,
            ),
        )

        return response

    async def _run_human_feedback_step(
        self,
        method_name: FlowMethodName,
        feedback_definition: FlowHumanFeedbackDefinition,
        method_output: Any,
    ) -> Any:
        llm = feedback_definition.llm
        emit = feedback_definition.emit
        default_outcome = feedback_definition.default_outcome
        metadata = feedback_definition.metadata
        learn = feedback_definition.learn and self.memory is not None
        llm_instance = _resolve_llm_instance(llm) if (emit or learn) else llm

        if learn:
            method_output = await asyncio.to_thread(
                _pre_review_with_lessons,
                self,
                method_name,
                method_output,
                llm=llm_instance,
                learn_source=feedback_definition.learn_source,
                learn_strict=feedback_definition.learn_strict,
            )

        provider = self._resolve_feedback_provider(feedback_definition)
        if provider is not None:
            context = PendingFeedbackContext(
                flow_id=self.flow_id or "unknown",
                flow_class=f"{type(self).__module__}.{type(self).__name__}",
                method_name=method_name,
                method_output=method_output,
                message=feedback_definition.message,
                emit=list(emit) if emit else None,
                default_outcome=default_outcome,
                metadata=metadata or {},
                llm=llm
                if llm is None or isinstance(llm, (str, dict))
                else _serialize_llm_for_context(llm),
                execution_uuid=get_execution_uuid(),
            )
            feedback_value = await asyncio.to_thread(
                provider.request_feedback, context, self
            )
            if asyncio.iscoroutine(feedback_value):
                feedback_value = await feedback_value
            raw_feedback = str(feedback_value)
        else:
            raw_feedback = await asyncio.to_thread(
                self._request_human_feedback,
                message=feedback_definition.message,
                output=method_output,
                metadata=metadata,
                emit=emit,
                method_name=method_name,
            )

        result = await self._finalize_human_feedback(
            method_name=method_name,
            method_output=method_output,
            raw_feedback=raw_feedback,
            emit=emit,
            default_outcome=default_outcome,
            llm=llm_instance,
            metadata=metadata or {},
        )

        await self._store_feedback_lessons(
            feedback_definition, method_name, method_output, raw_feedback, llm_instance
        )

        if emit:
            # Stash the feedback result: the collapsed outcome routes listeners,
            # but the flow's final result stays the method's actual return
            # value (result.output).
            self._human_feedback_method_outputs[method_name] = result
            return result.outcome
        return result

    async def _store_feedback_lessons(
        self,
        feedback_definition: FlowHumanFeedbackDefinition,
        method_name: str,
        method_output: Any,
        raw_feedback: str,
        llm: Any,
    ) -> None:
        if not (
            feedback_definition.learn
            and self.memory is not None
            and raw_feedback.strip()
        ):
            return
        await asyncio.to_thread(
            _distill_and_store_lessons,
            self,
            method_name,
            method_output,
            raw_feedback,
            llm=llm,
            learn_source=feedback_definition.learn_source,
            learn_strict=feedback_definition.learn_strict,
        )

    async def _finalize_human_feedback(
        self,
        *,
        method_name: str,
        method_output: Any,
        raw_feedback: str,
        emit: list[str] | None,
        default_outcome: str | None,
        llm: Any,
        metadata: dict[str, Any],
    ) -> HumanFeedbackResult:
        collapsed_outcome: str | None = None
        if not raw_feedback.strip():
            if default_outcome:
                collapsed_outcome = default_outcome
            elif emit:
                collapsed_outcome = emit[0]
        elif emit:
            collapse_llm = _resolve_llm_instance(llm)
            if collapse_llm is None:
                raise HumanFeedbackCollapseError(
                    "Could not resolve an LLM to classify human feedback. "
                    "Set llm= on @human_feedback or MODEL / MODEL_NAME / "
                    "OPENAI_MODEL_NAME."
                )
            collapsed_outcome = await asyncio.to_thread(
                self._collapse_to_outcome,
                feedback=raw_feedback,
                outcomes=emit,
                llm=collapse_llm,
            )
        if emit and collapsed_outcome is None:
            raise HumanFeedbackCollapseError(
                f"Could not classify human feedback into one of {list(emit)}."
            )

        result = HumanFeedbackResult(
            output=method_output,
            feedback=raw_feedback,
            outcome=collapsed_outcome,
            method_name=method_name,
            metadata=metadata,
        )
        self.human_feedback_history.append(result)
        self.last_human_feedback = result
        return result

    def _resolve_feedback_provider(
        self, feedback_definition: FlowHumanFeedbackDefinition
    ) -> Any:
        provider = feedback_definition.provider
        if isinstance(provider, str):
            provider = _resolve_instance_ref(provider, field="human_feedback.provider")
        if provider is None:
            from crewai.flow.flow_config import flow_config

            provider = flow_config.hitl_provider
        if provider is not None and not isinstance(provider, HumanFeedbackProvider):
            raise ValueError(
                f"human_feedback.provider {feedback_definition.provider!r} for flow "
                f"{self._definition.name!r} does not implement the "
                "HumanFeedbackProvider protocol (missing request_feedback)."
            )
        return provider

    def _request_human_feedback(
        self,
        message: str,
        output: Any,
        metadata: dict[str, Any] | None = None,
        emit: Sequence[str] | None = None,
        method_name: str = "",
    ) -> str:
        """Request feedback from a human.
        Args:
            message: The message to display when requesting feedback.
            output: The method output to show the human for review.
            metadata: Optional metadata for enterprise integrations.
            emit: Optional list of possible outcomes for routing.
            method_name: The flow method whose output is under review.

        Returns:
            The human's feedback as a string. Empty string if no feedback provided.
        """
        from crewai.events.event_listener import event_listener
        from crewai.events.types.flow_events import (
            HumanFeedbackReceivedEvent,
            HumanFeedbackRequestedEvent,
        )

        crewai_event_bus.emit(
            self,
            HumanFeedbackRequestedEvent(
                type="human_feedback_requested",
                flow_name=self._definition.name,
                method_name=method_name,
                output=output,
                message=message,
                emit=list(emit) if emit else None,
            ),
        )

        formatter = event_listener.formatter
        formatter.pause_live_updates()

        try:
            formatter.console.print("\n" + "═" * 50, style="bold cyan")
            formatter.console.print("  OUTPUT FOR REVIEW", style="bold cyan")
            formatter.console.print("═" * 50 + "\n", style="bold cyan")
            formatter.console.print(output)
            formatter.console.print("\n" + "═" * 50 + "\n", style="bold cyan")

            formatter.console.print(message, style="yellow")
            formatter.console.print(
                "(Press Enter to skip, or type your feedback)\n", style="cyan"
            )

            feedback = input("Your feedback: ").strip()

            crewai_event_bus.emit(
                self,
                HumanFeedbackReceivedEvent(
                    type="human_feedback_received",
                    flow_name=self._definition.name,
                    method_name=method_name,
                    feedback=feedback,
                    outcome=None,  # Will be determined after collapsing
                ),
            )

            return feedback
        finally:
            formatter.resume_live_updates()

    def _collapse_to_outcome(
        self,
        feedback: str,
        outcomes: Sequence[str],
        llm: str | BaseLLM,
    ) -> str:
        """Collapse free-form feedback to a predefined outcome using LLM.

        This method uses the specified LLM to interpret the human's feedback
        and map it to one of the predefined outcomes for routing purposes.

        Uses structured outputs (function calling) when supported by the LLM
        to guarantee the response is one of the valid outcomes. Falls back
        to simple prompting if structured outputs fail.

        Args:
            feedback: The raw human feedback text.
            outcomes: Sequence of valid outcome strings to choose from.
            llm: The LLM model to use. Can be a model string or BaseLLM instance.

        Returns:
            One of the outcome strings that best matches the feedback intent.

        Raises:
            HumanFeedbackCollapseError: If the LLM cannot be called or its
                response cannot be mapped to one of ``outcomes``.
        """
        from typing import Literal

        from pydantic import BaseModel, Field

        from crewai.hooks.dispatch import HookAborted
        from crewai.llm import LLM
        from crewai.llms.base_llm import BaseLLM as BaseLLMClass
        from crewai.utilities.i18n import I18N_DEFAULT

        llm_instance: BaseLLMClass
        if isinstance(llm, str):
            llm_instance = LLM(model=llm)
        elif isinstance(llm, BaseLLMClass):
            llm_instance = llm
        else:
            raise ValueError(f"Invalid llm type: {type(llm)}. Expected str or BaseLLM.")

        outcomes_tuple = tuple(outcomes)

        class FeedbackOutcome(BaseModel):
            """The outcome that best matches the human's feedback intent."""

            outcome: Literal[outcomes_tuple] = Field(  # type: ignore[valid-type]
                description=f"The outcome that best matches the feedback. Must be one of: {', '.join(outcomes)}"
            )

        prompt_template = I18N_DEFAULT.slice("human_feedback_collapse")

        prompt = prompt_template.format(
            feedback=feedback,
            outcomes=", ".join(outcomes),
        )

        try:
            # NOTE: LLM.call with response_model returns JSON string, not a Pydantic model
            response = llm_instance.call(
                messages=[{"role": "user", "content": prompt}],
                response_model=FeedbackOutcome,
            )
        except HookAborted:
            raise
        except Exception as e:
            logger.warning(
                f"Structured output failed, falling back to simple prompting: {e}"
            )
            try:
                response = llm_instance.call(
                    messages=[{"role": "user", "content": prompt}],
                )
            except HookAborted:
                raise
            except Exception as fallback_err:
                raise HumanFeedbackCollapseError(
                    f"Could not classify human feedback into {list(outcomes)}: "
                    f"{fallback_err}"
                ) from fallback_err
            return _require_collapse_outcome(str(response), outcomes)

        if isinstance(response, str):
            import json

            try:
                parsed = json.loads(response)
            except json.JSONDecodeError:
                return _require_collapse_outcome(response, outcomes)
            if isinstance(parsed, dict):
                outcome = parsed.get("outcome")
                if isinstance(outcome, str):
                    return _require_collapse_outcome(outcome, outcomes)
            return _require_collapse_outcome(response, outcomes)
        if isinstance(response, FeedbackOutcome):
            return str(response.outcome)
        if hasattr(response, "outcome"):
            return _require_collapse_outcome(str(response.outcome), outcomes)
        raise HumanFeedbackCollapseError(
            f"Unexpected collapse response type: {type(response)}"
        )

    def _log_flow_event(
        self,
        message: str,
        color: str = "yellow",
        level: Literal["info", "warning"] = "info",
    ) -> None:
        """Centralized logging method for flow events.

        This method provides a consistent interface for logging flow-related events,
        combining both console output with colors and proper logging levels.

        Args:
            message: The message to log
            color: Rich style for console output (default: "yellow")
                  Examples: "yellow", "red", "bold green", "bold magenta"
            level: Log level to use (default: info)
                  Supported levels: info, warning

        Note:
            This method uses the centralized Rich console formatter for output
            and the standard logging module for log level support.
        """
        from crewai.events.event_listener import event_listener

        event_listener.formatter.console.print(message, style=color)
        if level == "info":
            logger.info(message)
        else:
            logger.warning(message)

    def plot(self, filename: str = "crewai_flow.html", show: bool = True) -> str:
        """Create interactive HTML visualization of Flow structure.

        Args:
            filename: Output HTML filename (default: "crewai_flow.html").
            show: Whether to open in browser (default: True).

        Returns:
            Absolute path to generated HTML file.
        """
        crewai_event_bus.emit(
            self,
            FlowPlotEvent(
                type="flow_plot",
                flow_name=self._definition.name,
            ),
        )
        structure = build_flow_structure(cast(Any, self))
        return render_interactive(structure, filename=filename, show=show)

    @staticmethod
    def _show_tracing_disabled_message() -> None:
        """Show a message when tracing is disabled."""
        if should_suppress_tracing_messages():
            return

        console = Console()

        if has_user_declined_tracing():
            message = """Info: Tracing is disabled.

To enable tracing, do any one of these:
• Set tracing=True in your Flow code
• Set CREWAI_TRACING_ENABLED=true in your project's .env file
• Run: crewai traces enable"""
        else:
            message = """Info: Tracing is disabled.

To enable tracing, do any one of these:
• Set tracing=True in your Flow code
• Set CREWAI_TRACING_ENABLED=true in your project's .env file
• Run: crewai traces enable"""

        panel = Panel(
            message,
            title="Tracing Status",
            border_style="blue",
            padding=(1, 2),
        )
        console.print(panel)
