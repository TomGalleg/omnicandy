# CreateCraft: current progress (review package)

Updated: 2026-10-17 · Branch: `main` (local commits only, **no remote, nothing pushed**) · Windows is the primary platform; Linux is maintained from the
same codebase (see "Linux compatibility" at the end of this file).

CreateCraft is a Windows-first desktop app (Electron + React + TypeScript) that embeds and drives the 13 first-party Craft apps (PhotoCraft,
VectorCraft, SoundCraft, FilmCraft, LightCraft, EffectCraft, DesignCraft, WordCraft, PDFCraft, GridCraft, DeckCraft, FigCraft, CADCraft) with Claude as a
Creative Partner, plus third-party software (Blender, FreeCAD, Revit, DaVinci Resolve) through an adapter framework, and a Project Planner.

**How to read this file.** The dated sections from "Craft app stability fixes (2026-10-15)" down to "Linux compatibility" are the current picture.
Everything between this header and those sections (the master-plan table, the per-phase notes and sections 1-10) is the **historical record of
2026-10-14**: it is kept because its evidence (tests, screenshots, commands) is still valid for what it describes, but its counts, "next milestones"
and "not implemented" lists are superseded by the summary below. For a one-page snapshot use `docs/STATUS_FOR_ANALYSIS.md`; for each subsystem see
the matching file in `docs/`.

**Status labels used below**

| Label | Meaning |
|---|---|
| **WORKING** | Implemented and verified against the real installed apps or services on this PC (tests and/or end-to-end smoke runs listed). |
| **PARTIAL** | Implemented but with known gaps, or only verified in part. |
| **MOCK** | Present in the UI but backed by a labelled mock; no real work is done. |
| **NOT IMPLEMENTED** | Not built yet. |

Evidence for each integration (exact commands, versions and test results) is in `docs/integration-audit.md` (the "Integration truth table").

## Where things stand (2026-10-17)

| Area | Status |
|---|---|
| Core app: projects in user-chosen folders, Home with Claude-created projects, Simplified/Advanced navigation, docks, themes, live control of the Craft apps, multi-clip editing, Deliver, workflow editor and shared engine, 11 built-in templates | **WORKING** (Phases 0-5 and 8 of the master plan; verified on the real installed apps in 2026-10-14) |
| Paid AI generation: OpenAI image, Gemini image, Veo video | **WORKING**, one approved real run each (2026-10-14); spending limit and ledger. Runway built, not live-tested; Luma **NOT IMPLEMENTED** |
| Local free video (Wan via stable-diffusion.cpp/Vulkan) and the free "motion" render | **WORKING** on this PC's GPU for the listed models only |
| External integrations: adapter SDK, `.ccadapter` packages, Universal Connect, universal installer, plugin bridge | **WORKING**; real software verified: Blender 4.0.2, FreeCAD 1.1.4, Autodesk Revit 2027. DaVinci Resolve **PARTIAL** (adapter exists, commands never live-verified on this PC). Other Autodesk/Adobe profiles are data and docs only |
| AI Adapter Builder | **PARTIAL**: proven on real FreeCAD with a scripted blueprint; the in-app live-Claude author path is only exercised by an opt-in test that spends Claude usage |
| Project Planner (workspace, copy-and-paste handoff, MCP server, in-app Claude tools) | **WORKING** in automated runs only (`smoke-planner` 22/22 on Windows and on Linux); not yet used by hand; no model-driven client session has used the MCP tools |
| Linux (Ubuntu 24.04 on WSL2) | **PARTIAL**: unit tests, Planner/MCP, `smoke-linux` and several UI smokes pass; no Craft apps exist for Linux; AppImage/deb **not built**; AMD/Vulkan/local AI and Claude sign-in not tested. Postponed by decision |
| Installer, signing, first-run, backup and recovery, updates (master plan Phase 10) | **NOT IMPLEMENTED** (NSIS and Linux packaging configuration exist; no signed installer was built) |

**Tests.** `npm run check` (eslint, both tsc projects, Vitest) is the gate. Counts change with every feature, so see the dated sections for the number
at the time. The last count recorded for Windows is in "Linux compatibility" below (640 passed / 62 skipped on 2026-10-17); the 62 skips are opt-in live
tests that need installed apps, a running Resolve, the network or paid Claude calls. Two older live PhotoCraft SVG tests are known failures when live
tests are enabled. Most smoke scripts passed when written; only the Planner and navigation smokes are known to have been re-run after the latest changes.

**Known gaps (current).** Nothing is backed up remotely; the Planner has had no hand use; packaging is not finished; adapter isolation is Node's
permission model, not an OS sandbox; DesignCraft text colour is black/white only; the multi-clip strip has no drag-and-drop; no MP3 export; native
confirmation dialogs were answered by script, not by a human. See `docs/STATUS_FOR_ANALYSIS.md` section 4.

**Resume here (new conversation).** Follow Tomas's Master Development Instructions (phases 0-10). Done: Phases 0-8 (audit, docks and settings, project
storage, Project Home and AI-first creation, Simplified/Advanced navigation, Claude-driven workflows, real image generation, Veo video, templates), then
the external integration work (framework, installer, Revit, Builder) and the Planner. Open: Phase 9 documentation refresh (this file and the README are
being brought in line) and Phase 10 (installer, first run, backup, recovery). Working agreement: develop and debug on Windows, local commits only, no
push, no paid calls without approval; after changes to shared components or platform behaviour, run the Linux tests too (workflow in
`docs/linux-compatibility.md`). Keep work in small milestones and replies short.

> Historical record (2026-10-14) from here to the "Craft app stability fixes (2026-10-15)" section. Superseded items are marked where they matter.

## Master plan status (Phase 0 audit, 2026-10-14; historical)

Verified against the code at `fab6ab7` plus the Phase 1 commit. Baseline before changes: lint 0,
typecheck 0, Vitest 135 passed / 14 skipped (opt-in live tests).

| Phase | Item | Status | Depends on | Acceptance test |
|---|---|---|---|---|
| 1.1 | Header status chips moved out of the header | **WORKING** | none | `scripts/smoke-docks.mjs` |
| 1.1 | Settings dialog: Appearance, Integrations (ArtCraft, Claude, AI keys), Advanced diagnostics | **WORKING** | none | `smoke-docks.mjs` |
| 1.2 | Vertical Media tab (far left) and Claude tab (left edge of Claude panel); collapse/expand, resize, remembered width and state, Ctrl+Shift+M / Ctrl+Shift+C, aria labels | **WORKING** | none | `smoke-docks.mjs` 15/15; embedded app follows: `smoke-live.mjs` |
| 1.3 | Collapsible inspector, metadata in an expandable section, smaller Activity panel, plainer labels | **WORKING** | 1.2 | `smoke-docks.mjs`; screenshots 01, 42-45 |
| 1.4 | Workflow Editor: collapsible side panels, Fit/auto layout, running-node highlight, approval expands | **WORKING** | 1.2 | `smoke-workflow.mjs` 7/7, `workflowLayout.test.ts`; screenshots 95-96 |
| 2.1 | Default project folder in Settings, Projects & Storage (Browse, Open folder, write check, free space, per-project folder when creating) | **WORKING** | 1 | `projects.test.ts`, `smoke-projects.mjs` |
| 2.2 | Self-contained project folder layout (Assets/, Versions/, Exports/, Workflows/, per-app folders...) | **WORKING** for new projects; older projects keep their layout | 2.1 | `projectStore.test.ts`, `projects.test.ts` |
| 2.3 | Open existing project from any folder, Duplicate, verified Move, Locate a missing project | **WORKING** (relink of individual missing files: n/a, files are copied into the project) | 2.1 | `projects.test.ts` |
| 2.4 | Virtual collections (All, Originals, AI, Favorites, Versions, Workflows, Deliverables) | **WORKING** | 2.2 | `collections.test.ts` |
| 3.1 | Prompt-first Project Home: prompt, Create with Claude, New blank project, Open existing, recent project cards with type/brief, search | **WORKING** (Templates button enabled in Phase 8) | 2 | `smoke-projects.mjs` 13/13 |
| 3.2 | AI-first creation: real Claude call returns name, type, finished output, apps, AI tools, steps, questions; user approves; project created in chosen/default folder; optional reference import; opens matching workspace | **WORKING** (one real Claude call verified) | 3.1 | `smoke-home-ai.mjs` 6/6 (real Claude, Sonnet 5.5) |
| 3.3 | Blank project: name, type (5 categories), folder | **WORKING** | 3.1 | `projects.test.ts`, `smoke-projects.mjs` |
| 3.4 | Project Overview: brief, objective, progress, latest artwork, items to review, recent versions/exports, Continue creating, workspace + selected file restored | **WORKING**: Claude chat is saved in the project folder and restored on reopen (see "Phase 3 gaps closed") | 3.1 | `projects.test.ts`, `projectStore.test.ts`, `smoke-home-ai.mjs`, screenshots 46-47 |
| 4 | Simplified / Advanced navigation | **WORKING** | 1, 3 | `navigation.test.ts`, `smoke-nav.mjs` 7/7 |
| 5 | Claude builds and runs workflows (shared engine) | **WORKING** (paid AI Generate steps stay blocked until Phase 6) | 1.4 | `workflowPlan.test.ts`, `workflowControl.test.ts`, `workflowVersions.test.ts`, `smoke-claude-workflow.mjs` 9/9, `smoke-workflow-control.mjs` 32/32 (real Claude + real PhotoCraft) |
| 6 | Real Gemini / OpenAI image generation; spending limits; Workflow AI node | **WORKING / VERIFIED** (2026-10-14): one approved real image from each provider (OpenAI `gpt-image-2.5-flare`, Gemini `gemini-nano-banana-2.1`), 1024x1024, in the library with prompt/model/estimate; spending limit + ledger; Workflow AI step on the real path. Costs are estimates, not confirmed charges. | user's keys + OK | done |
| 7 | AI video providers (Veo, Runway, Luma) | **WORKING / VERIFIED (Veo)** 2026-10-14: one approved real clip (Veo 3.1 Lite, 16:9, 4 s, 720p, est. $0.20) came back as a 1280x720 4 s mp4 in the library with provenance and ledger entry. Runway built but not live-tested; Luma not built. | 6 | one approved real Veo clip |
| 8 | Templates | **WORKING** (2026-10-14): nine built-in templates on the shared workflow engine, Home Templates panel, Claude recommendation, user templates. Not run end to end with real files in this phase. | 5 | `templates.test.ts`, `smoke-templates.mjs` 6/6 |
| 9 | README / docs refresh, status vocabulary | PARTIAL (README out of date) | any | review |
| 10 | Installer, first run, backup, recovery | NOT IMPLEMENTED | 2 | manual |

Phase 1 tests (2026-10-14): `npm run check` lint 0, types 0, 135 passed / 14 skipped (unchanged);
`smoke-docks.mjs` 15/15 (new); `smoke-live.mjs` 22/22 with real PhotoCraft, VectorCraft and SoundCraft
windows, including the embedded app following the Claude and Media tabs; `smoke-projects.mjs` 10/10
(its stale "9 originals" check now accepts the current 11). Other smokes only had their header
selectors updated (Settings button, `.side-tab.right`) and were not re-run. New screenshots:
`docs/screenshots/40-45` (settings, side tabs).

Phase 1.3-1.4 (2026-10-14):
* Media dock: the Inspector is now **Details** and folds to its header (Hide/Show, remembered). Basic facts
  (type, size, file size, derived from, prompt, added) stay visible; origin, source, settings, cost,
  references, licensing, stored path, checksum (SHA-256) and the read-only note are under **More details**.
  Kind labels are plain (Picture, Vector art, Sound, Video, Layout, App document); filter gained Layouts.
* Bottom panel: a slim **Activity** strip by default (13%), taller (26%) when it shows a timeline; each
  context remembers its own height and can be folded to its header (Hide/Show; when folded, the latest
  activity line shows in the header). Log sources read as names (Project, Workflow, PhotoCraft...), and
  workflow log lines name the step instead of its internal id. The old `cs-center` saved layout is no
  longer used.
* Workflow Editor: toolbar split into "Add a step" and "View" groups: **Fit workflow**, **Tidy layout**
  (left-to-right by run order, `src/shared/workflowLayout.ts`), and toggles for Step settings, File results
  and the Map (MiniMap now off by default); all remembered. Thicker connections with arrowheads; done
  connections turn green, connections into the running step animate. The running step glows (pulse,
  off for reduced motion), a step waiting for approval is outlined, statuses read "waiting / running /
  needs you / done". While an approval is waiting, the approval panel gets the room (up to 62%) and the
  settings and results panels step aside; they come back after the decision.
* Tests: `npm run check` lint 0, types 0, **138 passed / 14 skipped** (+3 `workflowLayout.test.ts`);
  `smoke-docks.mjs` 15/15; `smoke-workflow.mjs` 7/7 (real LightCraft headless run + approval).
  `scripts/smoke.mjs` stops at its workflow part ("Approve" button never appears for its old demo graph);
  it fails the same way on `bb89719` without these changes, so it is a stale smoke, not a regression.

Phase 2.1-2.2 (2026-10-14):
* Settings has **Projects & Storage**: shows the folder new projects go to (built-in
  `%APPDATA%\creative-studio\projects` until changed), free/total space (`fs.statfs`, "not available"
  if unknown), **Browse...** (native dialog), **Open folder**, **Use built-in default**. A folder is
  accepted only after a real write test (plain-language error otherwise). Changing it never moves
  existing projects. Settings, keys and the registry (`projects.json`: current, recent, `defaultDir`,
  `locations` key -> absolute folder) stay in app data. Home's New project has **Choose folder...** for
  a per-project location (folder named after the project, " 2", " 3" if taken).
* New projects use layout 2 (`"layout": 2` in project.json): `Assets/{Originals,Generated,Audio,Video,
  Documents}`, `Versions`, `Exports`, `Workflows/workflow.json`, `Previews`, `Checkpoints`, one folder per
  ArtCraft app (live working files go in `<App>/work`), and `work/` scratch. AI generations go to
  `Assets/Generated`. Paths stay relative; hashes, lineage, provenance and read-only storing are unchanged.
  Projects without `layout` (Sample Project and anything older) keep `originals/`, `versions/`, `exports/`,
  `workflow.json` exactly as before, so nothing needs migrating.
* Not done yet: `Previews/` and `Checkpoints/` are created but unused; app folders hold only live scratch.
* Tests: `npm run check` lint 0, types 0, **142 passed / 14 skipped** (+3 projects, +1 legacy layout);
  `smoke-projects.mjs` 10/10 on a fresh build. Live-app and workflow smokes not re-run (not touched
  beyond the live work-folder path; do it with 2.3).

Phase 2.3-2.4 (2026-10-14):
* Home: **Open existing...** (pick any project folder; added to the list, nothing copied), **Duplicate...**
  (full copy with new identity and name "<name> copy", into a folder you pick), **Move...** (copy, check size
  and SHA-256 of every file under a `.moving` name, rename into place, register, then old folder to the
  Recycle Bin; any failure leaves the original; refused for the open project and the Sample Project),
  **Locate...** for a registered project whose folder is gone (shown as "Folder not found", same
  project identity needed). Rename still renames the project, not its folder.
* Media dock: **Collection** selector with counts: All Assets, Originals (imported, not AI), AI Generations
  (provider-made), Favorites (4+ stars), Versions, Workflows (made by workflow runs), Deliverables
  (lists the Exports folder). Computed from the manifest (`src/shared/collections.ts`); no files move.
* Not done: AI tagging (no AI integration for it yet); no dedicated UI test of the Browse dialogs
  (native dialogs; logic covered by unit tests).
* Tests: lint 0, types 0, **146 passed / 14 skipped**; `smoke-projects.mjs` 10/10, `smoke-docks.mjs` 15/15.

Phase 3 (2026-10-14):
* Home opens first (default workspace is Home). Big prompt "What would you like to create?"; **Create with Claude**
  makes ONE real Claude call (`ClaudePartner.planProject`, Agent SDK, no tools, no files, no generation) that returns
  a JSON plan (`src/shared/projectPlan.ts`, validated, with the five project types). The plan card lets the user edit
  name and type, answer Claude's questions (re-plans), and tick "add reference files"; nothing is created until
  **Approve and create project**. No mocked output: if Claude is signed out or fails, the error is shown. Claude is
  told which image models are set up and only recommends from them; no paid generation can start from planning.
* Project meta in `project.json` (all optional, older projects unaffected): `kind`, `brief`, `objective`, `view`
  (last workspace + selected file; saved quietly, does not change "last edited"). Opening a project restores its view.
* Blank projects: name + one of Image / Photography, Graphic Design, Video / Animation, Audio, Mixed Media + optional folder.
  Recent projects: cards show type and the brief's first line; search filters by name, brief and type.
* Overview: type chip, brief, Claude's objective (first plan step; it is not updated by Claude yet), progress
  checklist, latest artwork, "Waiting for your review" (new versions / AI images not yet approved), recent versions,
  workflow, recent exports, **Continue creating**. Nothing billable or destructive resumes on opening.
* Not done: Claude updating the objective itself, Templates (Phase 8). (History restore and pre-creation references were added in "Phase 3 gaps closed".)
* Tests: lint 0, types 0, **149 passed / 14 skipped** (+1 projects, +2 projectPlan); `smoke-projects.mjs` 13/13;
  `smoke-home-ai.mjs` 6/6 with real Claude (about one Sonnet call). Other smokes not re-run; the ones that type into
  "New project name" need the new "New blank project" step (only smoke-projects was updated).
  Screenshots: `46-home-claude-plan.png`, `47-project-overview-brief.png`, refreshed `40`, `41`.

Phase 3 gaps closed (2026-10-14):
* **Conversation history:** each project's Claude chat is saved to `<project>/Claude/conversation.json` (last 200
  items, written atomically, debounced; never in app settings), so Move and Duplicate carry it. The Claude panel
  restores it when the project is reopened. "New chat" clears the saved chat. A new session after reopening sends Claude
  only a short deterministic summary (up to 8 earlier requests, 120 chars each) plus the last 6 messages (400 chars
  each); no extra model call, and it is skipped while the live session continues. Approving a plan seeds the new
  project's chat with the request and plan. Code: `src/shared/claudeHistory.ts`, `ClaudePartner.ready/seed`.
* **Reference files:** **Add reference files...** on the Home prompt keeps only the chosen paths in main (renderer never
  supplies paths; max 12). Claude sees names/types/sizes and up to 3 small images (each at most 3 MB) in the one planning
  call. Nothing is copied until **Approve**; then they are imported to `Assets/Originals` (or Audio/Video/Documents)
  as read-only files with SHA-256, `origin: imported`, `role: "reference"`, original path in provenance. They are
  ordinary library files, so workflow Files steps and Claude (`list_files` flags `reference_from_user`) can use them as
  source images. Duplicates (same hash) are not copied twice.
* **Bug fixed on the way:** `ProjectStore.loadManifest` could create two manifest objects when first called
  concurrently, silently losing an import (seen as a flaky smoke). Now one shared object.
* Tests: lint 0, types 0, **153 passed / 14 skipped** (+3 claudeHistory, +1 projectStore); `smoke-home-ai.mjs` 11/11
  (real Claude, Sonnet 5.5, 3 consecutive runs; now also covers reference import after approval and chat restore),
  `smoke-projects.mjs` 13/13, `smoke-docks.mjs` 15/15. No generation was started. Not covered: the native file
  dialog itself (stubbed in the smoke) and a UI test of Move/Duplicate carrying the chat (logic is a whole-folder copy).

Phase 4 (2026-10-14):
* Header has two configurations, same project files and workflow system. **Simplified** (default): Project, Create,
  AI Generate, Deliver, **More** (menu: Media, Workflow, Effects, Color, Audio; More shows "More: <tool>" while one is open).
  **Advanced**: full navigation (Home, Media, Edit, AI Generate, Workflow, Effects, Color, Audio, Deliver). A header
  button switches modes at any time; the open workspace stays open; the choice is remembered (localStorage `cs-nav-mode`).
  Claude opening a file in Color/Effects/Audio still moves there in both modes. Code: `src/shared/navigation.ts`, `Header.tsx`.
* Timelines now show only while editing time-based media in Edit/Effects/Color/Audio (`shouldShowTimeline(kind, workspace)`),
  not in Project, Media, AI Generate, Workflow or Deliver.
* Not done: specialist tools are not auto-promoted to the main row by project type (always under More in Simplified).
* Tests: lint 0, types 0, **156 passed / 14 skipped** (+3 navigation); `smoke-nav.mjs` 7/7 (new), `smoke-docks.mjs` 15/15,
  `smoke-projects.mjs` 13/13. Other smokes click header tabs by name and now start in Simplified: they need the
  Advanced mode (or `More`) and were not updated or re-run. Screenshots `48-nav-simplified-more.png`, `49-nav-advanced.png`.

Phase 5 part 1 (2026-10-14):
* **Step A, smokes:** the older smokes (`apps`, `audio-deliver`, `claude-apps`, `claude-generate`, `generate`, `multiclip`,
  `workflow`) now switch to Advanced navigation at start (`localStorage cs-nav-mode`) and were re-run: workflow 7/7,
  generate 16/16, claude-generate 5/5, apps 20/20, multiclip 8/8, audio-deliver 17/17, claude-apps 15/15 (real Claude); also
  docks 15/15, nav 7/7. Fixed stale checks on the way: generated files now live in `Assets/Generated`, the video overview
  waveform needs the Edit tab (timelines only show while editing), duplicate option matches after the Details panel, and
  the export "no app window" check compares against windows already open. Not re-run: `smoke.mjs` (known stale), `smoke-live`,
  `smoke-theme`.
* **Claude plans workflows:** two new Claude tools. `workflow_catalog` (step types, every app with its edits and settings,
  connection rules) and `plan_workflow` (title, plain explanation, steps with readable keys, connections). Code:
  `src/shared/workflowPlan.ts`. It builds a normal `WorkflowGraph` for the existing engine: every connection goes through
  `validateConnection`, the whole graph through `validateGraph`; apps, edits and settings are checked with `checkEditValues`,
  files by exact library name, export presets against Deliver presets, image models and settings against the model table,
  and nodes are laid out with `autoLayout`. Problems come back to Claude as plain sentences so it can fix and retry.
* **What the user sees:** a card at the top of the Workflow tab with Claude's explanation, the steps, a cost estimate
  (paid generation per run, estimated with the existing price tables; free when nothing is paid), what they will be asked to
  approve, and warnings (missing API key, no approval step, app may not open a file type). **Use this workflow** (or
  **Replace my workflow**) saves it; a non-empty existing workflow is first kept as
  `Workflows/workflow-before-claude-<time>.json`. **Dismiss** discards it. Proposing saves, runs and generates nothing;
  Claude cannot run workflows. The pending plan is held in main (reset when switching projects).
* **Honest limits:** a paid AI Generate step can be planned and priced, but running paid generation inside workflows is
  still blocked (Phase 6); the plan says so as a warning. AI nodes carry `providerId`, `modelId`, `prompt`, `count`,
  `settings`; the runner still uses only the mock path. Import steps use library files only (no folder picking by Claude).
  Plan card appears in the Workflow tab; if the user is elsewhere it waits there (Claude tells them in chat).
* Tests: lint 0, types 0, **161 passed / 14 skipped** (+5 `workflowPlan.test.ts`); `smoke-claude-workflow.mjs` 9/9 (new,
  real Claude, Sonnet 5.5: plan appeared, nothing saved until applied, nothing generated, no ArtCraft window).
  Screenshots `53-claude-workflow-plan.png`, `54-claude-workflow-applied.png`.

Phase 5 part 2 (2026-10-14):
* **One engine, two drivers.** The editor and Claude both go through the same run controller in main (`ipc.ts startRun`);
  nothing is duplicated. Claude's tools: `workflow_status` (steps, state, per-step status, problems per file, what waits for
  the user, which steps changed; `wait_seconds` to watch), `run_workflow` / `rerun_workflow` (a native dialog asks the user
  first, Cancel is the default; the run then goes in the background), `pause_workflow`, `resume_workflow`, `cancel_workflow`,
  `change_workflow_step` (same validation as planning), `list_workflow_versions`, `restore_workflow_version`,
  `save_workflow_template`. Claude has no tool to approve or reject results: that stays with the user.
* **User controls** (Workflow tab): Pause / Resume (holds before the next step, never mid-step), **Take manual control**
  (pauses; Claude cannot change, run or resume anything until **Give control back to Claude**), Cancel, edit steps while
  paused then **Apply changes and continue** (finished steps keep results; only affected steps run again), per-step
  **Rerun from this step**, **Rerun N changed steps** (changed steps + what follows; shown as "will rerun" on the nodes),
  Approve / reject per file (as before), banner when Claude is running it.
* **Rerun of affected steps only:** `src/shared/workflowControl.ts` (`changedNodes`, `affectedNodes`, `reusableOutputs`);
  the runner takes `reuse` (kept steps are reported "Kept from the earlier run") and returns each finished step's outputs.
  A step is kept only if everything upstream is kept. Moving a node counts as no change.
* **Approved assets are protected:** approving marks the files `approved` (rejecting marks `rejected`) in the manifest. A
  rerun never asks about an already approved file again; reruns only add new versions, so approved versions are never
  overwritten (there is no delete path for versions in the app).
* **Versions:** `Workflows/history/v-<time>.json` is written before each run, plan apply, Claude change, template use and
  restore (identical consecutive graphs are not duplicated; last 50 kept). **Versions** panel restores one (the current one is
  kept first). **Templates:** `Workflows/templates/<id>.json`; only a workflow that ran successfully and is unchanged since can
  be saved; file choices are dropped; **Use** puts it in place (previous workflow kept as a version).
* **Honest limits:** paid generation is still blocked inside workflows (Phase 6); a run Claude starts is monitored through
  main's event stream, so it is not resumable after an app restart (state is in memory; versions and templates are on disk);
  templates have no gallery/starters yet (Phase 8); change_workflow_step edits one step's settings (no adding/removing steps:
  Claude proposes a new plan for that); the UI warns nothing about a rerun that has no earlier run (it just runs everything).
* Tests: lint 0, types 0, **171 passed / 14 skipped** (+10: `workflowControl.test.ts` 9, `workflowVersions.test.ts` 1);
  `smoke-workflow-control.mjs` 32/32 (new; real Claude Sonnet 5.5 and real PhotoCraft headless: pause/resume, approval,
  rerun kept steps and made no new versions, changed edit asked again while the earlier approval stayed, versions, template,
  Claude run via dialog, monitor, change step, rerun, template, refusal under manual control, no paid generation);
  `smoke-workflow` 7/7, `smoke-claude-workflow` 9/9 (its "use plan" wait now waits for the apply instead of racing),
  `smoke-docks` 15/15, `smoke-nav` 7/7. Two existing runner tests now use `toMatchObject` because the run result also
  carries `outputs`. Screenshots `55`-`59`. Not re-run: the other older smokes (they do not touch the changed paths).

Phase 6 part 1 (2026-10-14):
* **Spending limit:** per project (`<project>/spending.json`, never contains keys). AI Generate shows the limit field and the
  estimated total so far. A paid request that would pass the limit is refused before the approval dialog and before any
  network call; the approval dialog also shows the limit and the estimate so far. Every successful paid generation is
  recorded in the ledger as an **estimate** (CreateCraft's price tables), not a confirmed charge; the UI says so. Actual
  billing is only in the provider's console.
* **Workflow AI Generate step is no longer a mock** when the node has a model: it calls the same `GenerationService`
  (approval dialog in main, spending limit, ledger, provenance, reference image from the upstream file when the model can edit).
  Declining stops that branch with nothing charged. Old nodes without a model still use the offline mock. Claude's plans
  and prompt were updated (the "not enabled yet" warning is gone).
* **Verified (user ran both, approval dialog shown):** a real OpenAI image (est. $0.0132) and a real Gemini image (est. $0.0346). Earlier note: a real OpenAI or Gemini image was not yet verified. The user saved both keys and the free connection tests passed in their own
  app (2 of 2 and 4 of 4 models listed). I could not decrypt their keys from a second launched instance, so the real
  generation test is theirs to run once in AI Generate (approval dialog); then the files and provenance can be inspected.
  My launch also overwrote their stored "last test" status with a failure; pressing Test connection restores it.
* Tests: lint 0, types 0, **174 passed / 14 skipped** (+3: `spending.test.ts`, 2 workflow AI step tests);
  `smoke-generate-workflow.mjs` 7/7 (new, offline), `smoke-generate` 16/16, `smoke-claude-generate` 5/5, `smoke-workflow` 7/7.
  The "over the limit" behaviour is covered by the unit test; the smoke profile has no key so it stops earlier.

Phase 6 incident (2026-10-14): a second app instance I launched while the user's app was closing saw `project.json` as missing and
recreated the Sample Project list (11 sample files), dropping 9 entries from the list (files stayed on disk). Recovered by rebuilding
the list from the folder (backup: `project.json.bak-before-recovery`; lineage and generation settings best-effort). Guard added in
`ensureSampleProject`: retries, then refuses to recreate a project whose folder still has files. Unexplained: the running app did not
rewrite `project.json` after generation or a rating change; restart showed all 20 items. Tests 174 passed / 14 skipped.

Phase 7 (2026-10-14):
* **Recommendation: Veo first.** The user already has a saved Gemini key (the vault lists `gemini` and `openai` only), and Veo
  uses that same key. Runway and Luma each need a new key and their API docs could not be fully read here (Runway endpoints:
  `/v1/text_to_video`, `/v1/image_to_video`, `GET`/`DELETE /v1/tasks/{id}`; Luma `/generations`; prices unconfirmed), so they are
  listed as "planned" in `VIDEO_PROVIDERS` and not built. Midjourney stays a manual import.
* **Veo (Gemini API):** models `veo-3.1-lite|fast|(standard)-generate-preview`; text-to-video and image-to-video (starting
  picture), aspect 16:9 / 9:16, 4/6/8 s, 720p (1080p and 4k only at 8 s; Lite has no 4k). Estimates use Google's published
  per-second prices (Lite $0.05/$0.08, Fast $0.10/$0.12/$0.30, Veo 3.1 $0.40/$0.40/$0.60); they are estimates, not charges.
  Code: `src/shared/video.ts`, `src/main/videoApis.ts`, `src/main/videoGeneration.ts`, `VideoPanel.tsx` (AI Generate tab).
* **Same safety path as images:** key from the vault only, project spending limit (counts running jobs too) checked before the
  dialog, native approval dialog (video wording, Cancel default), ledger entry when the video lands, provenance on the asset.
* **Jobs:** saved in `<project>/work/video/jobs.json`; polled every 10 s in the background (30 min max); listing the jobs after a
  window change or restart resumes any still-running job from its saved operation (Google keeps the file 2 days). The finished
  mp4 is downloaded with the key, imported to `Assets/Generated`, and shown under "Video jobs" (Show in library / Open in Edit).
* **Honest limits:** Veo has no documented cancel call, so "Stop waiting" only stops CreateCraft and warns that Google may still
  bill it. Verified live: text-to-video, polling, download, import. Image-to-video also verified live. Request fields for image-to-video (`instances[0].image.bytesBase64Encoded/mimeType`) and the response path
  (`response.generateVideoResponse.generatedSamples[0].video.uri`) follow Google's docs but image-to-video is **unverified against the live API**. Claude has no video tool yet; Workflow AI step is images only; no resume of a job whose app was closed beyond 2 days.
* **Finish-up (same day):** (1) Media list now refreshes when a video job finishes (bug found in the real run). (2) **Runway built**
  (`gen4.5` text or picture, `gen4_turbo` picture only; header `X-Runway-Version 2024-11-06`; poll `/v1/tasks/{id}`; DELETE cancels;
  1 credit = $0.01, 12 and 5 credits/s; output link downloaded without the key; key test reads `/v1/organization` for the credit
  balance). **Unverified with a real Runway key and clip**; the base64 data-URI picture upload and `/v1/organization` are
  assumptions from the docs. (3) **Claude tools** `list_video_models` and `generate_video` (same approval dialog, spending limit;
  returns when submitted, the clip arrives later). (4) **Luma not built**: its docs give no price and its image-to-video needs
  an already-hosted image URL (no upload API). **Veo image-to-video verified** (2026-10-14 23:47): a library picture + prompt gave a 4 s 1280-wide mp4 with the reference recorded in provenance (est. $0.20).
* Tests after finish-up: lint 0, types 0, **183 passed / 14 skipped** (+2 Runway); `smoke-generate` 16/16 (provider count 3),
  `smoke-claude-generate` 5/5.
* Tests: lint 0, types 0, **181 passed / 14 skipped** (+7 `videoGeneration.test.ts`: price and rules, request mapping, decline sends
  nothing, spending limit, full job to library asset + ledger, restart resume, failure and stop-waiting); `smoke-generate` 16/16,
  `smoke-generate-workflow` 7/7, `smoke-docks` 15/15. No paid call was made.

Phase 8 (2026-10-14):
* **Nine built-in templates** (`src/shared/templates.ts`), each a real `WorkflowGraph` built through the same planner checks as Claude's workflows
  (apps, edits, presets, models validated) with file choices left empty: Cinematic poster, Photo restoration, Image enhancement, AI image variations,
  Animated artwork, Short cinematic video, Video sequence with music, Logo and vector illustration, Photo book or publication. Every one has an approval step.
* **Honest labels:** *Ready* (local ArtCraft apps only: Cinematic poster, Image enhancement), *Uses paid AI (asks first)* (AI image variations: Gemini
  Nano Banana 2.1, 3 images; the Workflow AI step keeps the approval dialog and project spending limit; nothing starts on its own) and *Partly manual*
  (limits stated on the card). Limits: restoration is tone/clarity/sharpen only (no scratch repair); animated artwork and the two video templates need a
  clip (no workflow video-generation step; Veo clips are made in AI Generate with their own approval); the sequence-with-music template only prepares
  clips, joining clips and music is done on the FilmCraft timeline by you or Claude; logo/vector needs an existing SVG (no raster-to-vector, no logo
  drawing); photo book is one DesignCraft layout per run (text replace, PDF/PNG), not page assembly.
* **UI:** Home **Templates** button opens a panel with the templates (plus templates saved in the open project); **Start a project with this** creates
  a project of the right type, fills in the workflow and opens the Workflow tab. Built-ins also appear in the Workflow tab's Templates list (Use).
  **Saving your own** is the existing Phase 5 feature (workflow must have run successfully and be unchanged). Claude's project plan now has an optional
  `template` id (validated against the catalogue); the plan card shows a ticked "Start from Claude's recommended template" that is applied on approval.
* **Tests:** lint 0, types 0, **186 passed / 14 skipped** (+3 `templates.test.ts`; one `videoGeneration` test failed once under full-suite load and
  passes alone and on re-run); `smoke-templates.mjs` 6/6 (new, offline), `smoke-projects.mjs` 13/13 (Templates check updated), `smoke-workflow.mjs` 7/7.
  Not run: a template applied to real files end to end, and the Claude recommendation live (needs one real Claude call; no paid generation was made).
  Screenshots `97-templates-home.png`, `98-template-applied.png`.

Free local video, Stage A + B (2026-10-14):
* **Stage A (research only, nothing run):** `docs/local-video-compatibility.md` has the model/backend matrix and recommendation.
  Key finding: AMD's Windows ROCm requirements list RX 7000/9000, Radeon PRO and Ryzen AI only; **RX 6000 (incl. 6650 XT) is
  unsupported**, so AMD RX 6650 XT is *unproven* and only a DirectML experiment could change that. Recommended first local engine:
  LTX-Video 2B distilled via a small diffusers runner (ComfyUI optional). No hardware is claimed to work.
* **Stage B (verified):** **Motion Effects**, a free non-AI camera move on one picture rendered by FilmCraft's headless engine:
  zoom in/out, pan L/R/U/D, strength, 16:9 / 9:16 / 1:1, 720p/1080p, 24/30 fps, 2-20 s. Saved as a new version of the picture,
  labelled "not AI-generated", no cost/ledger. Panel in AI Generate (below Video). Code: `src/shared/motionEffects.ts`,
  `src/main/motionEffects.ts`, `MotionPanel.tsx`; IPC `motion:render` / `motion:cancel`.
* Not built: parallax/depth, multi-picture crossfade sequences, overlays, title animation, Claude tool, workflow node, the
  Cloud / Free Local AI / Motion Effects source selector (Motion Effects is just its own panel for now).
* Tests: lint 0, types 0, **196 passed / 14 skipped** (+10: `motionEffects.test.ts` x2, incl. a real FilmCraft render);
  `smoke-generate` 16/16. `videoGeneration` Runway test is flaky under full-suite load (passes alone); not caused by this change.
* **Stage C part 1 (2026-10-15, verified on this PC):** read-only hardware check + **Free local AI video** setup card in AI Generate
  (`src/shared/localAi.ts`, `src/main/hardware.ts`, `LocalAiPanel.tsx`, IPC `localai:status`). Detects OS, CPU, RAM, GPUs with real VRAM
  (registry value, not the 4 GB WMI cap), free disk, and backends found (CUDA, ROCm/HIP, DirectML, CPU; all "untested"). Tier is a memory
  ceiling. Model registry (LTX-Video 2B distilled, Wan 2.2 5B) keeps availability apart from `verified` (empty). On this PC: i5-12600K,
  31.8 GB RAM, RX 6650 XT 8 GB + UHD 770, tier Standard, DirectML runtime present, no CUDA/ROCm; LTX "could be tried", Wan not offered.
  **Not built:** download manager, runner, self-test, generation, Claude/workflow integration. AMD is still unverified.
  Tests: 203 passed / 14 skipped (+7 `hardware.test.ts`, fake Windows output), smoke-generate 16/16.
* **Stage C part 2 (2026-10-15):** model download manager (`src/main/modelDownloads.ts`, tests with a fake server). Consent is a native
  dialog in main (license, size, folder; Cancel default); resume by HTTP Range, per-file SHA-256 when published, disk check with 2 GB
  margin, cancel keeps partials, remove, custom model folder (`local-ai.json`, write-tested). UI in the Free local AI card.
  **Correction:** the LTX-Video 2B distilled download is about **27 GB** (6.3 GB model + 19 GB text encoder + 1.7 GB VAE, sizes and
  hashes from the Hugging Face listing), not 8 GB as I said earlier. No real download has been made; needs Tomas's explicit yes naming
  model and size. Still unbuilt: runner, self-test, generation, Claude tool, workflow node. Tests 211 passed / 14 skipped (+9).
* **Stage C part 3 (2026-10-15): engine change + runner (simulated tests only).** torch-directml is stale (torch 2.4.1, Python <=3.12,
  last release Sept 2024; no wheel for this PC's Python 3.13), so the PyTorch route is out for AMD. New plan: **stable-diffusion.cpp**
  (MIT, Vulkan build 30 MB zip, no Python; has Wan 2.x video, GGUF, `--offload-to-cpu`, `--vae-tiling`). Test model: **Wan 2.1 T2V 1.3B**
  (Apache 2.0): 2.84 GB + 0.25 GB VAE + 3.66 GB umt5 Q4 GGUF = ~6.7 GB. LTX-Video 2B stays listed but only offered with CUDA.
  Built: `src/shared/localVideo.ts` (presets, validation, sd-cli args), `src/main/localVideo.ts` (runner: spawn, progress, cancel, import as an
  AI-labelled free asset, FilmCraft AVI->MP4 conversion), runtime zip extraction in the download manager, Vulkan probe, UI in the card.
  Tests: 220 passed / 14 skipped; the runner tests use a SIMULATED engine and prove only CreateCraft's logic. **No real generation has
  happened; the exact sd-cli output file name/format and progress lines are unconfirmed until the runtime is installed.**
* **FIRST REAL LOCAL CLIP (2026-10-15, Tomas approved the 30 MB engine + 6.7 GB Wan 1.3B download):** stable-diffusion.cpp Vulkan on the
  **AMD Radeon RX 6650 XT** (Vulkan device 0, 32 GB RAM) generated "a calm sea at sunset" at 320x192, 17 frames, 10 steps in **83 s**
  (weights held in RAM via --offload-to-cpu); AVI converted to H.264 MP4 by FilmCraft, 1.06 s at 16 fps, plays, frames change and look
  like water (Experimental quality is rough). Verified only for: this GPU, Vulkan, Wan 2.1 1.3B, Experimental preset. Not yet tried:
  Low/Balanced/Higher presets, cancel on the real engine, longer clips, other GPUs. Fixed on the way: Windows tar (Git's tar failed on
  "C:"), re-extract when the zip was already downloaded, `--fps 16` passed. Stage C remaining: Claude tool, workflow node, source selector.
* **Stage C part 4 (2026-10-15):** Claude tools `local_video_status`, `make_local_video`, `make_motion_video`, `request_model_download`; workflow
  AI Generate node can use the local model (`providerId: 'local'`, free, same engine/approval/cancel; Claude's plans accept
  `model_id wan-2.1-t2v-1.3b` + `settings.preset`); source selector in AI Generate (Cloud AI / Free Local AI / Motion Effects, default
  Motion Effects). **Balanced preset does NOT work in practice on the RX 6650 XT**: ~143 s per step x 20 steps (about 48 min), stopped
  by hand; the engine warned about pinned-memory allocation (all weights live in RAM). Low and Higher are untested. They stay as
  "future options", labelled "not proven on this PC"; Experimental (83 s) is the only proven preset. Lesson: a leftover temp test in
  src/ got picked up by `npm test` and started a second engine, which caused one out-of-memory failure; temp tests are now removed
  before any suite run. Tests: 4 new `localWorkflow.test.ts`.
* **Requirement added by Tomas:** Free Local AI must have a built-in, self-service setup inside CreateCraft (guided: check this PC, pick a model, consent, download, self-test, status and repair/remove). The user must not need to install Python or ComfyUI by hand.
* Next (needs Tomas's OK): Stage C hardware detection, then model download and a real inference test.

Five more ArtCraft apps (2026-10-15): CADCraft, FigCraft, WordCraft, DeckCraft, GridCraft are installed (0.6-0.7). **Audit done**
(`docs/integration-audit.md`, "Audit of five more ArtCraft apps"): headless CLI and live control (`--control PORT` + CLI bridge, no
token) verified for all five on this PC; theme sync not found/verified for any. Integration order: one app at a time, stop for
Tomas's OK after each.
* **WordCraft (first, 2026-10-15): INTEGRATED, partly verified.** New asset kind `document` (.docx). Registry entry (`wordcraft`,
  Edit tab) with quick edits Replace text (`edit.replaceAll`) and Add a paragraph; live driver `LiveWordCraft`
  (open_document, execute, save_document + render_page PNG, `edit.undoHistory`); headless engine for workflows
  (`wordcraft-cli mcp` with automation read/write roots); 7 Deliver presets (PDF, PNG of page 1, TXT, MD, HTML, ODT, RTF via
  `convert`/`render`); Claude `open_file`/`get_status`/workflow tools get it through the shared tables; template "Document to PDF";
  Media filter "Documents". Theme sync: none (`view.darkMode` only toggles the page's dark mode): listed as manual.
  Verified on this PC: every Deliver preset (real CLI), real workflow (replace text, add paragraph, PDF + text), real WordCraft
  window through the live controller (open, edit, undo, save new .docx + PNG, preview). **Not verified:** the in-app Edit-tab
  embedding and UI smokes (Tomas's CreateCraft was running, so none was launched), a real Claude request using it, thumbnails for
  imported .docx (shows "DOCX" until a version is saved). Tests: lint 0, types 0, 228 passed / 15 skipped
  (+8); `videoGeneration` tests flake under full-suite load (EPERM rename), pass alone.

* **WordCraft verified + PdfCraft integrated (2026-10-15): WORKING, details in `docs/wordcraft-pdfcraft-report.md`.** WordCraft: native conformance
  6/6 (open, edit, undo, save, reopen, all 7 exports), Edit-tab embedding and UI smoke (`npm run smoke:docs` 12/12), a real Claude request.
  PdfCraft (.pdf, asset kind `document`, opens in PdfCraft by default): `LivePdfCraft` drives the CLI engine (`pdfcraft-cli mcp --root`) on a working
  copy and keeps the embedded window showing it (its control port only has `ui.*`); quick edits Replace text, Add text, Rotate, Delete pages,
  Watermark, Title; 6 Deliver presets (PNG, text, DOCX, HTML, RTF, smaller PDF); "Add to library" hands an export on to another app
  (Word -> PDF -> PdfCraft and PDF -> DOCX -> WordCraft verified with the real apps and through the Claude panel); template "PDF touch-up".
  Not done: theme sync (no setting), import-time thumbnails, the window is refreshed (not edited live) after each edit.
  Tests: lint 0, types 0, 240 passed / 33 skipped; live suites 31/31 (`CS_LIVE_TESTS=1`).

* **GridCraft (2026-10-15): INTEGRATED, partly verified.** New asset kind `sheet` (.xlsx). Registry entry (`gridcraft`, Edit tab) with
  quick edits Set a cell (`cell.set`) and Sort a table by a column (`data.sort`), both with cell/range validation; live driver
  `LiveGridCraft` (open_workbook, execute_command, save_workbook, `history.list`, `undo`, window screenshot as the version picture);
  headless engine for workflows (`gridcraft-cli mcp`, which has no file roots, so only the library file is read and results go to
  the scratch folder); 4 Deliver presets (CSV and TSV of the first sheet, JSON, HTML; `convert`); Claude tools through the shared
  tables. Theme sync: none verified (manual). Verified on this PC: real CLI exports, real headless workflow (set formula, sort, CSV),
  real window through the live controller (open, edit, sort, undo, save new .xlsx + PNG, preview), unit tests. **Not verified:**
  in-app Edit-tab embedding / UI smoke and a real Claude request through CreateCraft; PNG preview of a workbook without a window
  (GridCraft has no headless renderer, so imported/workflow versions have no picture); multi-sheet CSV exports only the first sheet.
  Tests: lint 0, types 0, 242 passed / 34 skipped; `videoGeneration` flakes under full-suite load, passes alone.

* **DeckCraft (2026-10-15): INTEGRATED, partly verified.** New asset kind `deck` (.deckcraft, .pptx; default app for both). Quick edits:
  Replace text on all slides (no find/replace command exists, so `LiveDeckCraft` walks shapes with `inspect_slide` and sets text with
  `set_text`; the first run's formatting is kept for the whole shape; tables and charts are not searched) and Add a slide at the end
  (`slide.new` titleAndContent). Live driver over `--control PORT` + `deckcraft-cli mcp --connect`; history from `inspect_document`'s
  undo list; baseline digest so undo-then-save makes no new version; save writes .deckcraft + PNG of slide 1 (`render_slide`);
  headless engine for workflows; 3 Deliver presets (PDF, PPTX, PNG of slide 1 via `convert`); Claude tools through the shared tables.
  Theme sync: none verified (manual). Verified on this PC: real CLI exports, real headless workflow, real window through the live
  controller (open, edit, add slide, undo, save, preview, undo-then-save no-op), unit tests. **Not verified:** in-app Edit-tab
  embedding / UI smoke, a real Claude request, transitions/animations/theme/picture edits (no quick edit; use the window).

* **FigCraft (2026-10-15): INTEGRATED, partly verified.** New asset kind `ui` (.figcraft). Quick edits: Replace text in all layers
  (one undo step via the `batch` tool) and Add a line of text (`node.create` with its size, into the first frame). Live driver over
  `--control PORT` + `figcraft-cli mcp --attach PORT`; history from `inspect_document`; baseline digest (undo-then-save is a no-op);
  save writes .figcraft + PNG of the page (`screenshot`); headless engine for workflows; 4 Deliver presets (PNG, PNG at 2x, SVG, PDF
  of the first frame via `figcraft-cli export`). Theme sync: FigCraft has `view.themeLight/Dark/System` but it was not exercised, so
  listed manual. Verified on this PC: real CLI exports, real headless workflow, real window through the live controller, unit tests.
  **Not verified:** in-app Edit-tab embedding / UI smoke, a real Claude request, theme sync, prototypes/components/auto-layout edits
  (window only), .fig / .json / .svg import into the library as UI designs (SVG stays with VectorCraft).

* **CADCraft (2026-10-15): INTEGRATED, partly verified.** New asset kind `cad` (.dxf, .dwg; default app for both). Quick edits: Replace
  text in the drawing (`find`; an empty search is undone so it leaves no history entry) and Add a note (`text`, placed outside the
  drawing from its extents). Live driver over `--control PORT` + `cadcraft-cli mcp --connect`; history from `inspect_drawing`'s
  undo list (newest first, reversed); save writes .dxf + PNG (`save` with a .png path); headless engine for workflows; 5 Deliver
  presets (PDF, PNG 2400x1600, SVG, DXF, DWG via `convert`). **Shared change:** `liveTask` now compares saves with
  `documentDigest` (zip content digest, else raw bytes) so undo-then-save also makes no new version for non-zip files; zip apps
  behave as before (DesignCraft, WordCraft, DeckCraft, FigCraft live tests re-run). Theme sync: none found (manual). Verified on
  this PC: real CLI exports, real headless workflow (text and note present in the saved DXF), real window through the live
  controller, unit tests. **Not verified:** in-app Edit-tab embedding / UI smoke, a real Claude request, drawing/dimensioning
  edits (window or Claude's `command_line` only; no quick edit), DWG saved back as DWG (versions are always .dxf).

Phase 1 note: the old `integrationStatus().claude` field in `src/main/ipc.ts` still says "not
configured in this build" (stale); Settings now shows Claude's real sign-in state instead.

---

## 1. Features implemented and working

| Area | Status | Notes |
|---|---|---|
| Project library (import, read-only originals, versions with lineage, ratings, provenance, SHA-256) | **WORKING** | Originals are copied and never modified; every edit or save creates a new version with a parent link. |
| Media tab (browser, inspector, image/vector/video/audio preview, video thumbnails) | **WORKING** | Video thumbnails and real waveforms are decoded from the files. |
| Edit tab: files open in their ArtCraft app embedded in CreateCraft | **WORKING** | PhotoCraft, VectorCraft, SoundCraft, FilmCraft (video), DesignCraft (layouts). The app window sits over the Edit area; pop-out / put-back; hidden when you leave the tab. |
| Color tab (LightCraft), Effects tab (EffectCraft), Audio tab (SoundCraft) | **WORKING** | Same embedding; each tab opens the selected file in its app. |
| Quick edits per app (one-click, verified commands only) | **WORKING** | Every quick edit offered was verified against the real app (live tests). |
| Edit lock / Pause / Take control / resync | **WORKING** | Shared by the user, automation and Claude. |
| Save as new version from any live app | **WORKING** | PhotoCraft .pcraft+PNG, VectorCraft SVG+PNG, SoundCraft WAV, FilmCraft MP4, LightCraft full-size image, EffectCraft MP4/PNG, DesignCraft .designcraft+PNG. Unchanged saves make no duplicate. |
| FilmCraft timeline under the Edit area | **WORKING** | Live tracks/clips, playhead, clip select; multi-clip: add clip, add music, reorder, remove; crossfades, music volume, fades, trim, speed, looks. |
| SoundCraft timeline under the Audio tab | **WORKING** | Clips with real waveform, gain, fades, playhead; history from SoundCraft's own undo list. |
| Deliver tab (export queue) | **WORKING** | 24 presets across pictures, vector, audio, video and layouts, run headless by each app's CLI (no windows); queue with progress and cancel; never overwrites; `exports/manifest.json` records source, version history, preset, SHA-256; Show in folder. No MP3 (SoundCraft cannot write it). |
| Workflow tab (batches across apps) | **PARTIAL** | See section 8. |
| Claude Creative Partner | **WORKING** | See section 7. |
| AI image generation (BYOK) | **PARTIAL** | Real code, tested with mocked HTTP; no real paid call made yet. See section 9. |
| Themes and ArtCraft app theme sync | **WORKING** | See section 5. |
| Window capture (screenshots of app windows as a service) | **NOT IMPLEMENTED** | Interface only; the UI says "not connected". |

## 2. Project Home and new project creation

**WORKING** (Phase 3 made it prompt-first; see "Phase 3" above). The Home tab lists all projects (thumbnail, file count) with New project, Open,
Rename, Show folder and Remove (moves the folder to the Windows Recycle Bin after confirmation).
The open project has an Overview (files by kind, recent versions, workflow, exports, Import
files…, Show folder). Switching projects resets live sessions, Claude's session and per-project
queues. A Sample Project is created on first run and gains new sample files from later versions
once (current samples: photos, SVGs, a .pcraft, two sounds, two short videos made from the apps'
built-in demos, a DesignCraft flyer). Tests: `projects.test.ts`, `projectStore.test.ts`,
`scripts/smoke-projects.mjs`.

## 3. User-selected project storage and multi-project management

* Multi-project management (create, open, switch, rename, remove, remembered across restarts): **WORKING**.
* **User-selected storage location: NOT IMPLEMENTED.** All projects live under
  `%APPDATA%\creative-studio\projects\<key>\` (one folder per project: `originals/`, `versions/`,
  `work/`, `exports/`, manifest and workflow JSON). There is no folder picker for where projects are
  stored, and no "open project from folder" or move-project feature yet.

## 4. Simplified and Advanced navigation

**WORKING** since Phase 4 (see above). Before that there was one navigation layout: a header with nine workspace tabs (Home, Media,
Edit, AI Generate, Workflow, Effects, Color, Audio, Deliver) and a Settings button (no status chips
since Phase 1.1); the media browser + inspector docks on the left behind a vertical Media tab, a
context bottom panel (timeline for audio/video, activity log otherwise), and the Claude panel docks
on the right behind a vertical Claude tab (Phase 1.2). There is no Simplified/Advanced mode switch.

## 5. Themes: ArtCraft Match, Studio Dark, Light, System

| Theme | Status |
|---|---|
| ArtCraft Match (palette measured from PhotoCraft's "proMedium" theme) | **WORKING** |
| Studio Dark (original CreateCraft palette) | **WORKING** |
| Light | **WORKING** |
| System (follows Windows light/dark; the dark choice is configurable) | **WORKING** |
| Accent colour (presets + custom) | **WORKING** |
| ArtCraft app theme sync (open app follows CreateCraft's theme) | **WORKING** for all seven apps, each through its own official setting and read back: PhotoCraft (`ui.set theme`), VectorCraft (`uiBrightness`), SoundCraft (`ui_set theme`), FilmCraft (`appearance.colorTheme`), LightCraft (`appearanceMode`), EffectCraft (`appearance.appearanceMode`), DesignCraft (`ui_set brightness`). Can be switched off. |

Tests: `theme.test.ts`, `settingsStore.test.ts`, `scripts/smoke-theme.mjs`, theme checks in `scripts/smoke-apps.mjs`.

## 6. Live control of PhotoCraft, VectorCraft and SoundCraft

**Yes, all three are controlled live (WORKING),** and so are FilmCraft, LightCraft, EffectCraft and DesignCraft.

| App | How | Safety |
|---|---|---|
| PhotoCraft | `photocraft.exe --control <port>` + `photocraft-cli mcp --bridge` | Control token file + automation read/write roots (verified: wrong token and outside paths are refused); command allowlist. |
| VectorCraft | `vectorcraft --control <port>` + `vectorcraft-cli mcp --connect` | Automation read/write roots. No token exists in VectorCraft; random loopback port. |
| SoundCraft | `soundcraft --control <port>` + `soundcraft-cli mcp --connect` | No token or roots in SoundCraft; CreateCraft only sends commands from its own table and only writes to the project's work folder. |
| FilmCraft, LightCraft, EffectCraft, DesignCraft | Same pattern (see audit) | LightCraft uses a throwaway in-memory session (your library is never opened); EffectCraft uses automation roots; FilmCraft/DesignCraft have no token (fixed command tables only). |

Live behaviour: open, quick edits, undo, history (including hand edits), save as new version,
theme sync, embedding in the tab, pop-out. Tests: `liveApps.live.test.ts`, `photocraftLive.test.ts`
(opt-in: `CS_LIVE_TESTS=1`, they open real windows and close them), `scripts/smoke-live.mjs`,
`scripts/smoke-apps.mjs` (20/20), `scripts/smoke-audio-deliver.mjs` (13/13 + Claude checks 4/4).

## 7. Claude Creative Partner

**WORKING** (verified with real requests; the user's own Claude Code sign-in through the Claude
Agent SDK; no API key stored by CreateCraft; models: Claude Opus 5.5 default, Claude Sonnet 5.5).

Claude gets no shell, file or web tools: only CreateCraft's in-process tools, all under the same
edit lock, allowlists and versioning as the user:

* `get_status` (open file, app, history, lock, available edits, every app and its file types, plus app details such as the FilmCraft timeline or DesignCraft page text)
* `look_at_document` (picture of the document, frame or composition)
* `open_file` (any library file, in any suitable app; hands off between apps, e.g. PhotoCraft → LightCraft; the window follows to that app's tab)
* `apply_edit` (any verified quick edit of the open app), `photocraft_command` (allowlisted PhotoCraft adjustments/filters), `undo`, `save_version`
* `timeline_add`, `timeline_move_clip`, `timeline_remove_clip` (build multi-clip videos with music in FilmCraft)
* `list_export_formats`, `export_file` (Deliver presets, same queue and manifest)
* `list_files`, `list_image_models`, `generate_image` (each paid call needs the user's approval in a native dialog)

Verified with real requests: one request per app (7/7) plus a PhotoCraft → LightCraft hand-off;
multi-clip video with music and crossfades; export a layout to PDF; audio fade in the Audio tab.
Claude correctly refuses to discard unsaved edits without permission. Total Claude usage for all
verification runs today: about $5.

Claude can propose workflows (`workflow_catalog`, `plan_workflow`) for the user to apply, and after the user's approval run, monitor, pause, change and rerun them (see Phase 5 part 2).

## 8. Workflow node execution

| Node | Status | Notes |
|---|---|---|
| Files (Import) | **WORKING** | One file, several library files, or every supported file in a folder (copied into the library; folder only read; up to 200 files, no subfolders). |
| App step (ArtCraft Edit) | **WORKING** | Any of the 7 apps with its verified quick edits, run in the background with **no window**: PhotoCraft/VectorCraft/SoundCraft through their headless CLIs, FilmCraft/LightCraft/EffectCraft/DesignCraft through their CLI's own MCP engine. Each file gets new versions; a file the app cannot open stops alone. Older "PhotoCraft engine command" steps still run. |
| Approval | **WORKING** | Shows every file's result as a thumbnail; approve all, some (ticked) or reject. |
| Export | **WORKING** | Any of the 24 Deliver presets; formats that don't fit a file are skipped; same queue and manifest (marked "workflow"). |
| AI Generate | **MOCK** | Only the mock provider; no image, no network call. Real providers come in Workflow step two. |
| Batch execution | **WORKING** | Every file goes through each step in turn; per-file progress table under the canvas. |

Limits: one Files step per workflow; a straight chain per file (no merging files, e.g. placing a
photo into a layout); no saved named workflows or starter templates yet; Claude cannot build or
run workflows yet. Tests: `workflowRunner.test.ts`, `workflow.test.ts`, `headlessApps.test.ts`,
`workflowSteps.test.ts` (real cross-app workflows), `scripts/smoke-workflow.mjs` (7/7, no ArtCraft
window opened).

## 9. AI generation providers

| Item | Status |
|---|---|
| OpenAI (GPT Image 2.5 Flare / Sunburst) and Google Gemini (Nano Banana 2.1, Gemini 3.1 Flash Lite Image, 3.1 Flash Image, 3 Pro Image) | **PARTIAL**: request/response code is implemented and unit-tested with mocked HTTP. **No real generation has been made** (needs the user's key and explicit OK). A fake OpenAI key was tested and the real API answered 401, shown as "the key was rejected". |
| Keys | **WORKING**: encrypted with Windows DPAPI (Electron `safeStorage`) in the main process only; read from the clipboard and then cleared; never sent to the renderer, logs, project files or Claude. |
| Approval before every paid call | **WORKING**: native dialog in main with provider, model, prompt, settings and estimated price; Cancel is the default. Verified with the dialog stubbed to Cancel (nothing sent). |
| Mock provider | **MOCK** (labelled in the UI). |
| Claude `generate_image` | **WORKING** through the same approval path (verified with mock + a cancelled OpenAI request). |
| Workflow AI Generate node | **MOCK** (not connected to the real providers yet). |
| Midjourney | Folder import only (by policy). |

## 10. Known bugs, incomplete features and next milestones

**Known issues**

* ~~`README.md` is out of date~~ (refreshed 2026-10-17); some fixture strings may still show mis-encoded dashes (`â€"`).
* FilmCraft timeline panel: with music added, the music track can be below the fold of the bottom panel (scrolls).
* Multi-clip video: clips are appended and moved one step at a time (no drag-and-drop on the strip); pictures last 3 s; music cannot loop or run longer than its file.
* Deliver: no MP3 export; progress is per job (no percentage within one export).
* DesignCraft text edits only offer black or white text.
* Live apps without a control token (VectorCraft, SoundCraft, FilmCraft, DesignCraft) rely on a random loopback port plus CreateCraft's fixed command tables.
* Live/smoke tests that open app windows are opt-in and must be run on a PC with the ArtCraft apps installed.
* The renderer console logs a harmless warning that the CSP `frame-ancestors` directive is ignored in a `<meta>` tag.

**Incomplete / not implemented (2026-10-14 list; since done: user-selected project storage, Simplified/Advanced navigation, the real AI Generate node, saved workflows and templates, Claude-built workflows, real paid generation; still open: window capture service, installer/first-run/backup, push to a remote)**

* User-selected project storage location; open/move project folders.
* Simplified / Advanced navigation modes.
* Window capture service.
* Workflow step two: real AI Generate node, saved/named workflows with starters, Claude building and running workflows, merging files (e.g. photo into a layout).
* A real paid AI generation (awaiting the user's key and OK).
* Windows installer / packaging, first-run guide; code not yet pushed to a remote.

**Recommended next milestones (2026-10-14; milestones 1, 2 and 5 are done, see the summary at the top)**

1. Workflow step two (AI node with approval, saved workflows and starters, Claude builds/runs workflows).
2. Project storage choice (pick a folder, open existing project folders) and Simplified/Advanced navigation.
3. Place library pictures into DesignCraft layouts (by hand and by Claude), enabling photo → flyer → PDF pipelines.
4. Packaging: Windows installer, first-run guide, README refresh; push to a private remote for backup.
5. One real AI generation test with the user's key, then enable the Workflow AI node.

---

## Test results (run for this package, 2026-10-14)

`npm run check` (ESLint + TypeScript for main/preload and renderer + Vitest): **all passed.**

* Lint: 0 problems. Typecheck: 0 errors.
* Unit/integration tests: **19 files passed, 2 skipped; 135 tests passed, 14 skipped.**
  The 14 skipped tests are the opt-in live tests that open real app windows
  (`liveApps.live.test.ts`, `photocraftLive.test.ts`; run with `CS_LIVE_TESTS=1`).
  Several of the passing tests drive the real installed ArtCraft command-line tools headlessly
  (no windows): `deliver.test.ts` (all 24 export presets), `headlessApps.test.ts`,
  `workflowSteps.test.ts` (real cross-app workflows), `appEditors.test.ts`, `photocraftCli.test.ts`.

| Test file | Passed |
|---|---|
| src/shared/appSteps.test.ts | 10 |
| src/shared/collaboration.test.ts | 8 |
| src/shared/generation.test.ts | 4 |
| src/shared/photocraftOps.test.ts | 5 |
| src/shared/theme.test.ts | 10 |
| src/shared/workflow.test.ts | 6 |
| src/shared/workflowRunner.test.ts | 8 |
| src/main/appEditors.test.ts | 7 |
| src/main/deliver.test.ts | 12 |
| src/main/generation.test.ts | 11 |
| src/main/headlessApps.test.ts | 4 |
| src/main/imageApis.test.ts | 4 |
| src/main/liveTask.test.ts | 17 |
| src/main/media.test.ts | 4 |
| src/main/photocraftCli.test.ts | 5 |
| src/main/projects.test.ts | 5 |
| src/main/projectStore.test.ts | 8 |
| src/main/settingsStore.test.ts | 3 |
| src/main/workflowSteps.test.ts | 4 |
| src/main/liveApps.live.test.ts | 12 skipped (opt-in) |
| src/main/photocraftLive.test.ts | 2 skipped (opt-in) |

The window-opening tests were not re-run for this package (they open the ArtCraft apps). Their most
recent results from today: live app tests all passed; smokes: apps 20/20, Claude across apps 15/15,
Audio + Deliver 13/13 (+ Claude checks 4/4), multi-clip 8/8, workflow 7/7.

## What is in this ZIP

* `README.md`, `CURRENT_PROGRESS.md`, `package.json`, `package-lock.json`
* `src/main/`, `src/renderer/`, `src/shared/`, `src/preload/` (all source and tests)
* `docs/` (`architecture.md`, `integration-audit.md` from the repository's top-level `docs/`, and all screenshots)
* Configuration: `tsconfig.node.json`, `tsconfig.web.json`, `electron.vite.config.ts`, `eslint.config.mjs`, `vitest.config.ts`, `.gitignore`, `.gitattributes`
* `resources/` (window tracker script, icons) and `scripts/` (end-to-end smoke tests and fixture helpers)

Excluded: `node_modules/`, `out/`, `dist/`, `build/`, caches, sample media fixtures, credentials,
keys, tokens and `.env` files (none exist in the source; the only key-shaped strings are obvious fake
values in unit tests, e.g. `AIzaTEST…`).

## Craft app stability fixes (2026-10-15)

Details: `docs/fix-wordcraft-figcraft-open-timeouts.md`. Window lifecycle: an unplaced (cloaked) app window is never hidden before it is embedded, and a put-away app is hidden, not minimized (hiding before the first frame wedged WordCraft's control channel; minimize+restore wedged FigCraft's). WordCraft has a baseline and `docProps/core.xml` save stamps are ignored by `documentDigest`; a save identical to the last saved version makes no new version. `CS_MCP_TRACE=<file>` writes an opt-in wire trace.

Remaining limitations: causes come from on/off experiments (apps' source unavailable); put-away apps have no taskbar entry; saved versions from separate sessions both start at `-live1`; DWG not tested; Grid/Deck/CAD not covered by `smoke:reopen`. `smoke:claude-apps` consumes Claude usage (about $5 for the full run) and is opt-in only; routine validation is lint, typecheck, unit tests and the local smokes (`smoke:apps`, `smoke:docs`, `smoke:docks`, `smoke:reopen`, `smoke:live`).

## Universal Application Integration Framework, first slice (2026-10-16)

Docs: `docs/external-integration-sdk.md`. External third-party software only; the 13 native Craft apps are unchanged. Adapter SDK v1, local discovery, permissions, manager, Settings > Integrations screen, Claude tools `external_apps` / `external_run`. Real-app verification: Blender 4.0.2 only (detect, connect, create cube+camera+light scene, save, re-open check, render still). Autodesk, Adobe, FreeCAD, Godot, DaVinci Resolve, Unreal, Unity are detection-only placeholders (Revit 2027 and DaVinci Resolve were detected on this PC). Not done: Revit add-in, Photoshop UXP plugin, UI-automation/visual control methods, adapter plugin loading from disk, marketplace. Opt-in Claude check: `npm run smoke:claude-external`.

## Universal Application Integration Framework, second adapter: DaVinci Resolve (2026-10-16)

Docs: `docs/external-integration-sdk.md` (Resolve adapter, what was generalized, requirements before third-party loading).

* **Resolve adapter** (`adapters/resolve.ts`) on the same SDK, manager, permissions, router and screen as Blender: six commands (`app.info`, `project.list`, `project.inspect`, `project.create_scratch`, `project.delete_scratch`, `timeline.export`). Maturity `experimental`.
* **Generalized**: `process.ts` shared helpers; `HealthResult.state` and two new statuses ("Not running", "Scripting not available"); the Integrations screen refreshes after a failed action too (it showed a stale status before).
* **Real-machine result**: Resolve 21.0.4.5 is detected; CreateCraft never starts Resolve. With Resolve running, its scripting connection is refused on this PC (Free edition or External scripting off; not distinguishable from outside), so **the commands could not be run against a real Resolve here**. They are verified against a fake scripting module only. The scripting library also crashes Python 3.13 here (3.14 loads); the adapter isolates and skips crashing interpreters.
* **videoGeneration cancellation flake**: Windows refused to `rename` jobs.json (EPERM) while the polling loop had it open, which lost a cancel or a finished download at random. Fixed with a short retry in `VideoService.update`; 14 parallel runs now 14/14 (2 of 10 and 5 of 14 parallel runs had failed before the retry). The test timeouts were also raised (the 5 s default was exceeded under load). `projects.test.ts` had the same load-only 5 s timeout and got the same treatment.
* **Tests**: lint and typecheck clean; `npx vitest run` 284 passed, 48 skipped (opt-in); with `CS_LIVE_TESTS=1` 330 passed, 2 failed. The 2 failures are in `photocraftLive.test.ts` ("PhotoCraft can't open SVG files": the test imports an SVG and opens it in PhotoCraft) and fail identically at commit 5cf7390, so they predate this work; left unchanged. `smoke:apps` 20/20, `smoke:external` 8/8 (Blender and Resolve rows). Claude-panel smokes (`smoke:claude-external`) were not run (opt-in, uses the Claude subscription).
* **Left**: real Resolve verification needs Studio with External scripting = Local, Resolve open, then `resolve.live.test.ts`. Third-party adapter loading prerequisites are listed in the SDK doc.

## External Adapter Expansion Framework: installable adapter packages (2026-10-16)

Docs: `docs/external-integration-sdk.md` (package format, trust, isolation, jobs, sample, verification, limitations). The 13 native Craft apps, Blender and the experimental Resolve adapter are unchanged in behaviour.

* **Package format** (`.ccadapter`, strict versioned manifest, SHA-256 per file, optional Ed25519 signature) and a defensive ZIP reader; `scripts/pack-adapter.mjs` builds and signs packages.
* **Secure install**: review runs nothing; unsigned needs explicit confirmation and is asked about on every command; a new publisher key must be trusted; approved permission ceiling is enforced at run time; native confirmation dialog; staging + atomic rename; per-adapter storage; re-verification on every start; Repair restores the verified original; updates need the same key and a higher version.
* **Runtime**: child process with Node's permission model (OS refuses spawn/write/worker threads), minimal environment, host operations checked against the command in flight, crash recovery (3 crashes in 10 min turns it off), timeout/cancel kill. Not an OS sandbox (documented).
* **Discovery/registry**: installed packages register commands dynamically with the existing manager and AI router; self-contained adapters need no program; placeholders (stubs) can be replaced and are restored on removal. New Claude tool `external_job`; `external_run` has `background`.
* **Jobs**: in-memory handles with progress, cancel, timeout and output verification (not persisted across restarts).
* **UI**: Settings > Integrations > Integration packages (install, review, permissions, enable/disable, update, repair, remove, background jobs, inbox).
* **Tests**: `packages.test.ts` 45 tests with real child processes; default suite 329 passed / 48 skipped; `CS_LIVE_TESTS=1` 375 passed, 2 failed (the same two PhotoCraft SVG tests, unchanged); `smoke-adapter-packages.mjs` 14/14; opt-in `smoke-claude-adapter.mjs` 5/5; `smoke-external.mjs` 8/8; `smoke-claude-external.mjs` 4/4; `smoke-docks.mjs` 15/15.
* **Not claimed**: Resolve commands are still not live-verified; no marketplace, signing authority or revocation; see the SDK doc's limitations list.

## FreeCAD as a standalone installable package (2026-10-16)

Docs: `docs/external-integration-sdk.md` ("FreeCAD adapter" and its verification table). Source: `fixtures/freecad-adapter` (`adapter.json`, `main.js`, `freecad_job.py`). Built with `scripts/pack-adapter.mjs`, installed through Settings > Integrations like any package. No change to the manager, router, runner, Settings screen, `vendors.ts` or the 13 native Craft apps (only `eslint.config.mjs` learned to lint the new package folder).

* **Nine commands**: health check, create a parametric model (spreadsheet-driven box / cylinder / plate with hole), inspect, add a primitive, set an object property, change a named parameter, save a copy, export STEP, export STL (exports are cancellable jobs). Every edit writes a NEW file; each result is verified by re-opening or re-reading the file.
* **Security**: permissions `execute-scripts` + `write-files` (+ `read-info` for the version probe), enforced by the existing ceiling; files confined to the project's FreeCAD work folder (checked in `main.js` and again in `freecad_job.py`); parameters travel as base64 JSON data; the job script is hashed with the package.
* **Real FreeCAD 1.1.4 (official signed installer, per-user at `E:\FreeCAD 1.1`) VERIFIED**: `freecad.live.test.ts` 3/3, output files reopened by a separate FreeCADCmd run (parameters, volumes, STEP 2 valid solids, STL 208 triangles), `smoke-freecad.mjs --claude --real` 10/10 with real Claude. One real bug found and fixed in the package (stale Python bytecode made a job repeat the previous one). Not verified: other FreeCAD versions, cancelling a long export on the real program. `freecad.test.ts` (13) + mock smokes remain as the offline suite and prove plumbing only.
* **Regression**: lint and typecheck clean; `npx vitest run` 342 passed / 51 skipped; Blender and Resolve live tests 8/8; `smoke-adapter-packages` 14/14; `smoke-external` 8/8.

## External application discovery and placeholder replacement (2026-10-16)

Docs: `docs/external-integration-sdk.md` (Discovery). `discovery.ts`: uninstall records now also use the `DisplayIcon` and uninstaller folders (and their `bin`), Start Menu shortcut targets are checked (one PowerShell call), and indirectly found locations are remembered in `external-apps.json` (`remembered`, wired through `ManagerDeps.remembered`). No drive is walked; no application name is hardcoded. Real result: `E:\FreeCAD 1.1\bin\FreeCADCmd.exe` is found by plain discovery (uninstall record icon folder), no Add location needed. `manager.register` drops a replaced placeholder's entries immediately; `AdapterPackages` rescans after install / enable / remove / repair (the IPC handlers no longer scan twice); Settings reloads its list after those actions. Tests: `discovery.test.ts` (11: custom drives, icon / uninstaller / shortcut signals, multiple versions, missing files, no drive walk, remembered paths, placeholder replacement). Regression: lint, typecheck, `npx vitest run` 353 passed / 52 skipped; live tests (Blender, Resolve, FreeCAD) 11/11; smokes: freecad (mock) 7/7, freecad real + Claude 11/11, adapter-packages 14/14, external 8/8, docks 15/15. Limits: portable programs with no record, shortcut or standard folder still need Add location once; remembered entries are never pruned.

## Universal Connect user experience (2026-10-16)

Docs: `docs/external-integration-sdk.md` ("Universal Connect"). Settings > Integrations now starts with a **Connect Applications…** card: a guided dialog (Find, Allow, Set up, Done) that scans, classifies every program in plain language (ready, connector available, needs attention, connected, version not supported, not supported yet; experimental marked), lets the user pick one or several, explains permissions in plain words (technical names behind a disclosure), reviews and installs a connector through the existing `.ccadapter` review, publisher-trust checkboxes and native confirmation (never silently), then connects and **verifies with a second real health check** before saying "Connected and tested". Each program has its own connector, trust, permission and verification outcome; failures, refusals and cancels never leak into another program. **Browse for Application** (file or folder) and **Forget** (location and permissions, never the program) are in; the lists refresh by themselves after every change. The native "Run X?" question now says what it means in plain language first. The framework (adapter SDK, discovery, AI router, permission model, native Craft apps) was not redesigned; additions are `ManagerDeps.extraTargets`, `manager.verify`, a `bin` lookup for portable folders, `PackageReview.exeNames/displayNames`, and `ExternalState` (same `external-apps.json`).

* **Bundled connector**: `resources/adapters/freecad-1.0.0.ccadapter` (signed, built by `scripts/build-catalog.mjs`) is only listed as available; FreeCAD found by discovery shows as "Connector available" instead of "Unsupported placeholder".
* **Real results here**: Blender 4.0.2 and FreeCAD 1.1.4 verified through the dialog (FreeCAD after reviewing and trusting its publisher), Resolve (closed) honestly "Needs your action" while the other two stayed connected ("2 of 3 connected and tested"), Revit "not supported yet".
* **Tests**: `connect.test.ts` shared 10, `connectFlow.test.ts` 15, service `connect.test.ts` 24, live `connect.live.test.ts` 6, UI `scripts/smoke-connect.mjs` 39/39 (screenshots `120` to `127`). Regression: lint and typecheck clean, `npx vitest run` 402 passed / 58 skipped, live Blender/Resolve/FreeCAD/Connect 17/17 (one file at a time; parallel live files collide, also before this change), smoke adapter-packages 14/14, external 8/8, freecad 7/7 (double) and 7/7 real.
* **Not verified / limits**: a human has not clicked through the native dialogs (the smoke answers them); the "portable copy" is a junction to the real Blender folder; Resolve success path and commands still need a running Resolve Studio; incompatible/missing connectors only against fakes; forgetting a Windows-listed program does not hide it; signing key for the bundled connector is local in `.local/`; no installer config ships `resources/adapters` yet; not tried with a screen reader.

## Universal installer and professional application integration (this session)

Docs: `docs/universal-installer.md` (architecture, protocol, security), `docs/installation-profiles.md` (Autodesk and Adobe groundwork), `docs/release-signing.md`.

* **Manifest v2** (`manifestVersion` 2; v1 still read): `integration.type` external / internal / hybrid, host profile id, plugin destination id, restart / close / admin requirements, dependencies, vendor workflow, communication capabilities with permissions. Strict schema: no scripts, no absolute paths.
* **Universal Installation Manager** (`loader.ts` over `install/pluginInstaller.ts`): plan, approved destinations owned by CreateCraft (`install/hostProfiles.ts`), journalled install with rollback and crash recovery, verify / repair from the saved original / uninstall by ledger (user-edited files kept), host-open check (never closes the program), elevation gate (no elevator ships), add-in first then connector, half-installs undone.
* **Plugin bridge** (`bridge/`): named pipe, mutual HMAC auth bound to nonces, protocol negotiation, capability registration (narrowed by the manifest), typed commands, progress, timeout, cancel, `connection-lost` = outcome unknown, heartbeat, auto-reconnect; plugin SDK `src/plugin-sdk/ccbridge-client.js` requires an API-context executor. Hybrid connectors reach the add-in only via `ctx.plugin.call` (permission-checked host op).
* **Samples**: `fixtures/simcad` (SIMULATED application that loads plugins at start and enforces an API-context rule), `fixtures/hybrid-sample`, `fixtures/internal-sample`; external-only is `fixtures/sample-adapter` (manifest v1).
* **Profiles**: Revit, AutoCAD, Fusion, Inventor, 3ds Max, Photoshop, Illustrator, Premiere Pro, After Effects, InDesign: data + docs, all `groundwork`, none ready, nothing tested against the real programs.
* **UI**: Connect Applications shows add-in offers (including self-contained ones), the install plan (close / connector / add-in / restart / test) with Check again, an Advanced section, native confirmation text with folder and restart steps, and "Open the program, or restart it so it loads the add-in"; Connected only after a real round trip. Settings > Integrations shows the add-in state.
* **Distribution**: `electron-builder.yml` (NSIS, per-user, extraResources `adapters`, `trust`, tracker script, icon, sample project), `npm run dist:dir` / `dist`, installed-layout resource lookup (`process.resourcesPath`), `scripts/release-check.mjs` (blocks dev keys, unlisted keys, unsigned/tampered/sample/simulated packages, private keys, fixtures, any Autodesk/Adobe binaries), `build-catalog.mjs --release <key>`, `resources/trust/release-publishers.json` (empty: no production key).
* **Tests**: `install/installer.test.ts` 22, `bridge/bridge.test.ts` 22, `hybrid.test.ts` 10, `release.test.ts` 9, shared `connect.test.ts` +4; UI `scripts/smoke-connect-hybrid.mjs` 15/15 from the repository and 18/18 from the packaged application (`--exe release/win-unpacked/CreateCraft.exe`).
* **Not verified / limits**: see `docs/external-integration-sdk.md` ("Universal installer: remaining limitations"). No real Autodesk or Adobe add-in; Resolve success path still needs a running Resolve Studio; no signed installer.

## Autodesk Revit 2027 integration (2026-10-16)

First real Autodesk integration: hybrid package `autodesk.revit` (C# .NET 10 add-in + connector) on Universal Connect. Verified
against the installed Revit 2027: install, load, pipe auth, capability registration, real reads, one reversible edit in a scratch
model, reconnect after a CreateCraft restart, Revit shutdown handling, repair, uninstall. Not yet driven through the Electron
window. Details, limits and results: `docs/revit-integration.md`. Revit is the only host profile marked `supported`.

## AI Adapter Builder (2026-10-16)

Docs: `docs/ai-adapter-builder.md` (workflow, architecture, templates, pipeline, security, proofs, limits). Settings > Integrations > **Create Custom Integration**
(pick an installed program without an integration, or type any program name) lets Claude research the program and write a PRIVATE local integration:
the AI returns a strict JSON *blueprint*; CreateCraft's templates (python-script, cli, file-exchange; add-in source for review only) build a
manifest-v2 external `.ccadapter`; a four-stage pipeline (static, security incl. a Python syntax-tree scan and "documented interfaces only",
simulated with a MOCK program incl. timeout/cancel/crash/uninstall, live on the real program) tests it; installation is the unchanged review +
native confirmation (generated packages are unsigned, publisher fixed to "Created on this computer (AI-generated)", asked before every command).
Verification is recorded per command and per program version and only by real, independently re-checked runs. **My Integrations** (Official / Custom),
Repair / Update (AI proposes, CreateCraft tests, user approves, every version kept for rollback), Remove. No community, sharing or marketplace features.

* **Real FreeCAD 1.1.4 proof**: new `enclosure.create` / `enclosure.measure` commands (blueprint authored by Claude in the dev session, provenance "scripted"), built, installed and run on the real program; the file was re-opened by an outside FreeCADCmd (1 valid solid, volume matches the formula, bounding box). `builder/freecad.live.test.ts`, `scripts/smoke-builder.mjs` (40/40 in the real window, screenshots 130 to 138).
* **Not-installed proof**: ImageMagick (cli template) is built and mock-tested, and stays *Awaiting live verification* with no install offered.
* **Tests**: default suite 511 passed / 61 skipped; live Blender 6, FreeCAD 3, Resolve 2, Connect 6, builder FreeCAD 1; smokes in the doc. `smoke-connect` 36/39 is identical on the previous commit.
* **Not verified**: the in-app Claude author end to end (opt-in `claude.live.test.ts`, spends Claude usage); add-in templates (C#, UXP) are source only; only FreeCAD 1.1.4 has run generated scripts; Python in the program is not sandboxed.

* **Documentation fallback (2026-10-16)**: the builder now collects official documentation itself (online, official repository files at the installed version's tag, files installed with the program, user documents), stores it locally with origin and version, flags outdated copies (Refresh in Advanced), builds an index of exact API definitions, checks every citation against it and completes missing citations only where the documentation really contains the symbol. The saved real Claude blueprint now passes the citation checks with no manual change (offline replay). See `docs/ai-adapter-builder.md` (Documentation fallback). Not yet verified live.

## Project Planner (2026-10-16)

Docs: `docs/project-planner.md`. New workspace **Planner** (More in Simplified, in the toolbar in Advanced): one current plan per project of any type
(brief, ideas, references, questions, accepted requirements and decisions with reasons, tasks with dependencies and completion checks, assets and
output versions, milestones, activity history, every version of the accepted plan). Templates are editable defaults and can be mixed. Handoff round
trip: proposals (kept apart from the plan) -> user accepts -> immutable execution package (plan revision, requirements, decisions, scope, assets,
checks, report instructions) -> executor claims a task and submits a structured report -> user reviews. **Reported complete is never accepted** until the
user accepts; outdated plans are flagged on packages and reports; edits and proposals that conflict are refused, duplicate reports and double claims are
prevented; everything survives a restart (atomic writes under a lock, so the app and the MCP server can write at once).

* **Copy and paste**: package as Markdown/JSON; paste a JSON or Markdown report, preview (with what was guessed) before anything is applied, original kept.
* **MCP server** (`out/planner-mcp.cjs`, `npm run build:planner-mcp`): stdio plus token-protected 127.0.0.1 HTTP; scopes `read`, `propose`, `package`, `execute`
  (editing and accepting cannot be granted to a connection). CreateCraft's own Claude uses the same session through four `planner_*` tools.
* **Verified**: real MCP round trips across real processes; Claude Code's own `claude mcp list` (isolated config, no model call) connected to the server.
* **Not verified**: a model-driven Claude Code session (paid); Cowork, ChatGPT and the Gemini app cannot reach a local server (copy and paste works; remote
  hosting is not built); Gemini CLI configuration is untested (not installed). Client table with sources: `docs/project-planner.md`.
* **Tests**: 20 planner unit/integration tests, `scripts/smoke-planner.mjs` 22/22 in the real window (screenshots 140-149). Spend: $0.

## Linux compatibility (2026-10-17)

Docs: `docs/linux-compatibility.md` (audit, changes, evidence tables, findings). Decision: Windows stays the primary development platform; Linux is
maintained from the same codebase, and Linux packaging, native AMD GPU validation and extensive Linux integration testing are postponed.

* **Code**: shared OS helpers (`src/shared/platform.ts`, `src/main/platform/`); on Linux the 13 Craft apps are reported unavailable (no Linux build is known), window
  embedding is Windows-only (apps open in their own window elsewhere), credentials require a real keyring (GNOME Keyring or KWallet, `basic_text` refused),
  adapters declare `platforms` (default Windows only; the manager never runs adapter code on another system), Linux discovery, GPU/Vulkan detection and
  a Linux local-video engine download entry exist, AppImage/deb configuration and `Run CreateCraft.sh` exist.
* **Verified on Ubuntu 24.04 (WSL2)**: lint and typecheck clean; Vitest 557 passed / 0 failed / 145 skipped; real Planner MCP processes (stdio and HTTP);
  `smoke-planner` 22/22 and `smoke-linux` 9/9 (with and without a keyring) in the real window; `smoke-nav` 7/7. Windows on the same commits: 640 passed / 62 skipped.
* **Found and fixed by running on Linux**: Electron chose `basic_text` on unrecognised desktops even with a keyring (CreateCraft now asks for libsecret
  explicitly); tests relied on a case-insensitive file system; the Planner workspace was not accepted when saving a project's last workspace (also a
  Windows bug).
* **Not verified on Linux**: Craft apps (none exist), Blender/FreeCAD adapters (declared Windows-only), GPU/Vulkan/AMD and local video, Claude sign-in and live
  session, AppImage/deb build, the AI Adapter Builder's mock-program simulation (Windows launcher), first run/backup/upgrade.
