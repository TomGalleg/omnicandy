# DeckCraft
Format: PLAIN text, 322 lines.

## first 24 lines
```
file.new — New Presentation: {theme?: name, template?: starter name, size?: [w,h] pt, blank?: bool}
file.templates — Starter Templates → [{name, summary, theme, slides}]
file.open — Open…: {path}
file.adopt — Open: {path, token?} (a presentation the host read in the background and staged with Session::stage_loaded; without one, reads path like file.open)
file.openBytes — Open Data: {name, data: base64}
file.save — Save: {path?, format?: deckcraft|pptx}
file.saveAs — Save As…: {path, format?}
file.saveTemplate — Save as Template…: {path}
file.saveBytes — Save to Data: {format?: deckcraft|pptx} → {data: base64}
file.export — Export…: {path, format?: png|jpeg|pptx|deckcraft|outline|pdf|gif (else by path), slide?: index, all?: bool, scale?: px per pt, layout?: slides|notes|handouts (pdf), perPage?: 1|2|3|4|6|9, paper?: letter|a4|legal|a3 (pdf), orientation?: portrait|landscape (pdf), dpi?, slides?: [index]|range ("1-3,5"), includeHidden?, textLayer?, frame?, width?: px 16-3840|small|medium|large|extraLarge (gif), secondsPerSlide?: 0.1-600 (gif; 5), loop?: bool (gif; true: forever)} → {path, bytes} or {files} (png, jpeg); gif adds frames, width, height, secondsPerSlide
file.info — Info → {title, path, format, dirty, slides, hiddenSlides, sections, bytes?, properties}
file.render — Render Slide: {slide?: index, scale?, edit?: bool} → {png: base64, width, height}
slide.colorAt — Color At: {slide?: index, x, y (slide units), scale?: px per unit (2)} → {color: "RRGGBB", alpha: 0..255, x, y}: the colour drawn at a point of the slide (the Eyedropper)
file.close — Close
file.properties — Properties: {title?, subject?, author?, keywords?, comments?, category?, company?} → properties
file.recovery.save — Save AutoRecover Information → {written}
file.recovery.list — Recovered Presentations → [{uid, path, title, saved}]
file.recovery.open — Open Recovered Presentations → {opened: [document index]}
file.recovery.discard — Discard Recovered Presentations: {uid?: one entry (else all)}
file.revert — Revert
window.next — Next Window: {index?}
edit.undo — Undo
edit.redo — Redo
edit.cut — Cut: {scope?: slides} → {text, html?}
```
## `describe file.new`
```
file.new: New Presentation, in File, shortcut Cmd+N.

Parameters:
  theme, optional     name
  template, optional  starter name
  size, optional      [w,h] pt
  blank, optional     bool

Run it with: deckcraft-cli run --cmd file.new

```
