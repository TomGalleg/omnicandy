# EffectCraft
Format: PLAIN text, 732 lines.

## first 24 lines
```
file.newProject                      New Project                          Cmd+Alt+N        
file.openDemoProject                 Open Demo Project                                     
file.open                            Open Project...                      Cmd+O            {path}
file.save                            Save                                 Cmd+S            {path?}
file.saveAs                          Save As...                           Cmd+Shift+S      {path}
file.incrementAndSave                Increment and Save                   Cmd+Alt+Shift+S  
file.revert                          Revert                                                
file.import                          File...                              Cmd+I            {paths: [string] (files or folders), sequence?: bool (the Sequence checkbox: true imports numbered stills of one run as one image sequence, one picked file bringing its whole run and several picked files that range; default: a numbered still brings its run, except dropped files (drag), which import as stills as in After Effects; folders' runs import as sequences; false imports stills and a folder's files individually), alphabetical?: bool (Force Alphabetical Order: every image of that type in the folder, by name), frameRate?: fps (image sequences; default Settings ▸ Import ▸ Sequence Footage), importAs?: footage|composition|compositionLayerSizes (Photoshop, PDF, Illustrator and EPS files), layer?: name|index (footage of one Photoshop layer), page?: number from 1 (PDF / Illustrator page), drag?: bool (dropped files: Settings ▸ Import ▸ Default Drag Import As; files import as stills unless sequence), addToComp?: bool (also add them to the active comp, at time?, index?, position? as in layer.addItem), background?: bool (probe the files in a background job, jobs.list / jobs.wait; returns {job})}
file.projectSettings                 Project Settings...                  Cmd+Alt+Shift+K  {bitDepth?: 8|16|32, colorEngine?: adobe|ocio, workingSpace?: none|srgb|rec709|rec2020|p3|acescg|aces2065, workingGamma?: 2.2|2.4 (with no working space), linearize?, blendLinear?, hdr?: clip|compand|toneMap, outputSpace?: srgb|rec709|rec2020|p3|rec2100pq|rec2100hlg, renderer?: gpu|software, timeDisplay?: timecode|frames|feet35|feet16}
file.cycleBitDepth                   Cycle Project Bit Depth                               
render.backend                       Video Rendering and Effects                           {backend?: gpu|cpu}
roto.models                          Roto Brush Models                                     
roto.model.select                    Use Roto Brush Model                                  {id: classical|mobilesam, wait?} (Roto Brush 2.0 / 3.0 use it; wait: loaded before returning)
roto.model.install                   Install Roto Brush Model                              {path: weights file, id?, wait?} — verified against the registry's SHA-256
roto.model.download                  Download Roto Brush Model                             {id, wait?} — the official weights, verified (desktop; uses the system curl)
roto.model.remove                    Remove Roto Brush Model                               {id}
face.models                          Face Tracking Models                                  
face.model.select                    Use Face Tracking Model                               {id: classical|mediapipe-face, wait?} (face tracking uses it; wait: loaded before returning)
face.model.install    
```
## `describe file.newProject`
```
(describe unsupported)
```
