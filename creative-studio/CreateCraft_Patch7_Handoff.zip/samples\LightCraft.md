# LightCraft
Format: PLAIN text, 743 lines.

## first 24 lines
```
edit.undo                    Undo  [Cmd+Z]
                             params: {}
edit.redo                    Redo  [Cmd+Shift+Z]
                             params: {}
library.source               Show Source
                             params: {kind: all|recentlyAdded|album|recentlyDeleted|picks|missing|libraryFolder, id?: albumId, path?: a path from library.folders (for libraryFolder)}
library.filter               Filter
                             params: partial Filter: {text?, rating?, ratingOp?: atLeast|exactly|atMost, flag?: pick|reject|none|null, label?, kind?, merged?: hdr|panorama|hdrPanorama|any, edited?, date?, libraryFolder?: a path from library.folders, keyword?, person?, camera?}
library.folders              Library Folders
                             params: {} → [{name, path, count, own, volume, selectable, label?, children}] the disks and the folders the library's photos were imported from, with photo counts (subfolders included in `count`); show one with library.source {kind: libraryFolder, path} (rows with selectable false only open)
library.removeFolder         Remove Folder from Library
                             params: {path, disk?: bool} — move the library photos imported from this folder (and the folders inside it) to Recently Deleted; one undo step, no file is touched. A whole disk or share (`/Volumes/nas`, `C:\`, `\\srv\share`) goes only with `disk: true`, the startup disk never → {removed}
folder.label                 Set Folder Color Label
                             params: {path, label: red|yellow|green|blue|purple|none} — give a folder of the library (one its photos were imported from, see library.folders) a colour label, or take it off (also once its photos are gone); one undo step. The label follows the folder when it is renamed or moved with folder.rename / folder.move → {path, label}
library.clearFilter          Clear Filters
                             params: {}
library.sort                 Sort
                             params: {key?: captureDate|importDate|editDate|fileName|rating|fileSize|random, ascending?: bool, group?: auto|none|day|month|year, seed?: u64 (the shuffle `random` gives)}
library.refresh              Refresh View
                             params: {} — show what matches now: a view that holds its photos (`library.holdView`) lets go of the ones that stopped matching a smart album's rules, Picks or the filter bar since it was opened, sorted or last refreshed
library.holdView             Hold View Until Refreshed
                             params: {on?: bool (toggles when omitted)} → {hold} — when on, an edit that makes a photo stop matching the view (a keyword given in a smart album of photos without keywords, a flag taken off in Picks, a rating under the filter bar's) keeps it in the view until `library.refresh`, Reshuffle, or another source, filter or sort; photos that start matching still appear at once, and deleting a photo or taking it out of the album or folder shown still takes it out of the view. Changing a smart album's rules is another view too. Off (the default): the view follows every edit. Kept with the library's preferences; asking for the state it already has changes nothing
library.shuffle              Reshuffle
                             params: {seed?: 0..2^53-1} — sort at random; without `seed` a new shuffle each time
```
## line 5 (range/enum-like parameter line)
```
library.source               Show Source
                             params: {kind: all|recentlyAdded|album|recentlyDeleted|picks|missing|libraryFolder, id?: albumId, path?: a path from library.folders (for libraryFolder)}
```
## line 7 (range/enum-like parameter line)
```
library.filter               Filter
                             params: partial Filter: {text?, rating?, ratingOp?: atLeast|exactly|atMost, flag?: pick|reject|none|null, label?, kind?, merged?: hdr|panorama|hdrPanorama|any, edited?, date?, libraryFolder?: a path from library.folders, keyword?, person?, camera?}
```
## line 13 (range/enum-like parameter line)
```
folder.label                 Set Folder Color Label
                             params: {path, label: red|yellow|green|blue|purple|none} — give a folder of the library (one its photos were imported from, see library.folders) a colour label, or take it off (also once its photos are gone); one undo step. The label follows the folder when it is renamed or moved with folder.rename / folder.move → {path, label}
```
## `describe edit.undo`
```
(describe unsupported)
```
