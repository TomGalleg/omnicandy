# GridCraft
Format: PLAIN text, 683 lines.

## first 24 lines
```
file.new                       New Workbook (File) [Cmd+N]
                                 {sample?: "budget"|"sales"|"grades"}
file.open                      Open (File) [Cmd+O]
                                 {path} | {name, base64}, plus {password} for a password-protected workbook and {csvAsText?: bool} to keep every csv/tsv/txt field as text, with no number or date conversion (xlsx, xlsm, xls import, xlsb and ods data import, csv, tsv, txt, json)
file.save                      Save (File) [Cmd+S]
                                 {path?} (xlsx by default; .csv/.tsv/.json/.html/.pdf by extension)
file.saveAs                    Save As (File) [Cmd+Shift+S]
                                 {path} (.xlsx, .csv, .tsv, .json, .html, or .pdf: a PDF of the active sheet)
file.saveBytes                 Encode Workbook
                                 {format?: xlsx|csv|tsv|json|html} → {base64}
file.close                     Close (File) [Cmd+W]
                                 {force?: bool}
file.exportCsv                 Export as CSV (File > Export)
                                 {path, sheet?}
file.exportHtml                Save as Web Page (File > Export)
                                 {path}
file.properties                Properties (File)
                                 {title?, subject?, author?, company?, keywords?, description?}
file.options                   Options (File)
                                 {} → {calculation: {mode, iterative, maxIterations, maxChange}} for the active workbook (the interface opens File › Options; change settings with their own commands, e.g. formulas.calculationOptions, view.theme, app.language.set)
window.activate                Switch Window (Window)
                                 {index}
cell.set                       Enter Cell
                                 {cell?: "B2", input: "text, number or =formula", sheet?, array?: bool}
```
## line 1 (range/enum-like parameter line)
```
file.new                       New Workbook (File) [Cmd+N]
                                 {sample?: "budget"|"sales"|"grades"}
```
## line 3 (range/enum-like parameter line)
```
file.open                      Open (File) [Cmd+O]
                                 {path} | {name, base64}, plus {password} for a password-protected workbook and {csvAsText?: bool} to keep every csv/tsv/txt field as text, with no number or date conversion (xlsx, xlsm, xls import, xlsb and ods data import, csv, tsv, txt, json)
```
## line 9 (range/enum-like parameter line)
```
file.saveBytes                 Encode Workbook
                                 {format?: xlsx|csv|tsv|json|html} → {base64}
```
## `describe file.new`
```
(describe unsupported)
```
