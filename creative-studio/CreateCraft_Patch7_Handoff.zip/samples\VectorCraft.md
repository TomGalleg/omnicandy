# VectorCraft
Format: JSON array, 785 entries. Keys: enabled, id, label, menu, params, shortcut

## first 3
```json
[
 {
  "enabled": true,
  "id": "file.new",
  "label": "New…",
  "menu": [
   "File"
  ],
  "params": "{preset?: a name from file.newPresets (start from it; the other params change it), name?|title?: document name (default Untitled-N), width?: pt=612|\"210 mm\", height?: pt=792, units?: \"Pixels\"|\"Points\"|\"Picas\"|\"Inches\"|\"Millimeters\"|\"Centimeters\"|\"Feet\"|\"Yards\"|\"Meters\"|\"Feet & Inches\" (default: prefs unitsGeneral, as print presets; screen presets: Pixels), orientation?: \"portrait\"|\"landscape\" (swaps width and height to match), artboards?: n (1–1000), artboardLayout?: {layout?: \"gridByRow\"|\"gridByColumn\"|\"row\"|\"column\", columns?: n (default: all in one row), spacing?: pt=20, rightToLeft?: bool}, bleed?: pt|[top, bottom, left, right]|{top?, …} (0–72 pt), backgroundContents?: \"transparent\"|\"whi",
  "shortcut": null
 },
 {
  "disabled_reason": "no document open",
  "enabled": false,
  "id": "file.close",
  "label": "Close",
  "menu": [
   "File"
  ],
  "params": "{index?}",
  "shortcut": "Cmd+W"
 },
 {
  "enabled": true,
  "id": "document.activate",
  "label": "Activate Document",
  "menu": [],
  "params": "{index}",
  "shortcut": null
 }
]
```
## numeric ranges (a..b)
```json
[
 {
  "disabled_reason": "no document open",
  "enabled": false,
  "id": "object.setProps",
  "label": "Object Properties",
  "menu": [],
  "params": "{ids?|id?, name?, visible?, locked? (visible: false or locked: true deselects every selected object hidden or locked after the call, the key object included), opacity?: 0..100, blend?: \"Multiply\"…, isolate?, knockout?: \"on\"|\"off\"|\"neutral\"|bool (true = on, false = neutral), knockoutShape?: bool, data?: {key: \"value\" | null (removes it)} (the object's own data, SVG data-* attributes: {pivot: \"100,180\"} is data-pivot; document.node → attrs.data)}",
  "shortcut": null
 },
 {
  "disabled_reason": "no document open",
  "enabled": false,
  "id": "object.setBounds",
  "label": "Set Bounds",
  "menu": [],
  "params": "{x?, y?, width?, height?, reference?: 0..8 (9-point grid), proportional?, strokes?, corners?, copy?: bool, patterns?: bool (Transform Patterns), typeAreas?: bool (area type: the frame is reshaped and the text reflows at its size), objects?: bool (Transform Objects, as object.move)} (Transform panel; width/height and the reference point follow the bounding box, rotated with rotated objects; x, y are page coordinates; with Use Preview Bounds the values measure the visual bounds; strokes/corners as object.scale; with anchor points selected (Direct Selection) and no copy, the values are the box around those points, square to the page, and only they move or scale, as with object.move (#1824))",
  "shortcut": null
 },
 {
  "disabled_reason": "no document open",
  "enabled": false,
  "id": "path.insertAnchor",
  "label": "Add Anchor Point",
  "menu": [],
  "params": "{id, subpath, segment, t: 0..1}",
  "shortcut": null
 }
]
```
## enum/union (a|b)
```json
[
 {
  "enabled": true,
  "id": "file.new",
  "label": "New…",
  "menu": [
   "File"
  ],
  "params": "{preset?: a name from file.newPresets (start from it; the other params change it), name?|title?: document name (default Untitled-N), width?: pt=612|\"210 mm\", height?: pt=792, units?: \"Pixels\"|\"Points\"|\"Picas\"|\"Inches\"|\"Millimeters\"|\"Centimeters\"|\"Feet\"|\"Yards\"|\"Meters\"|\"Feet & Inches\" (default: prefs unitsGeneral, as print presets; screen presets: Pixels), orientation?: \"portrait\"|\"landscape\" (swaps width and height to match), artboards?: n (1–1000), artboardLayout?: {layout?: \"gridByRow\"|\"gridByColumn\"|\"row\"|\"column\", columns?: n (default: all in one row), spacing?: pt=20, rightToLeft?: bool}, bleed?: pt|[top, bottom, left, right]|{top?, …} (0–72 pt), backgroundContents?: \"transparent\"|\"whi",
  "shortcut": null
 },
 {
  "disabled_reason": "no document open",
  "enabled": false,
  "id": "document.setUnits",
  "label": "Units",
  "menu": [
   "File",
   "Document Setup"
  ],
  "params": "{units: \"Points\"|\"Picas\"|\"Inches\"|\"Millimeters\"|\"Centimeters\"|\"Pixels\"|\"Feet & Inches\"|\"Meters\"|\"Yards\"|\"Feet\"} the document's units: every length the UI shows and reads (General)",
  "shortcut": null
 },
 {
  "disabled_reason": "no document open",
  "enabled": false,
  "id": "edit.paste",
  "label": "Paste",
  "menu": [
   "Edit"
  ],
  "params": "{center?: [x, y], dx?, dy?, swatchConflict?} paste centred on `center` (the app passes the view centre), else offset by dx/dy (default: the Paste Offset preference). Pasting brings the image blobs, symbols, patterns, global and spot swatches (with the tint swatches of the tints used), gradient swatches, graphic styles, character and paragraph styles and brushes the objects use; one of the same name that differs comes in renamed. swatchConflict, for a swatch whose name the document gives another colour (clipboard.conflicts): \"merge\" (default: the objects take the document's swatch) | \"add\" (the pasted swatch comes in renamed) | {name: \"merge\"|\"add\"}. With Paste Remembers Layers on (layer.past",
  "shortcut": "Cmd+V"
 }
]
```
## nested objects/arrays
```json
[
 {
  "disabled_reason": "no document open",
  "enabled": false,
  "id": "document.find",
  "label": "Find Objects",
  "menu": [],
  "params": "{name?: substring of the Layers panel name, kind?: panel label such as Group; Path; Type or Image (exact), text?: substring of type content, limit?: max matches (default 100, 0 counts only)} → {matches: [{id, name, kind, path}], total}",
  "shortcut": null
 },
 {
  "disabled_reason": "no document open",
  "enabled": false,
  "id": "edit.paste",
  "label": "Paste",
  "menu": [
   "Edit"
  ],
  "params": "{center?: [x, y], dx?, dy?, swatchConflict?} paste centred on `center` (the app passes the view centre), else offset by dx/dy (default: the Paste Offset preference). Pasting brings the image blobs, symbols, patterns, global and spot swatches (with the tint swatches of the tints used), gradient swatches, graphic styles, character and paragraph styles and brushes the objects use; one of the same name that differs comes in renamed. swatchConflict, for a swatch whose name the document gives another colour (clipboard.conflicts): \"merge\" (default: the objects take the document's swatch) | \"add\" (the pasted swatch comes in renamed) | {name: \"merge\"|\"add\"}. With Paste Remembers Layers on (layer.past",
  "shortcut": "Cmd+V"
 },
 {
  "disabled_reason": "no document open",
  "enabled": false,
  "id": "clipboard.conflicts",
  "label": "Swatch Conflicts",
  "menu": [],
  "params": "{} → {swatches: [{name, document, clipboard, spot}]} the global or spot swatches the copied objects use whose name the active document gives another colour (`document`/`clipboard`: #rrggbb): Paste asks Merge or Add for each (pass the answer as edit.paste* {swatchConflict}). Pasting back into the document the objects came from raises none",
  "shortcut": null
 }
]
```
## no-param / return-doc (arrow)
```json
[
 {
  "enabled": true,
  "id": "file.new",
  "label": "New…",
  "menu": [
   "File"
  ],
  "params": "{preset?: a name from file.newPresets (start from it; the other params change it), name?|title?: document name (default Untitled-N), width?: pt=612|\"210 mm\", height?: pt=792, units?: \"Pixels\"|\"Points\"|\"Picas\"|\"Inches\"|\"Millimeters\"|\"Centimeters\"|\"Feet\"|\"Yards\"|\"Meters\"|\"Feet & Inches\" (default: prefs unitsGeneral, as print presets; screen presets: Pixels), orientation?: \"portrait\"|\"landscape\" (swaps width and height to match), artboards?: n (1–1000), artboardLayout?: {layout?: \"gridByRow\"|\"gridByColumn\"|\"row\"|\"column\", columns?: n (default: all in one row), spacing?: pt=20, rightToLeft?: bool}, bleed?: pt|[top, bottom, left, right]|{top?, …} (0–72 pt), backgroundContents?: \"transparent\"|\"whi",
  "shortcut": null
 },
 {
  "disabled_reason": "no document open",
  "enabled": false,
  "id": "document.inspect",
  "label": "Inspect Document",
  "menu": [],
  "params": "{depth?, childLimit?, ids?: [id…] (list just these nodes, of any level, in this order, under `nodes` in place of `layers`; an unknown id is an error; at most 10000), kind?: panel label such as Layer; Group; Path; Type or Image (exact, ignoring case; list every such node under `nodes`, each with `path`, its ancestor ids with the layer first, searching the subtrees of `ids` when given), limit?: at most this many entries of the list, offset?: entries skipped first (default 0; with `ids`, `kind`, `limit` or `offset` the reply adds `total`, the entries before paging)} → layer tree (each node: id, name, kind, visible, locked, bounds, opacity when below 1, blend when not Normal, fill, stroke and st",
  "shortcut": null
 },
 {
  "disabled_reason": "no document open",
  "enabled": false,
  "id": "document.node",
  "label": "Inspect Object",
  "menu": [],
  "params": "{id, summary?: compact summary, depth?: child levels in the summary (default all), childLimit?: children shown per node (default all; a level that shows fewer reports childCount)} → one object",
  "shortcut": null
 }
]
```
## optional markers (?)
```json
[
 {
  "enabled": true,
  "id": "file.new",
  "label": "New…",
  "menu": [
   "File"
  ],
  "params": "{preset?: a name from file.newPresets (start from it; the other params change it), name?|title?: document name (default Untitled-N), width?: pt=612|\"210 mm\", height?: pt=792, units?: \"Pixels\"|\"Points\"|\"Picas\"|\"Inches\"|\"Millimeters\"|\"Centimeters\"|\"Feet\"|\"Yards\"|\"Meters\"|\"Feet & Inches\" (default: prefs unitsGeneral, as print presets; screen presets: Pixels), orientation?: \"portrait\"|\"landscape\" (swaps width and height to match), artboards?: n (1–1000), artboardLayout?: {layout?: \"gridByRow\"|\"gridByColumn\"|\"row\"|\"column\", columns?: n (default: all in one row), spacing?: pt=20, rightToLeft?: bool}, bleed?: pt|[top, bottom, left, right]|{top?, …} (0–72 pt), backgroundContents?: \"transparent\"|\"whi",
  "shortcut": null
 },
 {
  "disabled_reason": "no document open",
  "enabled": false,
  "id": "document.inspect",
  "label": "Inspect Document",
  "menu": [],
  "params": "{depth?, childLimit?, ids?: [id…] (list just these nodes, of any level, in this order, under `nodes` in place of `layers`; an unknown id is an error; at most 10000), kind?: panel label such as Layer; Group; Path; Type or Image (exact, ignoring case; list every such node under `nodes`, each with `path`, its ancestor ids with the layer first, searching the subtrees of `ids` when given), limit?: at most this many entries of the list, offset?: entries skipped first (default 0; with `ids`, `kind`, `limit` or `offset` the reply adds `total`, the entries before paging)} → layer tree (each node: id, name, kind, visible, locked, bounds, opacity when below 1, blend when not Normal, fill, stroke and st",
  "shortcut": null
 }
]
```
## empty/absent params
```json
[]
```
