# FigCraft
Format: PLAIN text, 1139 lines.

## first 24 lines
```
node.create*  Create layer
    {type: rectangle|ellipse|polygon|star|line|arrow|vector|text|frame|section|component|slice, x?, y? (relative to the parent frame; groups don't count), width?, height?, parent? (id; default: the page), index?, name?, text? (for text), path? (SVG path data for vector), props? {node.set keys}, select? (default true)}
frame.create*  Create frame
    {preset? (name from FRAME_PRESETS), x?, y?, width?, height?, parent?, name?, props?} (a preset without x/y lands to the right of the page's frames)
shape.rectangle*  Rectangle
    {x, y, width, height, parent?, props?}
shape.ellipse*  Ellipse
    {x, y, width, height, parent?, props?}
shape.polygon*  Polygon
    {x, y, width, height, parent?, props? {pointCount}}
shape.star*  Star
    {x, y, width, height, parent?, props? {pointCount, innerRadius}}
shape.line*  Line
    {x, y, width (length), parent?, props? {rotation}}
shape.arrow*  Arrow
    {x, y, width (length), parent?, props?}
text.create*  Text
    {text, x, y, parent?, width? (fixed width wraps), props? (fontSize, fontFamily, …)}
vector.create*  Vector
    {path (SVG path data) | points [[x,y],..], closed?, x?, y?, width?, height? (scale the path; one keeps its proportion), parent?, props?}
image.place*  Place image
    {data (base64) | path, x?, y?, width?, height?, parent?, mode? (fill|fit|crop|tile)} → {id, image, width, height, imageProfile (its embedded colour profile; null: taken as sRGB)}
frame.swapOrientation*  Swap orientation
    {ids?} (portrait ⇄ landscape: width and height trade places)
```
## line 1 (range/enum-like parameter line)
```
node.create*  Create layer
    {type: rectangle|ellipse|polygon|star|line|arrow|vector|text|frame|section|component|slice, x?, y? (relative to the parent frame; groups don't count), width?, height?, parent? (id; default: the page), index?, name?, text? (for text), path? (SVG path data for vector), props? {node.set keys}, select? (default true)}
```
## line 19 (range/enum-like parameter line)
```
vector.create*  Vector
    {path (SVG path data) | points [[x,y],..], closed?, x?, y?, width?, height? (scale the path; one keeps its proportion), parent?, props?}
```
## line 21 (range/enum-like parameter line)
```
image.place*  Place image
    {data (base64) | path, x?, y?, width?, height?, parent?, mode? (fill|fit|crop|tile)} → {id, image, width, height, imageProfile (its embedded colour profile; null: taken as sRGB)}
```
## `describe node.create`
```
(describe unsupported)
```
