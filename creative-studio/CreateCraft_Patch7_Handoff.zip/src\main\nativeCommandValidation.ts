/** Pure validation of advertised native command schemas. Does not grant execution permissions. */
type Rule = { type: 'number' | 'boolean' | 'string'; min?: number; max?: number; required?: boolean };
function readRule(value: unknown): Rule | null {
  if (value && typeof value === 'object' && !Array.isArray(value)) {
    const v = value as Record<string, unknown>;
    const kind = v.type === 'integer' ? 'number' : v.type;
    if (kind !== 'number' && kind !== 'boolean' && kind !== 'string') return null;
    return { type: kind, min: typeof v.min === 'number' ? v.min : typeof v.minimum === 'number' ? v.minimum : undefined,
      max: typeof v.max === 'number' ? v.max : typeof v.maximum === 'number' ? v.maximum : undefined,
      required: v.required === true };
  }
  if (typeof value !== 'string') return null;
  const text = value.trim();
  const range = text.match(/^(-?\d+(?:\.\d+)?)\s*\.\.\s*(-?\d+(?:\.\d+)?)(?:\s*=.*)?$/);
  if (range) return {type:'number', min:Number(range[1]), max:Number(range[2])};
  if (/^(?:bool|boolean)(?:=.+)?$/i.test(text)) return {type:'boolean'};
  if (/^(?:number|integer|float|double)(?:=.+)?$/i.test(text)) return {type:'number'};
  if (/^(?:string|text)(?:=.+)?$/i.test(text)) return {type:'string'};
  return null;
}
/** PhotoCraft CLI uses JSON-like compact params: {"brightness":-150..150=0,"legacy":bool=false}.
 * Strictly parse the whole string rather than evaluating it or silently ignoring unknown syntax. */
function parseCompactParams(value: string): Record<string, string> | null {
  const text = value.trim();
  if (!text.startsWith('{') || !text.endsWith('}')) return null;
  const inside = text.slice(1, -1).trim();
  if (!inside) return {};
  const result: Record<string, string> = Object.create(null) as Record<string, string>;
  for (const field of inside.split(',')) {
    const match = field.trim().match(/^(?:"([A-Za-z_][\w-]*)"|([A-Za-z_][\w-]*))\s*:\s*(.+)$/);
    if (!match) return null;
    const key = match[1] ?? match[2];
    const rule = match[3]?.trim();
    if (!key || !rule || Object.prototype.hasOwnProperty.call(result, key) || !readRule(rule)) return null;
    result[key] = rule;
  }
  return result;
}

export function validateNativeCommandDetail(detail: string, command: string, params: Record<string, unknown>): string | undefined {
  let parsed: unknown;
  try { parsed = JSON.parse(detail); } catch { return `Cannot validate ${command}: command schema is not structured JSON. Do not execute.`; }
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return `Cannot validate ${command}: invalid command schema.`;
  const record = parsed as Record<string, unknown>;
  if (record.id !== command) return `Cannot validate ${command}: command schema ID mismatch.`;
  const schema = record.params ?? record.parameters ?? record.inputSchema;
  const normalized = typeof schema === 'string' ? parseCompactParams(schema) : schema;
  if (!normalized || typeof normalized !== 'object' || Array.isArray(normalized)) return `Cannot validate ${command}: parameter schema unavailable or malformed.`;
  const raw = normalized as Record<string, unknown>;
  const properties = raw.properties && typeof raw.properties === 'object' && !Array.isArray(raw.properties) ? raw.properties as Record<string, unknown> : raw;
  const required = new Set(Array.isArray(raw.required) ? raw.required.filter((k): k is string => typeof k === 'string') : []);
  for (const key of Object.keys(params)) {
    if (!Object.prototype.hasOwnProperty.call(properties,key)) return `Unknown parameter "${key}" for ${command}. Inspect exact command ID.`;
  }
  for (const [key, value] of Object.entries(properties)) {
    if (key === 'required' || key === 'additionalProperties' || key === 'type') continue;
    const rule = readRule(value);
    if (!rule) return `Cannot validate ${command}: unsupported schema for "${key}". Do not execute.`;
    const supplied = params[key];
    if (supplied === undefined) { if (required.has(key) || rule.required) return `Missing required parameter "${key}".`; continue; }
    if (rule.type === 'number') {
      if (typeof supplied !== 'number' || !Number.isFinite(supplied)) return `Parameter "${key}" must be a finite number.`;
      if (rule.min !== undefined && supplied < rule.min) return `Parameter "${key}" must be at least ${rule.min}.`;
      if (rule.max !== undefined && supplied > rule.max) return `Parameter "${key}" must be at most ${rule.max}.`;
    } else if (typeof supplied !== rule.type) return `Parameter "${key}" must be ${rule.type}.`;
  }
  return undefined;
}
