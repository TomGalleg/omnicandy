# SoundCraft
Format: PLAIN text, 481 lines.

## first 24 lines
```
session.new                          New...                             File
session.open                         Open Session...                    File
session.close                        Close Session                      File
session.save                         Save Session                       File
session.save_as                      Save Session As...                 File
session.save_copy                    Save Session Copy In...            File
session.save_template                Save As Template...                File
session.revert                       Revert Session to Saved...         File
file.import_audio                    Audio...                           File > Import
file.import_midi                     MIDI...                            File > Import
file.import_video                    Video...                           File > Import
file.bounce_mix                      Bounce Mix...                      File
file.bounce_stems                    Bounce Stems...                    
file.export_midi                     MIDI...                            File > Export
file.export_session_text             Session Info as Text...            File > Export
file.export_clips                    Export Clips as Files...           
file.export_selected_tracks_as_session Selected Tracks as New Session...  File > Export
file.export_sibelius                 Sibelius...                        File > Export
file.send_to_sibelius                Sibelius                           File > Send To...
file.print_score                     Print Score...                     File
file.score_setup                     Score Setup...                     File
file.export_clip_groups              Export Clip Groups...              
file.import_clip_groups              Clip Groups...                     File > Import
file.get_info                        Get Info...                        File
```
## `describe session.new`
```
{
  "id": "session.new",
  "label": "New...",
  "menu": [
    "File"
  ],
  "shortcut": "Cmd+N",
  "params": "{name?: 'Untitled', sample_rate?: 48000, bit_depth?: 24, template?: blank|demo}",
  "enabled": true,
  "disabled_reason": null
}

```
