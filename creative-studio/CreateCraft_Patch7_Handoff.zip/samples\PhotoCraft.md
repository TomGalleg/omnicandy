# PhotoCraft
Format: JSON array, 918 entries. Keys: disabledReason, enabled, id, label, menu, needsDocument, params, shortcut

## first 3
```json
[
 {
  "disabledReason": null,
  "enabled": true,
  "id": "file.new",
  "label": "New…",
  "menu": [
   "File"
  ],
  "needsDocument": false,
  "params": "{\"width\":1..300000=1920,\"height\":1..300000=1080 (pixel counts are rounded),\"mode\":\"rgb|gray|grayscale|cmyk|lab\"=\"rgb\",\"depth\":8|16|32=8,\"background\":\"white|black|backgroundColor|transparent|#rrggbb\"=\"white\",\"backgroundColor\":[r,g,b]? (0..1; defaults to toolbox colour),\"resolution\":1..30000=72 (ppi),\"name\":str}",
  "shortcut": "Cmd+N"
 },
 {
  "disabledReason": "no document open",
  "enabled": false,
  "id": "file.close",
  "label": "Close",
  "menu": [
   "File"
  ],
  "needsDocument": true,
  "params": "{\"document\":index?}",
  "shortcut": "Cmd+W"
 },
 {
  "disabledReason": "nothing to undo",
  "enabled": false,
  "id": "edit.undo",
  "label": "Undo",
  "menu": [
   "Edit"
  ],
  "needsDocument": false,
  "params": "{}",
  "shortcut": "Cmd+Z"
 }
]
```
## numeric ranges (a..b)
```json
[
 {
  "disabledReason": null,
  "enabled": true,
  "id": "file.new",
  "label": "New…",
  "menu": [
   "File"
  ],
  "needsDocument": false,
  "params": "{\"width\":1..300000=1920,\"height\":1..300000=1080 (pixel counts are rounded),\"mode\":\"rgb|gray|grayscale|cmyk|lab\"=\"rgb\",\"depth\":8|16|32=8,\"background\":\"white|black|backgroundColor|transparent|#rrggbb\"=\"white\",\"backgroundColor\":[r,g,b]? (0..1; defaults to toolbox colour),\"resolution\":1..30000=72 (ppi),\"name\":str}",
  "shortcut": "Cmd+N"
 },
 {
  "disabledReason": "no document open",
  "enabled": false,
  "id": "edit.fill",
  "label": "Fill…",
  "menu": [
   "Edit"
  ],
  "needsDocument": true,
  "params": "{\"contents\":\"foreground|background|color|contentAware|pattern|history|black|gray|white\"=\"color\",\"color\":\"#rrggbb|[r,g,b,a]\"=foreground (contents=color),\"pattern\":id|name (contents=pattern),\"scale\":%=100,\"angle\":deg,\"state\":index? (contents=history; default the oldest state),\"colorAdaptation\":bool=true (contents=contentAware),\"mode\":\"normal|multiply|…\"=\"normal\",\"opacity\":0..100=100,\"preserveTransparency\":bool=false,\"target\":\"pixels\"|\"mask\"|\"quickMask\"|{\"channel\":i}?}",
  "shortcut": "Shift+F5"
 },
 {
  "disabledReason": "no document open",
  "enabled": false,
  "id": "layer.new.layer",
  "label": "Layer…",
  "menu": [
   "Layer",
   "New"
  ],
  "needsDocument": true,
  "params": "{\"name\":str?,\"clipToPrevious\":bool=false (Use Previous Layer to Create Clipping Mask; inside a clip group the layer joins it anyway),\"color\":\"none|red|orange|yellow|green|seafoam|blue|indigo|magenta|fuchsia|violet|gray\"=\"none\",\"mode\":\"Normal|Multiply|…\"=\"Normal\",\"opacity\":0..1=1,\"fillNeutral\":bool=false (fill with the mode's neutral color: modes without one are an error),\"position\":\"above|below\"=\"above\" (below: the Layers panel's Cmd/Ctrl-click; never under the Background)}",
  "shortcut": "Cmd+Shift+N"
 }
]
```
## enum/union (a|b)
```json
[
 {
  "disabledReason": null,
  "enabled": true,
  "id": "file.new",
  "label": "New…",
  "menu": [
   "File"
  ],
  "needsDocument": false,
  "params": "{\"width\":1..300000=1920,\"height\":1..300000=1080 (pixel counts are rounded),\"mode\":\"rgb|gray|grayscale|cmyk|lab\"=\"rgb\",\"depth\":8|16|32=8,\"background\":\"white|black|backgroundColor|transparent|#rrggbb\"=\"white\",\"backgroundColor\":[r,g,b]? (0..1; defaults to toolbox colour),\"resolution\":1..30000=72 (ppi),\"name\":str}",
  "shortcut": "Cmd+N"
 },
 {
  "disabledReason": "no document open",
  "enabled": false,
  "id": "edit.fill",
  "label": "Fill…",
  "menu": [
   "Edit"
  ],
  "needsDocument": true,
  "params": "{\"contents\":\"foreground|background|color|contentAware|pattern|history|black|gray|white\"=\"color\",\"color\":\"#rrggbb|[r,g,b,a]\"=foreground (contents=color),\"pattern\":id|name (contents=pattern),\"scale\":%=100,\"angle\":deg,\"state\":index? (contents=history; default the oldest state),\"colorAdaptation\":bool=true (contents=contentAware),\"mode\":\"normal|multiply|…\"=\"normal\",\"opacity\":0..100=100,\"preserveTransparency\":bool=false,\"target\":\"pixels\"|\"mask\"|\"quickMask\"|{\"channel\":i}?}",
  "shortcut": "Shift+F5"
 },
 {
  "disabledReason": "no document open",
  "enabled": false,
  "id": "select.rect",
  "keywords": "Rectangular Marquee, Elliptical Marquee (\"ellipse\":true), ellipse, oval, circle, Single Row/Column Marquee (\"line\")",
  "label": "Rectangular Selection",
  "menu": [],
  "needsDocument": true,
  "params": "{\"x\":i32,\"y\":i32,\"width\":u32,\"height\":u32,\"mode\":\"replace|add|subtract|intersect\"=\"replace\",\"ellipse\":bool=false,\"line\":\"row|column\"?,\"antiAlias\":bool=true,\"feather\":px=0}",
  "shortcut": null
 }
]
```
## nested objects/arrays
```json
[
 {
  "disabledReason": "no document open",
  "enabled": false,
  "id": "layer.setAdjustment",
  "label": "Adjustment Properties",
  "menu": [],
  "needsDocument": true,
  "params": "{\"layer\":id?, …params of that adjustment kind} (Levels, Curves: \"eyedropper\":{\"point\":\"black|gray|white\",\"at\":[x,y],\"size\":1..101=1} or {\"point\",…,\"color\":[r,g,b] 0..1} = the Properties panel's Set Black/Neutral Gray/White Point, sampling the image below the layer, RGB and Grayscale (no gray) only)",
  "shortcut": null
 },
 {
  "disabledReason": "no document open",
  "enabled": false,
  "id": "paint.stroke",
  "label": "Brush Stroke",
  "menu": [],
  "needsDocument": true,
  "params": "{\"points\":[[x,y,pressure?,tiltX?,tiltY?,rotation?,timeMs?,wheel?],…],\"brush\":{…BrushSettings}?,\"preset\":name?,\"size\":0.5..5000 px?,\"hardness\":0..1?,\"opacity\":0..1?,\"flow\":0..1?,\"spacing\":0..10?,\"color\":\"#rrggbb\"?=foreground,\"mode\":\"normal|multiply|screen|…|clear (erases with this brush)\"=\"normal\",\"erase\":bool?,\"smoothing\":0..1?,\"zoom\":number=1,\"seed\":u64?,\"target\":\"pixels\"|\"mask\"|\"quickMask\"|{\"channel\":i}=Channels panel target}",
  "shortcut": null
 },
 {
  "disabledReason": "no document open",
  "enabled": false,
  "id": "layer.newAdjustmentLayer.brightnessContrast",
  "label": "Brightness/Contrast…",
  "menu": [
   "Layer",
   "New Adjustment Layer"
  ],
  "needsDocument": true,
  "params": "{\"brightness\":-150..150=0,\"contrast\":-50..100=0,\"legacy\":bool=false} + {\"path\":\"work\"|saved path name|{…path}? (the active path: becomes the vector mask; else the selection is the layer mask, or white with no selection)}",
  "shortcut": null
 }
]
```
## no-param / return-doc (arrow)
```json
[
 {
  "disabledReason": null,
  "enabled": true,
  "id": "layer.layerStyle.defaultFor",
  "label": "Layer Style Default",
  "menu": [],
  "needsDocument": false,
  "params": "{\"kind\":str} → {\"params\":{…},\"user\":bool} (the saved user default, else the factory defaults)",
  "shortcut": null
 },
 {
  "disabledReason": "no document open",
  "enabled": false,
  "id": "layer.list",
  "label": "List Layers",
  "menu": [],
  "needsDocument": true,
  "params": "{\"document\":index?,\"flat\":bool=false} → {\"layers\":[{\"id\",\"name\",\"kind\",\"visible\",\"bounds\":[x,y,w,h]|null,\"selected\",\"active\",\"children\"?}],\"activeLayer\":id?} (top-down; groups list their \"children\", or with \"flat\" every layer is one row with its \"depth\" and \"parent\" group id)",
  "shortcut": null
 },
 {
  "disabledReason": "no document open",
  "enabled": false,
  "id": "gradient.fill.create",
  "label": "Gradient (Live)",
  "menu": [],
  "needsDocument": true,
  "params": "{\"from\":[x,y],\"to\":[x,y],\"style\":\"linear|radial|angle|reflected|diamond\"=\"linear\",\"gradient\":preset name?,\"stops\":[[t,\"#rrggbb\"|\"foreground\"|\"background\"],…]?,\"transparency\":[[t,0..100],…]? (default: the current gradient),\"reverse\":bool=false,\"dither\":bool=true,\"opacity\":0..100=100,\"mode\":\"normal|multiply|…\"=\"normal\"} → {\"layer\":id}; a Gradient Fill layer above the active layer, masked by the selection",
  "shortcut": null
 }
]
```
## optional markers (?)
```json
[
 {
  "disabledReason": "no document",
  "enabled": false,
  "id": "timeline.create",
  "label": "Create Video Timeline",
  "menu": [],
  "needsDocument": true,
  "params": "{duration?:30, fps?:30} → {timeline}",
  "shortcut": null
 },
 {
  "disabledReason": "no document",
  "enabled": false,
  "id": "image.variables.define",
  "label": "Define…",
  "menu": [
   "Image",
   "Variables"
  ],
  "needsDocument": true,
  "params": "{defs:[{name, layer:id, type:visibility|textReplacement|pixelReplacement, method?:fit|fill|asIs|conform, align?, clip?}]} → {defs,dataSets,active}",
  "shortcut": null
 }
]
```
## empty/absent params
```json
[]
```
