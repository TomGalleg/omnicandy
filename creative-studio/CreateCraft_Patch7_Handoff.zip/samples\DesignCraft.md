# DesignCraft
Format: JSON array, 521 entries. Keys: enabled, id, label, menu, params, shortcut

## first 3
```json
[
 {
  "enabled": true,
  "id": "file.new",
  "label": "Document…",
  "menu": [
   "File",
   "New"
  ],
  "params": "{preset?: \"Letter\"|\"A4\"|… or a saved preset (file.savePreset), intent?: print|web|mobile, units?: points|picas|millimeters|…, width?, height?, pages?, startPage?, facingPages?, columns?, gutter?, margins?: number|{top,bottom,inside,outside}, bleed?, slug?: n | [top, bottom, inside, outside], title?, primaryTextFrame?: bool}",
  "shortcut": "Cmd+N"
 },
 {
  "enabled": true,
  "id": "file.newSample",
  "label": "Sample Document",
  "menu": [
   "Help"
  ],
  "params": "{} — a multi-page magazine sample",
  "shortcut": null
 },
 {
  "enabled": true,
  "id": "file.presets",
  "label": "Document Presets",
  "menu": [],
  "params": "{} → the built-in presets [{name, intent, width, height, units}], then the saved ones (with `saved: true`)",
  "shortcut": null
 }
]
```
## numeric ranges (a..b)
```json
[
 {
  "disabled_reason": "no document open",
  "enabled": false,
  "id": "transform.rotate",
  "label": "Rotate",
  "menu": [
   "Object",
   "Transform"
  ],
  "params": "{angle (degrees, CCW), ref?: 0..8 (reference point of the selection bounds, default 4: centre), ids?}",
  "shortcut": null
 },
 {
  "disabled_reason": "no document open",
  "enabled": false,
  "id": "transform.shear",
  "label": "Shear",
  "menu": [
   "Object",
   "Transform"
  ],
  "params": "{angle (degrees), ref?: 0..8 (reference point of the selection bounds, default 4: centre), ids?}",
  "shortcut": null
 },
 {
  "disabled_reason": "no document open",
  "enabled": false,
  "id": "transform.flip",
  "label": "Flip",
  "menu": [
   "Object",
   "Transform"
  ],
  "params": "{axis: horizontal|vertical, ref?: 0..8 (reference point of the selection bounds, default 4: centre), ids?}",
  "shortcut": null
 }
]
```
## enum/union (a|b)
```json
[
 {
  "enabled": true,
  "id": "file.new",
  "label": "Document…",
  "menu": [
   "File",
   "New"
  ],
  "params": "{preset?: \"Letter\"|\"A4\"|… or a saved preset (file.savePreset), intent?: print|web|mobile, units?: points|picas|millimeters|…, width?, height?, pages?, startPage?, facingPages?, columns?, gutter?, margins?: number|{top,bottom,inside,outside}, bleed?, slug?: n | [top, bottom, inside, outside], title?, primaryTextFrame?: bool}",
  "shortcut": "Cmd+N"
 },
 {
  "disabled_reason": "no document open",
  "enabled": false,
  "id": "file.place",
  "label": "Place…",
  "menu": [
   "File"
  ],
  "params": "{path?|base64?, name?, frame?: id (place into), spread?, x?, y?, width?: finite number > 0 (null: absent), height? (video/audio), pdfPage?: n (1-based, Image Import Options), pdfCrop?: crop|art|trim|bleed|media|contentVisible|contentAll (the box the graphic shows; `width` is the whole page's), loadCursor? (with no frame to fill and no x/y, an image loads into the place cursor, as File › Place), layoutPage?: n (IDML / .designcraft: that page's objects as a group), page?, rect?: [x0,y0,x1,y1] (text: a new frame there), autoflow? (threads one frame per page column from the first frame on, adding pages until the text fits), removeStyles?, styleMap?: {imported name: document style}, styleConflict",
  "shortcut": "Cmd+D"
 },
 {
  "disabled_reason": "no document open",
  "enabled": false,
  "id": "file.exportPdf",
  "label": "Export PDF…",
  "menu": [
   "File"
  ],
  "params": "{path?, pages?: \"1-3,5\" | [1,3] (1-based positions; default all), flatten?: high|medium|low|ppi (Transparency Flattener: spreads with transparency are rasterised), spreads?: bool, fullScreen?: bool, bookmarksPanel?: bool, pageLayout?: single|continuous|twoUp|twoUpCover|twoUpContinuous, view?: fitPage|fitWidth|actual, advanceSeconds?: number (interactive PDF), bleed?: bool (document bleed), marks?: bool | {crop?, bleed?, pageInfo?, weight?, offset?}, standard?: \"none\"|\"x4\"|\"a2b\", compressImages?: bool, tagged?: bool (structure tree: stories as paragraphs, figures with alt text), media?: bool (interactive: embed placed video and sound), title?, author?} → {path, bytes, pages, warnings} (no pat",
  "shortcut": null
 }
]
```
## nested objects/arrays
```json
[
 {
  "enabled": true,
  "id": "file.presets",
  "label": "Document Presets",
  "menu": [],
  "params": "{} → the built-in presets [{name, intent, width, height, units}], then the saved ones (with `saved: true`)",
  "shortcut": null
 },
 {
  "enabled": true,
  "id": "file.recentFiles",
  "label": "Recent Files",
  "menu": [],
  "params": "{} → [{path, name, exists}] File › Open Recent, most recent first",
  "shortcut": null
 },
 {
  "enabled": true,
  "id": "file.recovery.list",
  "label": "Recovery Data",
  "menu": [],
  "params": "{dir?} → [{uid, path, title, saved}] unsaved documents left by a crash (default: the session's recovery folder)",
  "shortcut": null
 }
]
```
## no-param / return-doc (arrow)
```json
[
 {
  "enabled": true,
  "id": "file.presets",
  "label": "Document Presets",
  "menu": [],
  "params": "{} → the built-in presets [{name, intent, width, height, units}], then the saved ones (with `saved: true`)",
  "shortcut": null
 },
 {
  "enabled": true,
  "id": "file.open",
  "label": "Open…",
  "menu": [
   "File"
  ],
  "params": "{path} — a DesignCraft or IDML file (recognised by its content, so the extension may be missing), or an InDesign .indd/.indt (recognised by its signature or extension, converted to IDML; its conversion warnings join `warnings`); the fonts in a `Document Fonts` folder beside it load first → {index, documentFonts: faces loaded, warnings: font files skipped, GREP styles whose pattern can't compile, Based on Parent links cleared and, for IDML and InDesign files, package parts missing}",
  "shortcut": "Cmd+O"
 },
 {
  "enabled": true,
  "id": "file.openBytes",
  "label": "Open Bytes",
  "menu": [],
  "params": "{name, base64} — DesignCraft JSON, an IDML package or an InDesign .indd/.indt → {index, warnings}",
  "shortcut": null
 }
]
```
## optional markers (?)
```json
[
 {
  "enabled": true,
  "id": "file.new",
  "label": "Document…",
  "menu": [
   "File",
   "New"
  ],
  "params": "{preset?: \"Letter\"|\"A4\"|… or a saved preset (file.savePreset), intent?: print|web|mobile, units?: points|picas|millimeters|…, width?, height?, pages?, startPage?, facingPages?, columns?, gutter?, margins?: number|{top,bottom,inside,outside}, bleed?, slug?: n | [top, bottom, inside, outside], title?, primaryTextFrame?: bool}",
  "shortcut": "Cmd+N"
 },
 {
  "disabled_reason": "no document open",
  "enabled": false,
  "id": "place.drop",
  "label": "Place Loaded Graphic",
  "menu": [],
  "params": "{spread?, x, y, rect?: [x0,y0,x1,y1], frame?: id}",
  "shortcut": null
 }
]
```
## empty/absent params
```json
[]
```
