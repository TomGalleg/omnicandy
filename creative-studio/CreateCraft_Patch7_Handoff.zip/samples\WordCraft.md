# WordCraft
Format: PLAIN text, 630 lines.

## first 24 lines
```
text.insert                      Type Text                                                     Editing
text.newParagraph                New Paragraph                        Enter                    Editing
text.lineBreak                   Line Break                           Shift+Enter              Editing
text.pageBreak                   Page Break                           Mod+Enter                Insert › Pages
text.columnBreak                 Column Break                         Mod+Shift+Enter          Layout › Breaks
text.tab                         Tab                                  Tab                      Editing
text.backTab                     Shift+Tab                            Shift+Tab                Editing
text.backspace                   Backspace                            Backspace                Editing
text.delete                      Delete                               Delete                   Editing
text.deleteWordBack              Delete Previous Word                 Mod+Backspace / Alt+Backspace Editing
text.deleteWordForward           Delete Next Word                     Mod+Delete / Alt+Delete  Editing
text.nbsp                        Nonbreaking Space                    Mod+Shift+Space          Insert › Symbols
text.nbHyphen                    Nonbreaking Hyphen                   Mod+Shift+-              Insert › Symbols
text.optionalHyphen              Optional Hyphen                      Mod+-                    Insert › Symbols
text.toggleUnicode               Toggle Unicode Character             Alt+X                    Editing
text.typeCode                    Type Character Code                                           Editing
text.emDash                      Em Dash                              Mod+Alt+-                Insert › Symbols
text.copyright                   Copyright Sign                       Mod+Alt+C                Insert › Symbols
text.registered                  Registered Sign                      Mod+Alt+R                Insert › Symbols
text.trademark                   Trademark Sign                       Mod+Alt+T                Insert › Symbols
text.ellipsis                    Ellipsis                             Mod+Alt+.                Insert › Symbols
caret.left                       Left                                 Left                     Navigation
caret.right                      Right                                Right                    Navigation
caret.up                         Up                                   Up                       Navigation
```
## `describe text.insert`
```
(describe unsupported)
```
