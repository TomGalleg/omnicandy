# CADCraft
Format: JSON array, 426 entries. Keys: aliases, enabled, id, interactive, label, menu, params, shortcut

## first 3
```json
[
 {
  "aliases": [
   "qnew"
  ],
  "enabled": true,
  "id": "new",
  "interactive": false,
  "label": "New Drawing...",
  "menu": [
   "File",
   "New Drawing..."
  ],
  "params": "{metric?: bool, template?: path to a .dwt/.dxf template (\".\" for none; default QNEWTEMPLATE)}",
  "shortcut": "Cmd+N"
 },
 {
  "aliases": [],
  "enabled": true,
  "id": "open",
  "interactive": false,
  "label": "Open...",
  "menu": [
   "File",
   "Open..."
  ],
  "params": "{path} | {data: base64, name} → {index, entities?, warnings: what reading left out}",
  "shortcut": "Cmd+O"
 },
 {
  "aliases": [],
  "enabled": true,
  "id": "close",
  "interactive": false,
  "label": "Close",
  "menu": [
   "File",
   "Close"
  ],
  "params": "{index?}",
  "shortcut": "Cmd+W"
 }
]
```
## numeric ranges (a..b)
```json
[
 {
  "aliases": [
   "t",
   "mt"
  ],
  "enabled": true,
  "id": "mtext",
  "interactive": true,
  "label": "Multiline Text",
  "menu": [
   "Draw",
   "Text",
   "Multiline Text..."
  ],
  "params": "{at, text, height?, width?, attach?: 1..9 | justify?: TL..BR, rotation?, style?, lineSpacing?, lineSpacingExact?, list?: bullet|number|lower|upper, indent?, firstIndent?, rightIndent?, tabs?: [..], align?: left|center|right|justify|distributed, columns?: {type: static|dynamic, count?, gutter?, height, heights?, reversed?}} (indents and tabs in text heights; width = one column)",
  "shortcut": null
 },
 {
  "aliases": [],
  "enabled": true,
  "id": "spline.cv",
  "interactive": true,
  "label": "Control Vertices",
  "menu": [
   "Draw",
   "Spline",
   "Control Vertices"
  ],
  "params": "{control: [[x,y],...], degree?: 1..10 (default 3), closed?}",
  "shortcut": null
 },
 {
  "aliases": [
   "-overkill"
  ],
  "enabled": true,
  "id": "overkill",
  "interactive": true,
  "label": "Delete Duplicate Objects",
  "menu": [
   "Modify",
   "Delete Duplicate Objects"
  ],
  "params": "{handles? (default: the whole current space), tolerance? (0..1e6, default 1e-6), ignore?: [color|layer|linetype|ltscale|lineweight|thickness|transparency|plotStyle], plines?: bool (default true), partialOverlap?: bool (default true), endToEnd?: bool (default false), associativity?: bool (keep associated objects, default true)} → {deleted, duplicates, overlapping, segments}",
  "shortcut": null
 }
]
```
## enum/union (a|b)
```json
[
 {
  "aliases": [],
  "enabled": true,
  "id": "saveas",
  "interactive": false,
  "label": "Save As...",
  "menu": [
   "File",
   "Save As..."
  ],
  "params": "{path, version?: 2000|2004|2007|2010|2013|2018, binary?: bool}",
  "shortcut": "Cmd+Shift+S"
 },
 {
  "aliases": [],
  "enabled": true,
  "id": "drawingrecovery",
  "interactive": false,
  "label": "Drawing Recovery Manager...",
  "menu": [
   "File",
   "Drawing Utilities",
   "Drawing Recovery Manager..."
  ],
  "params": "{action?: list|open|discard (default list), path? (one of the listed files)} → {files: [{path, drawing, modified, bytes}]} | (open: as RECOVER)",
  "shortcut": null
 },
 {
  "aliases": [],
  "enabled": true,
  "id": "undo",
  "interactive": true,
  "label": "Undo",
  "menu": [],
  "params": "{count?: n} | {mode: mark|begin|end} | {mode: back, confirm?: bool (no mark: undo everything; default true)} | {mode: auto, on: bool} | {mode: control, control: all|none|one|combine|layer, on?: bool (combine/layer)}",
  "shortcut": null
 }
]
```
## nested objects/arrays
```json
[
 {
  "aliases": [],
  "enabled": true,
  "id": "audit",
  "interactive": true,
  "label": "Audit",
  "menu": [
   "File",
   "Drawing Utilities",
   "Audit"
  ],
  "params": "{fix?: bool} → {errors, fixed, issues: [{kind, location, handle?, message, fix}], message}",
  "shortcut": null
 },
 {
  "aliases": [],
  "enabled": true,
  "id": "drawingrecovery",
  "interactive": false,
  "label": "Drawing Recovery Manager...",
  "menu": [
   "File",
   "Drawing Utilities",
   "Drawing Recovery Manager..."
  ],
  "params": "{action?: list|open|discard (default list), path? (one of the listed files)} → {files: [{path, drawing, modified, bytes}]} | (open: as RECOVER)",
  "shortcut": null
 },
 {
  "aliases": [],
  "enabled": true,
  "id": "select",
  "interactive": true,
  "label": "Select",
  "menu": [],
  "params": "{handles: [hex]} | {window: [[x,y],[x,y]], crossing?: bool} | {at: [x,y]} | {clear: true} | {add?: bool}",
  "shortcut": null
 }
]
```
## no-param / return-doc (arrow)
```json
[
 {
  "aliases": [],
  "enabled": true,
  "id": "open",
  "interactive": false,
  "label": "Open...",
  "menu": [
   "File",
   "Open..."
  ],
  "params": "{path} | {data: base64, name} → {index, entities?, warnings: what reading left out}",
  "shortcut": "Cmd+O"
 },
 {
  "aliases": [],
  "enabled": true,
  "id": "document.bytes",
  "interactive": false,
  "label": "Drawing as bytes",
  "menu": [],
  "params": "{format?: dxf, version?: 2000…2018, binary?: bool} → {data: base64}",
  "shortcut": null
 },
 {
  "aliases": [
   "scr"
  ],
  "enabled": true,
  "id": "script",
  "interactive": true,
  "label": "Run Script...",
  "menu": [
   "Tools",
   "Run Script..."
  ],
  "params": "{path: script (.scr) file} | {data: base64} → {lines}",
  "shortcut": null
 }
]
```
## optional markers (?)
```json
[
 {
  "aliases": [
   "qnew"
  ],
  "enabled": true,
  "id": "new",
  "interactive": false,
  "label": "New Drawing...",
  "menu": [
   "File",
   "New Drawing..."
  ],
  "params": "{metric?: bool, template?: path to a .dwt/.dxf template (\".\" for none; default QNEWTEMPLATE)}",
  "shortcut": "Cmd+N"
 },
 {
  "aliases": [],
  "enabled": true,
  "id": "saveas",
  "interactive": false,
  "label": "Save As...",
  "menu": [
   "File",
   "Save As..."
  ],
  "params": "{path, version?: 2000|2004|2007|2010|2013|2018, binary?: bool}",
  "shortcut": "Cmd+Shift+S"
 }
]
```
## empty/absent params
```json
[
 {
  "aliases": [],
  "enabled": true,
  "id": "closeall",
  "interactive": false,
  "label": "Close All",
  "menu": [
   "File",
   "Close All"
  ],
  "params": "",
  "shortcut": null
 },
 {
  "aliases": [
   "ai_selall"
  ],
  "enabled": true,
  "id": "selectall",
  "interactive": false,
  "label": "Select All",
  "menu": [
   "Edit",
   "Select All"
  ],
  "params": "",
  "shortcut": "Cmd+A"
 }
]
```
