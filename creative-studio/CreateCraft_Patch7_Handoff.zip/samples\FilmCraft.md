# FilmCraft
Format: PLAIN text, 702 lines.

## first 24 lines
```
file.newProject                  Project…                           Cmd+Alt+N      {"name":str}
file.openDemoProject             Demo Project                                      {}
file.newSequence                 Sequence…                          Cmd+N          {"name":str,"width":u32=1920,"height":u32=1080,"fps":f64=23.976,"sampleRate":u32=48000,"video":n=3,"audio":n=3,"mix":"Stereo|Mono|5.1|Adaptive"?,"trackType":"Standard|Mono|5.1|Adaptive"?,"fromItem":itemId?,"fromItems":[itemId]?}
file.newSequenceFromClip         Sequence From Clip                                {"items":[id]?}
file.newBin                      Bin                                Cmd+B          {"name":str,"parent":binId?}
file.newBinFromSelection         Bin From Selection                 Shift+B        {"items":[id]?,"name":str?}
file.newSearchBin                Search Bin                                        {"name":str?,"column":str?,"operator":str?,"text":str?,"rows":[..]?,"matchAll":bool?,"caseSensitive":bool?}
file.newOfflineFile              Offline File…                                     {"name":str?,"fileName":str?,"tapeName":str?,"video":bool=true,"audio":bool=true,"width":u32?,"height":u32?,"fps":f64?,"sampleRate":u32=48000,"channels":u32=2,"timecode":"HH:MM:SS:FF"?,"seconds":f64=10,"description":str?}
file.newAdjustmentLayer          Adjustment Layer…                                 {"seconds":f64=5}
file.newBarsAndTone              Bars and Tone…                                    {"seconds":f64=10}
file.newBlackVideo               Black Video…                                      {"seconds":f64}
file.newColorMatte               Color Matte…                                      {"color":"#rrggbb","seconds":f64}
project.matteColor               Color Matte Color…                                {"item":id?,"color":"#rrggbb"}
file.newCountingLeader           Universal Counting Leader…                        {}
file.newTransparentVideo         Transparent Video…                                {}
file.importDemoFootage           Demo Footage                                      {"scene":"OceanSunset|Aurora|CityNight|Dunes|Plasma|Forest"}
file.exportInterchange           Export Interchange                                {"format":"edl|xml|fcpxml|otio|aaf|omf"=xml,"path":str,"sequence":id?}
file.exportEdl                   EDL…                                              {"path":str}
file.exportSelectionProject      Selection as FilmCraft Project…                   {"path":str,"items":[id]?}
file.exportAle                   Avid Log Exchange…                                {"path":str,"items":[id]?}
file.exportOtio                  OpenTimelineIO…                                   {"path":str}
file.exportFcp7Xml               Final Cut Pro XML…                                {"path":str}
file.exportFcpxml                FCPXML…                                           {"path":str}
file.exportAaf                   AAF…                                              {"path":str,"sequence":id?,"mixdownVideo":bool?,"mixdownFormat":"mov|mxf"?,"breakoutToMono":bool?,"audio":"embedded|separate|linked"?,"audioFormat":"wav|aiff|mxf"?,"sampleRate":int?,"bitDepth":"16|24"?,"trimAudio":bool?,"handles":frames?,"renderAudioEffects":bool?,"smallSectors":bool?}
```
## `describe file.newProject`
```
{
  "defaultShortcut": "Cmd+Alt+N",
  "enabled": true,
  "id": "file.newProject",
  "label": "Project…",
  "menu": [
    "File",
    "New"
  ],
  "params": "{\"name\":str}",
  "shortcut": "Cmd+Alt+N",
  "shortcuts": [
    "Cmd+Alt+N"
  ]
}

```
