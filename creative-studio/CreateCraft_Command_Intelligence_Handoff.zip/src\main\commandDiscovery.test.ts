import { describe, expect, it } from 'vitest';
import { formatDiscoveredCommands, parsePlainCommandCatalog } from './commandDiscovery';

describe('engine command catalog formatting', () => {
  it('filters a JSON command list without changing ids', () => {
    const result = formatDiscoveredCommands([{ id: 'type.create', params: { text: 'string' }, label: 'Add text' }, { id: 'shape.ellipse', label: 'Ellipse' }], 'type', 'PhotoCraft');
    expect(result).toContain('type.create');
    expect(result).not.toContain('shape.ellipse');
  });
  it('handles wrapped MCP command catalogs', () => {
    expect(formatDiscoveredCommands({ commands: [{ id: 'timeline.place' }] }, '', 'FilmCraft')).toContain('timeline.place');
  });
  it('rejects malformed catalogs without inventing commands', () => {
    expect(() => formatDiscoveredCommands({ result: 'unknown' })).toThrow(/unsupported/);
  });
});


describe('multi-line catalog and pagination', () => {
  it('counts paired description lines as one command and keeps descriptions searchable', () => {
    const plain = 'shape.circle\n  Draw a circle\nshape.rectangle\n  Draw a rectangle';
    const rows = parsePlainCommandCatalog(plain);
    expect(rows).toHaveLength(2);
    expect(formatDiscoveredCommands(rows, 'rectangle', 'LightCraft')).toContain('shape.rectangle');
    expect(formatDiscoveredCommands(rows, 'rectangle', 'LightCraft')).not.toContain('shape.circle');
  });
  it('finds commands after the first 80 and paginates filtered results', () => {
    const rows = Array.from({ length: 185 }, (_, i) => ({ id: `shape.command${i}` }));
    const second = formatDiscoveredCommands(rows, 'page:2', 'GridCraft');
    expect(second).toContain('shape.command80');
    expect(second).not.toContain('shape.command0\n');
    expect(second).toContain('page 2/3');
    expect(formatDiscoveredCommands(rows, 'page:3', 'GridCraft')).toContain('shape.command184');
  });
  it('rejects out of range pages without returning unrelated commands', () => {
    expect(formatDiscoveredCommands([{ id: 'a' }], 'page:999', 'FigCraft')).toContain('does not exist');
  });
});

describe('plain catalog parsing regressions', () => {
  it('accepts an id followed by a single space and a description (LightCraft)', () => {
    const rows = parsePlainCommandCatalog('edit.undo   Undo\n                params: {}\nlibrary.emptyRecentlyDeleted Empty Recently Deleted\n                params: {} → {deleted}\nbeforeAfter.copyAfterToBefore Copy After\'s Settings to Before\n                params: {}');
    expect(rows.map((r) => r.id)).toEqual(['edit.undo', 'library.emptyRecentlyDeleted', 'beforeAfter.copyAfterToBefore']);
    expect(rows[1]?.label).toContain('Empty Recently Deleted');
  });
  it('accepts ids with a trailing * marker and keeps the executable id (FigCraft)', () => {
    const rows = parsePlainCommandCatalog('node.create*  Create layer\n    {type: rectangle, x?, y?}\nframe.presets  List frame presets\n    {}\nshape.rectangle*  Rectangle\n    {x, y}');
    expect(rows.map((r) => r.id)).toEqual(['node.create', 'frame.presets', 'shape.rectangle']);
    expect(rows[0]?.label).toContain('Create layer');
  });
  it('never treats indented description or parameter lines as commands', () => {
    const rows = parsePlainCommandCatalog('a.one  First\n  Looks like an id\n  params: {}\na.two  Second\n    word  with gap');
    expect(rows.map((r) => r.id)).toEqual(['a.one', 'a.two']);
  });
});
